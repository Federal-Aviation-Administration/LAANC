// BeautyTips - minified from /templates/4/assets/js/beautyTips/_jquery.bt.js
jQuery.bt = {
        version: "0.9.7"
    },
    function ($) {
        jQuery.fn.bt = function (content, options) {
            function drawIt(t, e) {
                this.moveTo(t[0].x, t[0].y)
                for (var o = 1; o < t.length; o++) "arcStart" == t[o - 1].type ? (this.quadraticCurveTo(round5(t[o].x, e), round5(t[o].y, e), round5(t[(o + 1) % t.length].x, e), round5(t[(o + 1) % t.length].y, e)), o++) : this.lineTo(round5(t[o].x, e), round5(t[o].y, e))
            }

            function round5(t, e) {
                var o
                return e = numb(e), o = e % 2 ? t : Math.round(t - .5) + .5
            }

            function numb(t) {
                return parseInt(t) || 0
            }

            function arrayRemove(t, e) {
                var o, s = []
                for (o in t) t[o] != e && s.push(t[o])
                return s
            }

            function canvasSupport() {
                return !!window.HTMLCanvasElement
            }

            function shadowSupport() {
                try {
                    return $.isNumeric(document.createElement("canvas").getContext("2d").shadowOffsetX)
                } catch (t) {}
                return !1
            }

            function betweenPoint(t, e, o) {
                var s, i
                return t.x == e.x ? (s = t.y < e.y ? t.y + o : t.y - o, {
                    x: t.x,
                    y: s
                }) : t.y == e.y ? (i = t.x < e.x ? t.x + o : t.x - o, {
                    x: i,
                    y: t.y
                }) : void 0
            }

            function centerPoint(t, e, o) {
                var s, i, n = e.x == t.x ? o.x : t.x,
                    p = e.y == t.y ? o.y : t.y
                return t.x < o.x ? t.y > o.y ? (s = Math.PI / 180 * 180, i = Math.PI / 180 * 90) : (s = Math.PI / 180 * 90, i = 0) : t.y > o.y ? (s = Math.PI / 180 * 270, i = Math.PI / 180 * 180) : (s = 0, i = Math.PI / 180 * 270), {
                    x: n,
                    y: p,
                    type: "center",
                    startAngle: s,
                    endAngle: i
                }
            }

            function findIntersect(t, e, o, s, i, n, p, r) {
                if (i == p) return findIntersectY(t, e, o, s, i)
                if (n == r) return findIntersectX(t, e, o, s, n)
                var a = (e - s) / (t - o),
                    h = e - a * t,
                    c = (n - r) / (i - p),
                    x = n - c * i,
                    f = (x - h) / (a - c),
                    l = a * f + h
                return {
                    x: f,
                    y: l
                }
            }

            function findIntersectY(t, e, o, s, i) {
                if (e == s) return {
                    x: i,
                    y: e
                }
                var n = (e - s) / (t - o),
                    p = e - n * t,
                    r = n * i + p
                return {
                    x: i,
                    y: r
                }
            }

            function findIntersectX(t, e, o, s, i) {
                if (t == o) return {
                    x: t,
                    y: i
                }
                var n = (e - s) / (t - o),
                    p = e - n * t,
                    r = (i - p) / n
                return {
                    x: r,
                    y: i
                }
            }
            if (this.addClass("bt-instantiated"), "string" != typeof content) {
                var contentSelect = !0
                options = content, content = !1
            } else var contentSelect = !1
            return jQuery.fn.hoverIntent && "hover" == jQuery.bt.defaults.trigger && (jQuery.bt.defaults.trigger = "hoverIntent"), this.each(function (index) {
                var opts = jQuery.extend(!1, jQuery.bt.defaults, jQuery.bt.options, options)
                opts.spikeLength = numb(opts.spikeLength), opts.spikeGirth = numb(opts.spikeGirth), opts.overlap = numb(opts.overlap)
                var ajaxTimeout = !1
                if (opts.killTitle && $(this).find("[title]").addBack().each(function () {
                        $(this).prop("bt-xTitle") || $(this).prop("bt-xTitle", $(this).prop("title")).prop("title", "")
                    }), "string" == typeof opts.trigger && (opts.trigger = [opts.trigger]), "hoverIntent" == opts.trigger[0]) {
                    var hoverOpts = jQuery.extend(opts.hoverIntentOpts, {
                        over: function () {
                            this.btOn()
                        },
                        out: function () {
                            this.btOff()
                        }
                    })
                    $(this).hoverIntent(hoverOpts)
                } else "hover" == opts.trigger[0] ? $(this).hover(function () {
                    this.btOn()
                }, function () {
                    this.btOff()
                }) : "now" == opts.trigger[0] ? $(this).hasClass("bt-active") ? this.btOff() : this.btOn() : "none" == opts.trigger[0] || (opts.trigger.length > 1 && opts.trigger[0] != opts.trigger[1] ? $(this).bind(opts.trigger[0], function () {
                    this.btOn()
                }).bind(opts.trigger[1], function () {
                    this.btOff()
                }) : $(this).bind(opts.trigger[0], function () {
                    $(this).hasClass("bt-active") ? this.btOff() : this.btOn()
                }))
                this.btOn = function () {
                    if ("object" == typeof $(this).data("bt-box") && this.btOff(), opts.preBuild.apply(this), $(jQuery.bt.vars.closeWhenOpenStack).btOff(), $(this).addClass("bt-active " + opts.activeClass), contentSelect && null == opts.ajaxPath && (opts.killTitle && $(this).prop("title", $(this).prop("bt-xTitle")), content = $.isFunction(opts.contentSelector) ? opts.contentSelector.apply(this) : eval(opts.contentSelector), opts.killTitle && $(this).prop("title", "")), null != opts.ajaxPath && 0 == content) {
                        if ("object" == typeof opts.ajaxPath) {
                            var url = eval(opts.ajaxPath[0])
                            url += opts.ajaxPath[1] ? " " + opts.ajaxPath[1] : ""
                        } else var url = opts.ajaxPath
                        var off = url.indexOf(" ")
                        if (off >= 0) {
                            var selector = url.slice(off, url.length)
                            url = url.slice(0, off)
                        }
                        var cacheData = opts.ajaxCache ? $(document.body).data("btCache-" + url.replace(/\./g, "")) : null
                        if ("string" == typeof cacheData) content = selector ? $("<div/>").append(cacheData.replace(/<script(.|\s)*?\/script>/g, "")).find(selector) : cacheData
                        else {
                            var target = this,
                                ajaxOpts = jQuery.extend(!1, {
                                    type: opts.ajaxType,
                                    data: opts.ajaxData,
                                    cache: opts.ajaxCache,
                                    url: url,
                                    complete: function (t, e) {
                                        "success" == e || "notmodified" == e ? (opts.ajaxCache && $(document.body).data("btCache-" + url.replace(/\./g, ""), t.responseText), ajaxTimeout = !1, content = selector ? $("<div/>").append(t.responseText.replace(/<script(.|\s)*?\/script>/g, "")).find(selector) : t.responseText) : ("timeout" == e && (ajaxTimeout = !0), content = opts.ajaxError.replace(/%error/g, t.statusText)), $(target).hasClass("bt-active") && target.btOn()
                                    }
                                }, opts.ajaxOpts)
                            jQuery.ajax(ajaxOpts), content = opts.ajaxLoading
                        }
                    }
                    var shadowMarginX = 0,
                        shadowMarginY = 0,
                        shadowShiftX = 0,
                        shadowShiftY = 0
                    if (opts.shadow && !shadowSupport() && (opts.shadow = !1, jQuery.extend(opts, opts.noShadowOpts)), opts.shadow && (shadowMarginX = opts.shadowBlur > Math.abs(opts.shadowOffsetX) ? 2 * opts.shadowBlur : opts.shadowBlur + Math.abs(opts.shadowOffsetX), shadowShiftX = opts.shadowBlur - opts.shadowOffsetX > 0 ? opts.shadowBlur - opts.shadowOffsetX : 0, shadowMarginY = opts.shadowBlur > Math.abs(opts.shadowOffsetY) ? 2 * opts.shadowBlur : opts.shadowBlur + Math.abs(opts.shadowOffsetY), shadowShiftY = opts.shadowBlur - opts.shadowOffsetY > 0 ? opts.shadowBlur - opts.shadowOffsetY : 0), opts.offsetParent) var offsetParent = $(opts.offsetParent),
                        offsetParentPos = offsetParent.offset(),
                        pos = $(this).offset(),
                        top = numb(pos.top) - numb(offsetParentPos.top) + numb($(this).css("margin-top")) - shadowShiftY,
                        left = numb(pos.left) - numb(offsetParentPos.left) + numb($(this).css("margin-left")) - shadowShiftX
                    else var offsetParent = "absolute" == $(this).css("position") ? $(this).parents().eq(0).offsetParent() : $(this).offsetParent(),
                        pos = $(this).btPosition(),
                        top = numb(pos.top) + numb($(this).css("margin-top")) - shadowShiftY,
                        left = numb(pos.left) + numb($(this).css("margin-left")) - shadowShiftX
                    var width = $(this).btOuterWidth(),
                        height = $(this).outerHeight()
                    if ("object" == typeof content) {
                        var original = content,
                            clone = $(original).clone(!0).show(),
                            origClones = $(original).data("bt-clones") || []
                        origClones.push(clone), $(original).data("bt-clones", origClones), $(clone).data("bt-orig", original), $(this).data("bt-content-orig", {
                            original: original,
                            clone: clone
                        }), content = clone
                    }
                    if ("null" != typeof content && "" != content) {
                        var $text = $('<div class="bt-content"></div>').append(content).css({
                                padding: opts.padding,
                                position: "absolute",
                                width: opts.shrinkToFit ? "auto" : opts.width,
                                zIndex: opts.textzIndex,
                                left: shadowShiftX,
                                top: shadowShiftY
                            }).css(opts.cssStyles),
                            $box = $('<div class="bt-wrapper"></div>').append($text).addClass(opts.cssClass).css({
                                position: "absolute",
                                width: opts.width,
                                zIndex: opts.wrapperzIndex,
                                visibility: "hidden"
                            }).appendTo(offsetParent)
                        jQuery.fn.bgiframe && ($text.bgiframe(), $box.bgiframe()), $(this).data("bt-box", $box)
                        var scrollTop = numb($(document).scrollTop()),
                            scrollLeft = numb($(document).scrollLeft()),
                            docWidth = numb($(window).width()),
                            docHeight = numb($(window).height()),
                            winRight = scrollLeft + docWidth,
                            winBottom = scrollTop + docHeight,
                            space = {},
                            thisOffset = $(this).offset()
                        space.top = thisOffset.top - scrollTop, space.bottom = docHeight - (thisOffset + height - scrollTop), space.left = thisOffset.left - scrollLeft, space.right = docWidth - (thisOffset.left + width - scrollLeft)
                        var textOutHeight = numb($text.outerHeight()),
                            textOutWidth = numb($text.btOuterWidth())
                        if (opts.positions.constructor == String && (opts.positions = opts.positions.replace(/ /, "").split(",")), "most" == opts.positions[0]) {
                            var position = "top"
                            for (var pig in space) position = space[pig] > space[position] ? pig : position
                        } else
                            for (var x in opts.positions) {
                                var position = opts.positions[x]
                                if (("left" == position || "right" == position) && space[position] > textOutWidth + opts.spikeLength) break
                                if (("top" == position || "bottom" == position) && space[position] > textOutHeight + opts.spikeLength) break
                            }
                        var horiz = left + .5 * (width - textOutWidth),
                            vert = top + .5 * (height - textOutHeight),
                            points = [],
                            textTop, textLeft, textRight, textBottom, textTopSpace, textBottomSpace, textLeftSpace, textRightSpace, crossPoint, textCenter, spikePoint
                        switch (position) {
                            case "top":
                                $text.css("margin-bottom", opts.spikeLength + "px"), $box.css({
                                    top: top - $text.outerHeight(!0) + opts.overlap,
                                    left: horiz
                                }), textRightSpace = winRight - opts.windowMargin - ($text.offset().left + $text.btOuterWidth(!0))
                                var xShift = shadowShiftX
                                0 > textRightSpace && ($box.css("left", numb($box.css("left")) + textRightSpace + "px"), xShift -= textRightSpace), textLeftSpace = $text.offset().left + numb($text.css("margin-left")) - (scrollLeft + opts.windowMargin), 0 > textLeftSpace && ($box.css("left", numb($box.css("left")) - textLeftSpace + "px"), xShift += textLeftSpace), textTop = $text.btPosition().top + numb($text.css("margin-top")), textLeft = $text.btPosition().left + numb($text.css("margin-left")), textRight = textLeft + $text.btOuterWidth(), textBottom = textTop + $text.outerHeight(), textCenter = {
                                    x: textLeft + $text.btOuterWidth() * opts.centerPointX,
                                    y: textTop + $text.outerHeight() * opts.centerPointY
                                }, points[points.length] = spikePoint = {
                                    y: textBottom + opts.spikeLength,
                                    x: .5 * (textRight - textLeft) + xShift,
                                    type: "spike"
                                }, crossPoint = findIntersectX(spikePoint.x, spikePoint.y, textCenter.x, textCenter.y, textBottom), crossPoint.x = crossPoint.x < textLeft + opts.spikeGirth / 2 + opts.cornerRadius ? textLeft + opts.spikeGirth / 2 + opts.cornerRadius : crossPoint.x, crossPoint.x = crossPoint.x > textRight - opts.spikeGirth / 2 - opts.cornerRadius ? textRight - opts.spikeGirth / 2 - opts.CornerRadius : crossPoint.x, points[points.length] = {
                                    x: crossPoint.x - opts.spikeGirth / 2,
                                    y: textBottom,
                                    type: "join"
                                }, points[points.length] = {
                                    x: textLeft,
                                    y: textBottom,
                                    type: "corner"
                                }, points[points.length] = {
                                    x: textLeft,
                                    y: textTop,
                                    type: "corner"
                                }, points[points.length] = {
                                    x: textRight,
                                    y: textTop,
                                    type: "corner"
                                }, points[points.length] = {
                                    x: textRight,
                                    y: textBottom,
                                    type: "corner"
                                }, points[points.length] = {
                                    x: crossPoint.x + opts.spikeGirth / 2,
                                    y: textBottom,
                                    type: "join"
                                }, points[points.length] = spikePoint
                                break
                            case "left":
                                $text.css("margin-right", opts.spikeLength + "px"), $box.css({
                                    top: vert + "px",
                                    left: left - $text.btOuterWidth(!0) + opts.overlap + "px"
                                }), textBottomSpace = winBottom - opts.windowMargin - ($text.offset().top + $text.outerHeight(!0))
                                var yShift = shadowShiftY
                                0 > textBottomSpace && ($box.css("top", numb($box.css("top")) + textBottomSpace + "px"), yShift -= textBottomSpace), textTopSpace = $text.offset().top + numb($text.css("margin-top")) - (scrollTop + opts.windowMargin), 0 > textTopSpace && ($box.css("top", numb($box.css("top")) - textTopSpace + "px"), yShift += textTopSpace), textTop = $text.btPosition().top + numb($text.css("margin-top")), textLeft = $text.btPosition().left + numb($text.css("margin-left")), textRight = textLeft + $text.btOuterWidth(), textBottom = textTop + $text.outerHeight(), textCenter = {
                                    x: textLeft + $text.btOuterWidth() * opts.centerPointX,
                                    y: textTop + $text.outerHeight() * opts.centerPointY
                                }, points[points.length] = spikePoint = {
                                    x: textRight + opts.spikeLength,
                                    y: .5 * (textBottom - textTop) + yShift,
                                    type: "spike"
                                }, crossPoint = findIntersectY(spikePoint.x, spikePoint.y, textCenter.x, textCenter.y, textRight), crossPoint.y = crossPoint.y < textTop + opts.spikeGirth / 2 + opts.cornerRadius ? textTop + opts.spikeGirth / 2 + opts.cornerRadius : crossPoint.y, crossPoint.y = crossPoint.y > textBottom - opts.spikeGirth / 2 - opts.cornerRadius ? textBottom - opts.spikeGirth / 2 - opts.cornerRadius : crossPoint.y, points[points.length] = {
                                    x: textRight,
                                    y: crossPoint.y + opts.spikeGirth / 2,
                                    type: "join"
                                }, points[points.length] = {
                                    x: textRight,
                                    y: textBottom,
                                    type: "corner"
                                }, points[points.length] = {
                                    x: textLeft,
                                    y: textBottom,
                                    type: "corner"
                                }, points[points.length] = {
                                    x: textLeft,
                                    y: textTop,
                                    type: "corner"
                                }, points[points.length] = {
                                    x: textRight,
                                    y: textTop,
                                    type: "corner"
                                }, points[points.length] = {
                                    x: textRight,
                                    y: crossPoint.y - opts.spikeGirth / 2,
                                    type: "join"
                                }, points[points.length] = spikePoint
                                break
                            case "bottom":
                                $text.css("margin-top", opts.spikeLength + "px"), $box.css({
                                    top: top + height - opts.overlap,
                                    left: horiz
                                }), textRightSpace = winRight - opts.windowMargin - ($text.offset().left + $text.btOuterWidth(!0))
                                var xShift = shadowShiftX
                                0 > textRightSpace && ($box.css("left", numb($box.css("left")) + textRightSpace + "px"), xShift -= textRightSpace), textLeftSpace = $text.offset().left + numb($text.css("margin-left")) - (scrollLeft + opts.windowMargin), 0 > textLeftSpace && ($box.css("left", numb($box.css("left")) - textLeftSpace + "px"), xShift += textLeftSpace), textTop = $text.btPosition().top + numb($text.css("margin-top")), textLeft = $text.btPosition().left + numb($text.css("margin-left")), textRight = textLeft + $text.btOuterWidth(), textBottom = textTop + $text.outerHeight(), textCenter = {
                                    x: textLeft + $text.btOuterWidth() * opts.centerPointX,
                                    y: textTop + $text.outerHeight() * opts.centerPointY
                                }, points[points.length] = spikePoint = {
                                    x: .5 * (textRight - textLeft) + xShift,
                                    y: shadowShiftY,
                                    type: "spike"
                                }, crossPoint = findIntersectX(spikePoint.x, spikePoint.y, textCenter.x, textCenter.y, textTop), crossPoint.x = crossPoint.x < textLeft + opts.spikeGirth / 2 + opts.cornerRadius ? textLeft + opts.spikeGirth / 2 + opts.cornerRadius : crossPoint.x, crossPoint.x = crossPoint.x > textRight - opts.spikeGirth / 2 - opts.cornerRadius ? textRight - opts.spikeGirth / 2 - opts.cornerRadius : crossPoint.x, points[points.length] = {
                                    x: crossPoint.x + opts.spikeGirth / 2,
                                    y: textTop,
                                    type: "join"
                                }, points[points.length] = {
                                    x: textRight,
                                    y: textTop,
                                    type: "corner"
                                }, points[points.length] = {
                                    x: textRight,
                                    y: textBottom,
                                    type: "corner"
                                }, points[points.length] = {
                                    x: textLeft,
                                    y: textBottom,
                                    type: "corner"
                                }, points[points.length] = {
                                    x: textLeft,
                                    y: textTop,
                                    type: "corner"
                                }, points[points.length] = {
                                    x: crossPoint.x - opts.spikeGirth / 2,
                                    y: textTop,
                                    type: "join"
                                }, points[points.length] = spikePoint
                                break
                            case "right":
                                $text.css("margin-left", opts.spikeLength + "px"), $box.css({
                                    top: vert + "px",
                                    left: left + width - opts.overlap + "px"
                                }), textBottomSpace = winBottom - opts.windowMargin - ($text.offset().top + $text.outerHeight(!0))
                                var yShift = shadowShiftY
                                0 > textBottomSpace && ($box.css("top", numb($box.css("top")) + textBottomSpace + "px"), yShift -= textBottomSpace), textTopSpace = $text.offset().top + numb($text.css("margin-top")) - (scrollTop + opts.windowMargin), 0 > textTopSpace && ($box.css("top", numb($box.css("top")) - textTopSpace + "px"), yShift += textTopSpace), textTop = $text.btPosition().top + numb($text.css("margin-top")), textLeft = $text.btPosition().left + numb($text.css("margin-left")), textRight = textLeft + $text.btOuterWidth(), textBottom = textTop + $text.outerHeight(), textCenter = {
                                    x: textLeft + $text.btOuterWidth() * opts.centerPointX,
                                    y: textTop + $text.outerHeight() * opts.centerPointY
                                }, points[points.length] = spikePoint = {
                                    x: shadowShiftX,
                                    y: .5 * (textBottom - textTop) + yShift,
                                    type: "spike"
                                }, crossPoint = findIntersectY(spikePoint.x, spikePoint.y, textCenter.x, textCenter.y, textLeft), crossPoint.y = crossPoint.y < textTop + opts.spikeGirth / 2 + opts.cornerRadius ? textTop + opts.spikeGirth / 2 + opts.cornerRadius : crossPoint.y, crossPoint.y = crossPoint.y > textBottom - opts.spikeGirth / 2 - opts.cornerRadius ? textBottom - opts.spikeGirth / 2 - opts.cornerRadius : crossPoint.y, points[points.length] = {
                                    x: textLeft,
                                    y: crossPoint.y - opts.spikeGirth / 2,
                                    type: "join"
                                }, points[points.length] = {
                                    x: textLeft,
                                    y: textTop,
                                    type: "corner"
                                }, points[points.length] = {
                                    x: textRight,
                                    y: textTop,
                                    type: "corner"
                                }, points[points.length] = {
                                    x: textRight,
                                    y: textBottom,
                                    type: "corner"
                                }, points[points.length] = {
                                    x: textLeft,
                                    y: textBottom,
                                    type: "corner"
                                }, points[points.length] = {
                                    x: textLeft,
                                    y: crossPoint.y + opts.spikeGirth / 2,
                                    type: "join"
                                }, points[points.length] = spikePoint
                        }
                        var canvas = document.createElement("canvas")
                        if ($(canvas).prop("width", numb($text.btOuterWidth(!0)) + 2 * opts.strokeWidth + shadowMarginX).prop("height", numb($text.outerHeight(!0)) + 2 * opts.strokeWidth + shadowMarginY).appendTo($box).css({
                                position: "absolute",
                                zIndex: opts.boxzIndex
                            }), "undefined" != typeof G_vmlCanvasManager && (canvas = G_vmlCanvasManager.initElement(canvas)), opts.cornerRadius > 0) {
                            for (var newPoints = [], newPoint, i = 0; i < points.length; i++) "corner" == points[i].type ? (newPoint = betweenPoint(points[i], points[(i - 1) % points.length], opts.cornerRadius), newPoint.type = "arcStart", newPoints[newPoints.length] = newPoint, newPoints[newPoints.length] = points[i], newPoint = betweenPoint(points[i], points[(i + 1) % points.length], opts.cornerRadius), newPoint.type = "arcEnd", newPoints[newPoints.length] = newPoint) : newPoints[newPoints.length] = points[i]
                            points = newPoints
                        }
                        var ctx = canvas.getContext("2d")
                        if (opts.shadow && opts.shadowOverlap !== !0) {
                            var shadowOverlap = numb(opts.shadowOverlap)
                            switch (position) {
                                case "top":
                                    opts.shadowOffsetX + opts.shadowBlur - shadowOverlap > 0 && $box.css("top", numb($box.css("top")) - (opts.shadowOffsetX + opts.shadowBlur - shadowOverlap))
                                    break
                                case "right":
                                    shadowShiftX - shadowOverlap > 0 && $box.css("left", numb($box.css("left")) + shadowShiftX - shadowOverlap)
                                    break
                                case "bottom":
                                    shadowShiftY - shadowOverlap > 0 && $box.css("top", numb($box.css("top")) + shadowShiftY - shadowOverlap)
                                    break
                                case "left":
                                    opts.shadowOffsetY + opts.shadowBlur - shadowOverlap > 0 && $box.css("left", numb($box.css("left")) - (opts.shadowOffsetY + opts.shadowBlur - shadowOverlap))
                            }
                        }
                        if (drawIt.apply(ctx, [points], opts.strokeWidth), ctx.fillStyle = opts.fill, opts.shadow && (ctx.shadowOffsetX = opts.shadowOffsetX, ctx.shadowOffsetY = opts.shadowOffsetY, ctx.shadowBlur = opts.shadowBlur, ctx.shadowColor = opts.shadowColor), ctx.closePath(), ctx.fill(), opts.strokeWidth > 0 && (ctx.shadowColor = "rgba(0, 0, 0, 0)", ctx.lineWidth = opts.strokeWidth, ctx.strokeStyle = opts.strokeStyle, ctx.beginPath(), drawIt.apply(ctx, [points], opts.strokeWidth), ctx.closePath(), ctx.stroke()), opts.preShow.apply(this, [$box[0]]), $box.css({
                                display: "none",
                                visibility: "visible"
                            }), opts.showTip.apply(this, [$box[0]]), opts.overlay) {
                            var overlay = $('<div class="bt-overlay"></div>').css({
                                position: "absolute",
                                backgroundColor: "blue",
                                top: top,
                                left: left,
                                width: width,
                                height: height,
                                opacity: ".2"
                            }).appendTo(offsetParent)
                            $(this).data("overlay", overlay)
                        }(null != opts.ajaxPath && 0 == opts.ajaxCache || ajaxTimeout) && (content = !1), opts.clickAnywhereToClose && (jQuery.bt.vars.clickAnywhereStack.push(this), $(document).click(jQuery.bt.docClick)), opts.closeWhenOthersOpen && jQuery.bt.vars.closeWhenOpenStack.push(this), opts.postShow.apply(this, [$box[0]])
                    }
                }, this.btOff = function () {
                    var t = $(this).data("bt-box")
                    opts.preHide.apply(this, [t])
                    var e = this
                    e.btCleanup = function () {
                        var t = $(e).data("bt-box"),
                            o = $(e).data("bt-content-orig"),
                            s = $(e).data("bt-overlay")
                        if ("object" == typeof t && ($(t).remove(), $(e).removeData("bt-box")), "object" == typeof o) {
                            var i = $(o.original).data("bt-clones")
                            $(o).data("bt-clones", arrayRemove(i, o.clone))
                        }
                        "object" == typeof s && ($(s).remove(), $(e).removeData("bt-overlay")), jQuery.bt.vars.clickAnywhereStack = arrayRemove(jQuery.bt.vars.clickAnywhereStack, e), jQuery.bt.vars.closeWhenOpenStack = arrayRemove(jQuery.bt.vars.closeWhenOpenStack, e), $(e).removeClass("bt-active " + opts.activeClass), opts.postHide.apply(e)
                    }, opts.hideTip.apply(this, [t, e.btCleanup])
                }
                var refresh = this.btRefresh = function () {
                    this.btOff(), this.btOn()
                }
            })
        }, jQuery.fn.btPosition = function () {
            function t(t, e) {
                return t[0] && parseInt(jQuery.css(t[0], e, !0), 10) || 0
            }
            var e
            if (this[0]) {
                var o = this.offsetParent(),
                    s = this.offset(),
                    i = /^body|html$/i.test(o[0].tagName) ? {
                        top: 0,
                        left: 0
                    } : o.offset()
                s.top -= t(this, "marginTop"), s.left -= t(this, "marginLeft"), i.top += t(o, "borderTopWidth"), i.left += t(o, "borderLeftWidth"), e = {
                    top: s.top - i.top,
                    left: s.left - i.left
                }
            }
            return e
        }, jQuery.fn.btOuterWidth = function (t) {
            function e(t, e) {
                return t[0] && parseInt(jQuery.css(t[0], e, !0), 10) || 0
            }
            return this.innerWidth() + e(this, "borderLeftWidth") + e(this, "borderRightWidth") + (t ? e(this, "marginLeft") + e(this, "marginRight") : 0)
        }, jQuery.fn.btOn = function () {
            return this.each(function () {
                jQuery.isFunction(this.btOn) && this.btOn()
            })
        }, jQuery.fn.btOff = function () {
            return this.each(function () {
                jQuery.isFunction(this.btOff) && this.btOff()
            })
        }, jQuery.bt.vars = {
            clickAnywhereStack: [],
            closeWhenOpenStack: []
        }, jQuery.bt.docClick = function (t) {
            if (!t) var t = window.event!$(t.target).parents().addBack().filter(".bt-wrapper, .bt-active").length && jQuery.bt.vars.clickAnywhereStack.length && ($(jQuery.bt.vars.clickAnywhereStack).btOff(), $(document).unbind("click", jQuery.bt.docClick))
        }, jQuery.bt.defaults = {
            trigger: "hover",
            clickAnywhereToClose: !0,
            closeWhenOthersOpen: !1,
            shrinkToFit: !1,
            width: "200px",
            padding: "10px",
            spikeGirth: 10,
            spikeLength: 15,
            overlap: 0,
            overlay: !1,
            killTitle: !0,
            textzIndex: 9999,
            boxzIndex: 9998,
            wrapperzIndex: 9997,
            offsetParent: null,
            positions: ["most"],
            fill: "rgb(255, 255, 102)",
            windowMargin: 10,
            strokeWidth: 2,
            strokeStyle: "#333",
            cornerRadius: 5,
            centerPointX: .5,
            centerPointY: .5,
            shadow: !1,
            shadowOffsetX: 3,
            shadowOffsetY: 3,
            shadowBlur: 8,
            shadowColor: "rgba(51, 51, 51, .9)",
            shadowOverlap: !1,
            noShadowOpts: {
                strokeStyle: "#333"
            },
            cssClass: "",
            cssStyles: {},
            activeClass: "bt-active",
            contentSelector: "$(this).prop('title')",
            ajaxPath: null,
            ajaxError: "<strong>ERROR:</strong> <em>%error</em>",
            ajaxLoading: "<blink>Loading...</blink>",
            ajaxData: {},
            ajaxType: "GET",
            ajaxCache: !0,
            ajaxOpts: {},
            preBuild: function () {},
            preShow: function () {},
            showTip: function (t) {
                $(t).show()
            },
            postShow: function () {},
            preHide: function () {},
            hideTip: function (t, e) {
                $(t).hide(), e()
            },
            postHide: function () {},
            hoverIntentOpts: {
                interval: 300,
                timeout: 500
            }
        }, jQuery.bt.options = {}
    }(jQuery)

// BeautyTips default options
$.bt.options = {
    ajaxType: 'POST',
    boxzIndex: 998,
    cornerRadius: 12,
    fill: '#FFF',
    killTitle: false,
    noShadowOpts: {
        strokeStyle: '#0076C0'
    },
    positions: ['left', 'top'],
    shadow: true,
    spikeGirth: 14,
    spikeLength: 18,
    strokeStyle: '#0076C0',
    textzIndex: 999,
    wrapperzIndex: 997
};


// extend jQuery UI Autocomplete to add search string highlighting to result set
$.ui.autocomplete.prototype._renderItem = function (ul, item) {
    var
        keywords = $.trim(this.term).split(' ').join('|'),
        output = item.label.replace(new RegExp('(' + keywords + ')', 'gi'), '<b>$1</b>');

    return $('<li>').append($('<a>').html(output)).appendTo(ul);
};


// faaModal plugin: acts as a wrapper to jQuery UI Dialog and builds in Ajax functionality
(function ($) {
    'use strict';
    $('<div id="modalDialog" />').appendTo('body');
    $.faaModal = function (toggle, options) {
        var defaults = {
                autoOpen: false, // Boolean: whether the dialog opens on creation or not. It defaults to false for greater control of steps.
                buttons: {}, // Specifies which buttons -- if any -- should be displayed on the dialog.
                dialogClass: '', // Class to apply for specific styling. In addition, a class of "faaModal" is automatically applied to the dialog.
                draggable: false, // Boolean. Defaults to false because of a known bug in jQuery UI 1.10.4
                height: 'auto', // Height of the dialog. If set to a numerical value, it will override minHeight and maxHeight.
                innerHtml: '', // Initial content for the dialog
                loadCallback: null, // Ajax: callback function after the load() event
                loadData: {}, // Ajax: object or string sent back to the server
                loadUrl: '', // Ajax: URL from which to load data
                maxHeight: 600, // Maximum height of the dialog. The content will scroll if it overflows this height.
                minHeight: 371, // Minimum height of the dialog. (golden ratio FTW)
                modal: true, // Boolean: darkens the area behind the dialog and limits interaction to the dialog.
                position: { // Object: defaults to horizontally and vertically centered
                    my: 'center',
                    at: 'center',
                    of: window
                },
                resizable: false, // Boolean
                target: '#modalDialog', // Query selector of target dialog element
                title: '', // Title of the dialog
                width: 600 // Width of the dialog
            },
            options = $.extend(defaults, options || {});

        // empty any existing content, then populate
        $(options.target).empty().html(function () {
            // if innerHtml is specified
            if (options.innerHtml.length) {
                return options.innerHtml;
            }
            // if Ajax URL is specified
            else if (options.loadUrl.length) {
                $(this).load(options.loadUrl, options.loadData, options.loadCallback);
            }
        });

        // If we want to create the dialog (which will be pretty much always, however we reserve the ability to use FALSE if needed)
        if (toggle) {
            $(options.target).dialog({
                autoOpen: options.autoOpen,
                buttons: options.buttons,
                close: function () {
                    // empty dialog content
                    $(this).empty();

                    // remove desaturation
                    $('.header, .header + .templateContainer, .footer').removeClass('desaturate');
                    $('.forYou > ul, .hNav > ul > li > div').removeClass('visuallyHidden');
                },
                closeText: '&times;', // replace 'Close' with multiplication sign
                dialogClass: 'faaModal ' + options.dialogClass,
                draggable: options.draggable,
                height: options.height,
                hide: 'fade',
                maxHeight: options.maxHeight,
                minHeight: options.minHeight,
                modal: options.modal,
                open: function () {
                    // give close icon better tooltip text
                    $('.ui-dialog-titlebar-close').attr('title', 'Close');

                    // add desaturation
                    $('.header, .header + .templateContainer, .footer').addClass('desaturate');
                    $('.forYou > ul, .hNav > ul > li > div').addClass('visuallyHidden');
                },
                position: options.position,
                resizable: options.resizable,
                show: 'fade',
                title: options.title,
                width: options.width
            });
        }
    };
}(jQuery));


// preload images
(function ($) {
    'use strict';
    $.preloadImages = function () {
        var args_len = arguments.length,
            cache = [],
            i = 0;

        for (i; i < args_len; i++) {
            var cacheImage = document.createElement('img');
            cacheImage.src = arguments[i];
            cache.push(cacheImage);
        }
    };
}(jQuery));


/*! http://mths.be/placeholder v2.1.2 by @mathias */
! function (a) {
    "function" == typeof define && define.amd ? define(["jquery"], a) : a("object" == typeof module && module.exports ? require("jquery") : jQuery)
}(function (a) {
    function b(b) {
        var c = {},
            d = /^jQuery\d+$/;
        return a.each(b.attributes, function (a, b) {
            b.specified && !d.test(b.name) && (c[b.name] = b.value)
        }), c
    }

    function c(b, c) {
        var d = this,
            f = a(d);
        if (d.value == f.attr("placeholder") && f.hasClass(m.customClass))
            if (f.data("placeholder-password")) {
                if (f = f.hide().nextAll('input[type="password"]:first').show().attr("id", f.removeAttr("id").data("placeholder-id")), b === !0) return f[0].value = c;
                f.focus()
            } else d.value = "", f.removeClass(m.customClass), d == e() && d.select()
    }

    function d() {
        var d, e = this,
            f = a(e),
            g = this.id;
        if ("" === e.value) {
            if ("password" === e.type) {
                if (!f.data("placeholder-textinput")) {
                    try {
                        d = f.clone().prop({
                            type: "text"
                        })
                    } catch (h) {
                        d = a("<input>").attr(a.extend(b(this), {
                            type: "text"
                        }))
                    }
                    d.removeAttr("name").data({
                        "placeholder-password": f,
                        "placeholder-id": g
                    }).bind("focus.placeholder", c), f.data({
                        "placeholder-textinput": d,
                        "placeholder-id": g
                    }).before(d)
                }
                f = f.removeAttr("id").hide().prevAll('input[type="text"]:first').attr("id", g).show()
            }
            f.addClass(m.customClass), f[0].value = f.attr("placeholder")
        } else f.removeClass(m.customClass)
    }

    function e() {
        try {
            return document.activeElement
        } catch (a) {}
    }
    var f, g, h = "[object OperaMini]" == Object.prototype.toString.call(window.operamini),
        i = "placeholder" in document.createElement("input") && !h,
        j = "placeholder" in document.createElement("textarea") && !h,
        k = a.valHooks,
        l = a.propHooks;
    if (i && j) g = a.fn.placeholder = function () {
        return this
    }, g.input = g.textarea = !0;
    else {
        var m = {};
        g = a.fn.placeholder = function (b) {
            var e = {
                customClass: "placeholder"
            };
            m = a.extend({}, e, b);
            var f = this;
            return f.filter((i ? "textarea" : ":input") + "[placeholder]").not("." + m.customClass).bind({
                "focus.placeholder": c,
                "blur.placeholder": d
            }).data("placeholder-enabled", !0).trigger("blur.placeholder"), f
        }, g.input = i, g.textarea = j, f = {
            get: function (b) {
                var c = a(b),
                    d = c.data("placeholder-password");
                return d ? d[0].value : c.data("placeholder-enabled") && c.hasClass(m.customClass) ? "" : b.value
            },
            set: function (b, f) {
                var g = a(b),
                    h = g.data("placeholder-password");
                return h ? h[0].value = f : g.data("placeholder-enabled") ? ("" === f ? (b.value = f, b != e() && d.call(b)) : g.hasClass(m.customClass) ? c.call(b, !0, f) || (b.value = f) : b.value = f, g) : b.value = f
            }
        }, i || (k.input = f, l.value = f), j || (k.textarea = f, l.value = f), a(function () {
            a(document).delegate("form", "submit.placeholder", function () {
                var b = a("." + m.customClass, this).each(c);
                setTimeout(function () {
                    b.each(d)
                }, 10)
            })
        }), a(window).bind("beforeunload.placeholder", function () {
            a("." + m.customClass).each(function () {
                this.value = ""
            })
        })
    }
});
$('input, textarea').placeholder();


/* FlowType.JS v1.1 */
! function (n) {
    n.fn.flowtype = function (i) {
        var m = n.extend({
                maximum: 960,
                minimum: 314,
                maxFont: 26,
                minFont: 13,
                fontRatio: 35
            }, i),
            t = function (i) {
                var t = n(i),
                    o = t.width(),
                    u = o > m.maximum ? m.maximum : o < m.minimum ? m.minimum : o,
                    a = u / m.fontRatio,
                    f = a > m.maxFont ? m.maxFont : a < m.minFont ? m.minFont : a
                t.css("font-size", f + "px")
            }
        return this.each(function () {
            var i = this
            n(window).resize(function () {
                t(i)
            }), t(this)
        })
    }
}(jQuery)
$('.maxMeasure').flowtype();


// document search validation
// Found on: Air Traffic homepage; Modals: N-number, Orders & Notices, Advisory Circulars;
$.fn.validateDocumentSearchForm = function (e) {
    var
        searchCriteriaField = $("#wfq"),
        messageContainer = $("#messageContainer"),
        displayStatusField = $("#display").val(),

        // If the document search is for Orders/Notices then set the flag to TRUE, otherwise FALSE.
        cancelledRequiresCriteria = (searchCriteriaField.parents("#searchOrdersNotices").length > 0) ? true : false,

        // Set the default text
        defaultText = 'Search Content, Number, Title, Description, or Office',

        // Is the current value the default text?
        isDefault = (searchCriteriaField.val() === defaultText) ? true : false,

        // If it isn't the default text, is it greater than 3 chars?
        isEnoughChars = (!isDefault && searchCriteriaField.val().length >= 3) ? true : false,

        // Default to VALID
        isValidated = true,

        // Param the error string
        errorMessage = '';

    // Remove any existing error messages
    $("#docSearchError").remove();

    searchCriteriaField.removeClass("error");
    // INVALID if cancelled requires criteria, and status selected includes cancelled docs, and the search criteria is the default text or less than 3 chars
    if (cancelledRequiresCriteria && (isDefault || !isEnoughChars) && displayStatusField !== 'current') {
        isValidated = false;
        errorMessage = errorMessage + '<p>Due to the large number of cancelled documents, please limit your search by typing text or a number (at least 3 characters).</p>';
    }
    // INVALID if the search criteria is NOT the default text and NOT greater than 3 chars
    if (!isDefault && !isEnoughChars) {
        isValidated = false;
        errorMessage = errorMessage + '<p>To search within all current documents, you must type at least 3 characters.</p>';
    }
    // If INVALID, display error field and stop processing.
    if (!isValidated) {

        // display errors
        messageContainer.addClass("error").removeClass("lightGrey");
        $("<div/>").attr("id", "docSearchError").addClass("message-box failure").html(errorMessage).prependTo("#messageContainer");

    } else { // If VALID then get on with your bad self.
        return true;
    }
};


// on DOM ready
$(function () {

    if (!!window.matchMedia) {
        $(window).on('load resize', function () {
            if (window.matchMedia("(max-width: 530px)").matches) {
                // keep relatively narrow images and imageFormat() divs floated at narrow viewport widths
                $('.content').find('img.left, img.right, .image.left, .image.right').each(function () {
                    if (($(this).outerWidth(true) + 130) < $(this).parents('div').width()) {
                        $(this).addClass('keepFloated');
                    } else {
                        $(this).removeClass('keepFloated');
                    }
                });
            }
        });
    }


    // essentially IE 8 and below
    if (!document.getElementsByClassName) {
        // striped table rows and form rows
        $('.striped > tbody > tr:nth-child(odd)').removeClass('alt-bg altBg');
        $('.striped > tbody > tr:nth-child(even)').addClass('altBg');
        $('form.layout.striped .formRow:nth-child(odd)').removeClass('alt-bg altBg');
        $('form.layout.striped .formRow:nth-child(even)').addClass('altBg');
    }

    // documentViewer fallback
    var documentTypes = {
        'doc': 'MS Word',
        'DOC': 'MS Word',
        'docm': 'MS Word',
        'DOCM': 'MS Word',
        'docx': 'MS Word',
        'DOCX': 'MS Word',
        'dot': 'MS Word',
        'DOT': 'MS Word',
        'rtf': 'MS Word',
        'RTF': 'MS Word',
        'mp3': 'MP3',
        'MP3': 'MP3',
        'pdf': 'PDF',
        'PDF': 'PDF',
        'pps': 'MS PowerPoint',
        'PPS': 'MS PowerPoint',
        'ppsx': 'MS PowerPoint',
        'PPSX': 'MS PowerPoint',
        'ppt': 'MS PowerPoint',
        'PPT': 'MS PowerPoint',
        'pptx': 'MS PowerPoint',
        'PPTX': 'MS PowerPoint',
        'wav': 'WAV',
        'WAV': 'WAV',
        'wmv': 'WMV',
        'WMV': 'WMV',
        'xls': 'MS Excel',
        'XLS': 'MS Excel',
        'xlsx': 'MS Excel',
        'XLSX': 'MS Excel',
        'zip': 'Zip',
        'ZIP': 'Zip'
    };
    $.each(documentTypes, function (key, value) {
        var matchText = new RegExp('(?:' + key + '|' + value + '|' + value.replace("MS ", "") + ')\\b', 'i');

        // fallback for instances that the CSS fallback can't yet reach
        $('a[href$=".' + key + '"]:not(:last-child)').each(function () {
            if ($(this).next(':not(.small):not(small)').length && !$(this).has('img').length && !$(this).text().match(matchText)) {
                $('<small>&nbsp;(' + value + ')</small>').insertAfter(this);
            }
        });

        // tweak targeting of overzealous CSS fallback
        $('a[href$=".' + key + '"]:last-child').each(function () {
            if ($(this).text().match(matchText) || ($(this)[0].nextSibling && $(this)[0].nextSibling.nodeValue.match(matchText)) || $(this).has('img').length) {
                $('<span />').insertAfter(this);
            }
        });
    });


    // page tools
    $('.pageTools')
        // print link
        .on('click', '.print', function (e) {
            e.preventDefault();
            window.print();
        })

    // share module
    .on('click', '.share', function (e) {
            e.preventDefault();
            $('+ li', this).slideToggle('fast');
        })
        .find('.share a').attr('title', 'Share this page');

    $('.share + li').on('click', 'a', function (e) {
        e.preventDefault();
        open(this.href, 'share_window', 'width=800,height=500,top=100,menubar=yes,location=yes,resizable=yes,scrollbars=yes,status=yes');
    });


    // give tabindex to table rows that have hover/focus styles
    $('table.hover tbody > tr').attr('tabindex', 0);


    // external link dialog
    var exitLinks = $('[href^="/exit/"]');
    $(exitLinks).has('img').addClass('descendantImage');
    $('.templateContainer').find(exitLinks).on('click', function (e) {
        e.preventDefault();
        $.faaModal(true, {
            autoOpen: true,
            dialogClass: $(this).attr('class'),
            loadUrl: this.href + ' #content',
            title: 'You are about to leave ' + window.location.hostname + '.',
            width: 525
        });
    });


    // remove 'index.cfm' from url when we're able to
    var indexRegex = new RegExp('/index\\.cfml?(?=$|\\?)', 'i'),
        combinedPath = window.location.pathname + window.location.search;
    if (history.replaceState && indexRegex.test(combinedPath)) {
        history.replaceState({
            awesome: 'true'
        }, '', combinedPath.replace(indexRegex, '/') + window.location.hash);
    }


    // add intra-page anchor for CF debugging output on dev tier
    if ($('table.cfdebug').length) {
        $('table.cfdebug')[0].id = 'cfdebug';
    }


    // autocomplete
    var searchTerms = [
		'acquisition',
		'administrator',
		'advisories',
		'Advisory Circulars (ACs)',
		'Aeronautical Information Manual (AIM)',
		'Aerospace Medical Certification Subsystem (AMCS)',
		'Air Defense Identification Zone (ADIZ)',
		'air traffic control',
		'air traffic controller',
		'Air Transportation Oversight System (ATOS)',
		'Aircraft Registration',
		'aircraft',
		'Airframe & Powerplant (A&P)',
		'airframe',
		'Airline Certification (Title 14 CFR Part 135)',
		'Airmen Practical Test Standards (PTS)',
		'Airplane Flying Handbook (FAA-H-8083-3A)',
		'airport diagrams',
		'airports',
		'airspace',
		'Airworthiness Directives (ADs)',
		'alcohol',
		'Automatic Dependent Surveillance Broadcast (ADS-B)',
		'Aviation Medical Examiner (AME)',
		'Aviation Safety Action Program (ASAP)',
		'aviation weather',
		'avionics',
		'bird strike',
		'carry-on',
		'centerline',
		'change of address',
		'charts',
		'clearances',
		'cockpit',
		'contractions',
		'definitions',
		'Designated Airworthiness Representative (DAR)',
		'Designated Engineering Representative (DER)',
		'Designated Mechanic Examiner (DME)',
		'Designated Pilot Examiner (DPE)',
		'designee',
		'Digital Airport/Facility Directory (d -A/FD)',
		'directory',
		'dispatcher',
		'email',
		'Emergency Locator Transmitters (ELTs)',
		'employee directory',
		'employee express',
		'employees',
		'employment',
		'English Proficiency',
		'Extended-range Twin-engine Operational Performance Standards (ETOPS)',
		'FAA Safety Team (FAAST)',
		'FAA-H-8083-25A, Pilot\'s Handbook of Aeronautical Knowledge',
		'familiarization',
		'FAR 121, Air Carrier Certification Process (Title 14 CFR Part 121)',
		'FAR 145, Repair Stations (Title 14 CFR Part 145)',
		'FAR 25, Airworthiness Standards: Transport Category Airplanes (Title 14 CFR Part 25)',
		'FAR 43, Maintenance, Preventive Maintenance, Rebuilding, and Alteration (Title 14 CFR Part 43)',
		'FAR 61, Certification: Pilots, Flight Instructors, and Ground Instructors (Title 14 CFR Part 61)',
		'Federal Aviation Regulations (FARs)',
		'flight attendant',
		'flight plan',
		'Flight Standards District Office (FSDO)',
		'Form 337, Major Repair and Alteration',
		'Form 7233-1, Flight Plan',
		'Form 7460-1, Notice of Proposed Construction or Alteration',
		'Form 7460-2, Notice of Actual Construction or Alteration',
		'Form 8050-1, Aircraft Registration Application',
		'Form 8050-2, Aircraft Bill of Sale',
		'Form 8110-3, Statement of Compliance with the Federal Aviation Regulations',
		'Form 8130-3, Authorized Release Certificate',
		'Form 8130-6, Application for U.S. Airworthiness Certificate',
		'Form 8130-9, Statement of Conformity',
		'Form 8610-1, Mechanic\'s Application for Inspection Authorization',
		'Form 8610-2, Airmen Certification and/or Rating Application',
		'Form 8710-1, Airman Certificate and/or Rating Application',
		'forms',
		'General Operating and Flight Rules (Title 14 CFR Part 91)',
		'handbook',
		'helicopter',
		'human factors',
		'inspection authorization',
		'Instrument Flying Handbook (FAA-H-8083-15)',
		'Integrated Airman Certification and/or Rating Application (IACRA)',
		'jobs',
		'Joint Planning and Development Office (JPDO)',
		'launch',
		'liquids',
		'Local Area Augmentation System (LAAS)',
		'Master Minimum Equipment List (MMEL)',
		'mechanics',
		'medical certificate',
		'medical examiners',
		'medical',
		'medications',
		'MedXpress',
		'Mike Monroney Aeronautical Center (MMAC)',
		'modernization',
		'National Airspace System (NAS)',
		'National Plan of Integrated Airport Systems (NPIAS)',
		'New Employee Onboarding',
		'NextGen',
		'N-Numbers',
		'Notices of Proposed Rulemaking (NPRM)',
		'Notices to Airmen (NOTAMs)',
		'Operational Evolution Partnership (OEP)',
		'Order 7110.65, Air Traffic Control',
		'Order 8100.8, Designee Management Handbook',
		'Order 8110.4, Type Certification',
		'Order 8130.21, Procedures for Completion and Use of the Authorized Release Certificate',
		'Order 8130.2F, Airworthiness Certification of Aircraft and Related Products',
		'Order 8900.1, Flight Standards Information Management System (FSIMS)',
		'Order 8900.2, General Aviation Airman Designee Handbook',
		'oversight',
		'parachute',
		'Parts Manufacturer Approval (PMA)',
		'Pilot Proficiency Award Program (WINGS)',
		'preflight',
		'publications',
		'Reduced Vertical Separation Minimum (RVSM)',
		'registration',
		'Regulatory and Guidance Library (RGL)',
		'repair stations',
		'Required Navigation Performance (RNP)',
		'rotorcraft',
		'Runway Safety',
		'Safety Management Systems (SMS)',
		'scholarships',
		'service bulletins',
		'Service Difficulty Reporting (SDR)',
		'SFAR 88, Fuel Tank System Fault Tolerance Evaluation Requirements',
		'Special Airworthiness Information Bulletins (SAIB)',
		'sport pilot',
		'Supplemental Type Certificates (STC)',
		'Suspected Unapproved Parts (SUP)',
		'takeoff',
		'Technical Standard Orders (TSO)',
		'Temporary Flight Restrictions (TFRs)',
		'Terminal Instrument Procedures (TERPS)',
		'Title 14, Code of Federal Regulations (14 CFR)',
		'Traffic Collision and Avoidance System (TCAS)',
		'training',
		'Type Certificate Data Sheets (TCDS)',
		'type certificate',
		'Unmanned Aircraft Systems (UAS)',
		'weather',
		'Wide Area Augmentation System (WAAS)'
	],
        searchInputs = $('#q, #googleQ01, #googleQ02');

    // autocomplete: template search form and search results page search forms
    searchInputs
        .autocomplete({
            source: searchTerms,
            select: function (event, ui) {
                $(this).val(ui.item.value).parents('form').submit();
            },
            minLength: 2,
            close: function () {
                // prevent close (for testing):
                if (!$('.ui-autocomplete').is(':visible')) {
                    // $('.ui-autocomplete').show();
                }
            },
            create: function () {
                $(this).attr('aria-haspopup', 'true');
            }
        })
        .focus(function () {
            // show the menu if the search input regains focus
            $(this).data('ui-autocomplete').search($(this).val());
        });

    // hide the autocomplete menu on overlapping nav dropdowns
    $('#hNav li:nth-child(n+4), .forYou').on('mouseenter', function () {
        if (!!$($(searchInputs).autocomplete('widget')).is(':visible')) {
            $(searchInputs).animate({
                opacity: 0
            }, 400, function () {
                searchInputs.autocomplete('close').blur();
                // restore opacity in case it opens again
                $(this).css('opacity', 1);
            });
        }
    });


    // keyboard accessible dropdown links
    $('#hNav > ul > li > a').on('focus', function () {
        $('#hNav > ul > li > a').removeClass('descendantFocus');
        $(this).addClass('descendantFocus');
    });
    $('.forYou > a').on('focus', function () {
        $(this).addClass('descendantFocus');
    });

    $(document).on('focusin', function () { // listen for all focus events
        if ($(document.activeElement).parents('#hNav').length === 0) {
            $('#hNav a').removeClass('descendantFocus');
        }

        if ($(document.activeElement).parents('.forYou').length === 0) {
            $('.forYou > a').removeClass('descendantFocus');
        }

        // IE8 redraw
        if (!document.getElementsByClassName) {
            $('body').addClass('stupidIE').removeClass('stupidIE');
        }
    });


    // hash-related behavior
    (function ($) {
        var
            targetOffset = 10,
            scrollUp = function (scrollValue) {
                $('html, body').animate({
                    scrollTop: scrollValue
                }, {
                    duration: 800,
                    easing: 'easeOutExpo'
                });
            },
            scrollValue = 0;

        $(window).on('hashchange load', function () {

            var hashValue = location.hash.substring(1);

            if (hashValue) {
                var element = document.getElementById(hashValue);

                if (element) {

                    // scroll up slightly after hashchange
                    // keep page title in view for "Skip to page content" link
                    if (location.hash === '#content' && $('.hGroup').length) {
                        scrollValue = $('.hGroup').offset().top;
                    } else {
                        scrollValue = $(element).offset().top;
                    }

                    scrollValue -= targetOffset;
                    scrollUp(scrollValue);

                    // change keyboard focus based on visual focus
                    if (!/^(?:a|button|input|select|textarea)$/i.test(element.tagName)) {
                        element.tabIndex = -1;
                    }

                }
            }
        });

        // scroll up after certain focus events
        $(document).on('focusin', 'a', function () {
            if ($(':focus').length && $(':focus')[0].getBoundingClientRect().top < (targetOffset)) {
                scrollValue = $(':focus').offset().top - (targetOffset);
                scrollUp(scrollValue);
            }
        });
    })(jQuery);


    // add close button to message boxes and page messages
    $('.message-box, .pageMessage').not('.noClose').not(':has(a[class~="close"])').each(function () {
        $('<a class="close" href="#" aria-label="Close" title="Close">&times;</a>').prependTo(this);
    });
    $(document).on('click', '.message-box > .close, .pageMessage > .close', function (e) {
        e.preventDefault();
        $(this).parent().slideUp('fast');
    });


    // hide 1px x 1px ForeSee Flash container
    // TODO: replace setTimeout with mutationobserver: https://github.com/ryanmorr/ready/blob/master/ready.js
    $(window).load(function () {
        var hideForeSee = function () {
            $('#_fsr_swfContainerv2').addClass('visuallyHidden');
        };
        setTimeout(hideForeSee, 500);
    });


    // Modal: N-number
    // Found on Aircraft page; Pilots portal; N-numbers page; Top Tasks: Aircraft, Aircraft Certification, Licenses & Certificates
    $('.modal.search.nNumber').on('click', function (e) {
        e.preventDefault();

        $.faaModal(true, {
            autoOpen: true,
            loadUrl: '/widgets/n-number/ajax/ #ajaxContent',
            loadCallback: function () {
                // Toggle div: format help
                $('#nNumberWidget').on('click', 'a', function (e) {
                    e.preventDefault();
                    $('#nNumberFormat').slideToggle('fast');
                });
            },
            minHeight: 247,
            title: 'Look up an N-Number',
            width: 400
        });
    });


    // Modal: Orders and Notices
    // Found on: Regulations & Policies page; Top Tasks: Regulations & Policies
    $('.modal.search.ordersNotices').on('click', function (e) {
        e.preventDefault();

        var
            searchType = "Orders & Notices",
            subset = " #searchOrdersNotices",
            url = $(this).attr("href"),
            callback = function () {
                // add link
                $("<p/>").html('Or, you can <a href="' + url + '">browse all ' + searchType + '</a>.').insertAfter($.trim(subset));

                // autocomplete
                $('#searchOrdersNotices #wfq').autocomplete({
                    source: '/regulations_policies/orders_notices/index.cfm/go/document.documentJSString',
                    select: function (event, ui) {
                        if (ui.item) {
                            $(this).val(ui.item.value);
                            $("#documentNumber").val(ui.item.value);
                        }

                        $(this).parents('form').submit();

                        $("#documentNumber").val();
                    },
                    minLength: 2,
                    open: function () {
                        $('.ui-autocomplete').removeClass('ui-corner-all');
                    }
                });

                // validate search criteria
                $("#searchOrdersNotices").on('submit', function (e) {
                    if (!$.fn.validateDocumentSearchForm()) {
                        e.preventDefault();
                    }
                });
            };

        $.faaModal(true, {
            autoOpen: true,
            loadCallback: callback,
            loadUrl: url + subset,
            minHeight: '336',
            title: 'Search ' + searchType,
            width: '544'
        });
    });


    // Modal: Advisory Circulars
    // Found on: Pilots Portal; Regulations & Policies page; Top Tasks: Airports
    $('.modal.search.advisoryCirculars').on('click', function (e) {
        e.preventDefault();

        var
            searchType = "Advisory Circulars",
            subset = " #searchAdvisoryCirculars",
            url = this.href,
            callback = function () {
                // add link
                $("<p/>").html('Or, you can <a href="' + url + '">browse all ' + searchType + '</a>.').insertAfter($.trim(subset));

                // autocomplete
                $("#wfq").autocomplete({
                    source: '/regulations_policies/advisory_circulars/index.cfm/go/document.documentJSString',
                    minLength: 2,
                    open: function () {
                        $('.ui-autocomplete').removeClass('ui-corner-all');
                    },
                    select: function (event, ui) {

                        $("#documentNumber").val(ui.item.value);

                        if (ui.item.label.indexOf('CANCELLED') > 0) {
                            $("#display").val('all');
                        }

                        $(this).parents('form').submit();
                    }
                });

                // validate search criteria
                $("#searchAdvisoryCirculars").on('submit', function (e) {
                    if (!$.fn.validateDocumentSearchForm()) {
                        e.preventDefault();
                    }
                });
            };

        $.faaModal(true, {
            autoOpen: true,
            loadCallback: callback,
            loadUrl: url + subset,
            title: 'Search ' + searchType,
            width: '544',
            minHeight: '336'
        });
    });


    // Omniture tracking
    $('.siteLogo').attr('name', '&lid=Site Logo&lpos=Site Logo');

    $('.topNav').find('a').each(function () {
        $(this).attr('name', function () {
            return '&lid=Top Nav: ' + $(this).text() + '&lpos=Top Nav';
        });
    });

    $('#hNav').find('a').each(function () {
        $(this).attr('name', function () {
            return '&lid=Horizontal Nav: ' + $(this).text() + '&lpos=Horizontal Nav';
        });
    });

    $('#footer').find('a').each(function () {
        $(this).attr('name', function () {
            return '&lid=Footer: ' + $(this).text() + '&lpos=Footer';
        });
    });

}); // ready close
