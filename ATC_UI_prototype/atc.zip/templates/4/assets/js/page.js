
$(function () {

	// Toggle form classes
	$('#toggleLayout').bind('click', function () {
		$('#sampleForm, #form-section + h3 > code > span:nth-child(1)').toggleClass('layout');
	});
	$('#toggleStriping').bind('click', function () {
		$('#sampleForm, #form-section + h3 > code > span:nth-child(2)').toggleClass('striped');
	});

	/* jQuery UI datepicker */
	$('.datepicker').datepicker();

	/* jQuery UI modals */
	$(document)
		.on('click', '#ajax-modal', function (e) {
			var that = this;

			e.preventDefault();

			$.faaModal(true, {
				autoOpen: true,
				loadUrl: 'ajax.html',
				loadCallback: function () {
					console.log('callback for ' + that.id);
				},
				title: 'ajax content, modal',
				dialogClass: this.id,
				width: 600,
				minHeight: 162,
				modal: true
			});
		})

		.on('click', '#ajax-non-modal', function (e) {
			var that = this;

			e.preventDefault();

			$.faaModal(true, {
				autoOpen: true,
				loadUrl: 'ajax.html',
				loadCallback: function () {
					console.log('callback for ' + that.id);
				},
				title: 'ajax content, non-modal',
				dialogClass: this.id,
				width: 600,
				minHeight: 162,
				modal: false
			});
		})

		.on('click', '#same-page-modal', function (e) {
			var paragraph = $('#tab-1').contents().clone();

			e.preventDefault();

			$.faaModal(true, {
				autoOpen: true,
				height: 200,
				innerHtml: paragraph,
				modal: true,
				position: {
					my: 'right top',
					at: 'right bottom',
					of: $(this)
				},
				title: 'same-page content, modal',
				width: 300
			});
		})

		.on('click', '#same-page-non-modal', function (e) {
			var paragraph = $('#tab-1').contents().clone();

			e.preventDefault();

			$.faaModal(true, {
				autoOpen: true,
				height: 200,
				innerHtml: paragraph,
				modal: false,
				position: {
					my: 'right top',
					at: 'right bottom',
					of: $(this)
				},
				title: 'same-page content, non-modal',
				width: 300
			});
		})

		.on('click', '#generated-modal', function (e) {
			e.preventDefault();

			$.faaModal(true, {
				autoOpen: true,
				height: 200,
				innerHtml: 'This here is text from JS!',
				modal: true,
				position: {
					my: 'right top',
					at: 'right bottom',
					of: $(this)
				},
				title: 'generated content, modal',
				width: 300
			});
		})

		.on('click', '#generated-non-modal', function (e) {
			e.preventDefault();

			$.faaModal(true, {
				autoOpen: true,
				height: 200,
				innerHtml: 'This here is text from JS!',
				modal: false,
				position: {
					my: 'right top',
					at: 'right bottom',
					of: $(this)
				},
				title: 'generated content, non-modal',
				width: 300
			});
		})

        .ready(function () {
        /* set 'here' class on current page item in sidenav - used to show current nav selection. GC*/
        var url = window.location.pathname;
        var filename = url.substring(url.lastIndexOf('/') + 1);
        $('#subvNav li a').each(function () {
            if (filename == $(this).attr('href')) {
                $(this).addClass('here');
            }
        });
    });

	/* jQuery UI tabs */
	$('.tabs').tabs();

	/* jQuery UI tooltip */
	$('.content a[title]').tooltip();

	// jQuery Colorbox
	$('.group1').colorbox({ rel: 'group1' });

});
