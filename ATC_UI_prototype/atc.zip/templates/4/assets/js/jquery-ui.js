! function (e, t) {
    function s(t, i) {
        var n, s, a, o = t.nodeName.toLowerCase();
        return "area" === o ? (n = t.parentNode, s = n.name, t.href && s && "map" === n.nodeName.toLowerCase() ? (a = e("img[usemap=#" + s + "]")[0], !!a && r(a)) : !1) : (/input|select|textarea|button|object/.test(o) ? !t.disabled : "a" === o ? t.href || i : i) && r(t)
    }

    function r(t) {
        return e.expr.filters.visible(t) && !e(t).parents().addBack().filter(function () {
            return "hidden" === e.css(this, "visibility")
        }).length
    }
    var i = 0,
        n = /^ui-id-\d+$/;
    e.ui = e.ui || {}, e.extend(e.ui, {
        version: "1.10.4",
        keyCode: {
            BACKSPACE: 8,
            COMMA: 188,
            DELETE: 46,
            DOWN: 40,
            END: 35,
            ENTER: 13,
            ESCAPE: 27,
            HOME: 36,
            LEFT: 37,
            NUMPAD_ADD: 107,
            NUMPAD_DECIMAL: 110,
            NUMPAD_DIVIDE: 111,
            NUMPAD_ENTER: 108,
            NUMPAD_MULTIPLY: 106,
            NUMPAD_SUBTRACT: 109,
            PAGE_DOWN: 34,
            PAGE_UP: 33,
            PERIOD: 190,
            RIGHT: 39,
            SPACE: 32,
            TAB: 9,
            UP: 38
        }
    }), e.fn.extend({
        focus: function (t) {
            return function (i, n) {
                return "number" == typeof i ? this.each(function () {
                    var t = this;
                    setTimeout(function () {
                        e(t).focus(), n && n.call(t)
                    }, i)
                }) : t.apply(this, arguments)
            }
        }(e.fn.focus),
        scrollParent: function () {
            var t;
            return t = e.ui.ie && /(static|relative)/.test(this.css("position")) || /absolute/.test(this.css("position")) ? this.parents().filter(function () {
                return /(relative|absolute|fixed)/.test(e.css(this, "position")) && /(auto|scroll)/.test(e.css(this, "overflow") + e.css(this, "overflow-y") + e.css(this, "overflow-x"))
            }).eq(0) : this.parents().filter(function () {
                return /(auto|scroll)/.test(e.css(this, "overflow") + e.css(this, "overflow-y") + e.css(this, "overflow-x"))
            }).eq(0), /fixed/.test(this.css("position")) || !t.length ? e(document) : t
        },
        zIndex: function (i) {
            if (i !== t) return this.css("zIndex", i);
            if (this.length)
                for (var s, r, n = e(this[0]); n.length && n[0] !== document;) {
                    if (s = n.css("position"), ("absolute" === s || "relative" === s || "fixed" === s) && (r = parseInt(n.css("zIndex"), 10), !isNaN(r) && 0 !== r)) return r;
                    n = n.parent()
                }
            return 0
        },
        uniqueId: function () {
            return this.each(function () {
                this.id || (this.id = "ui-id-" + ++i)
            })
        },
        removeUniqueId: function () {
            return this.each(function () {
                n.test(this.id) && e(this).removeAttr("id")
            })
        }
    }), e.extend(e.expr[":"], {
        data: e.expr.createPseudo ? e.expr.createPseudo(function (t) {
            return function (i) {
                return !!e.data(i, t)
            }
        }) : function (t, i, n) {
            return !!e.data(t, n[3])
        },
        focusable: function (t) {
            return s(t, !isNaN(e.attr(t, "tabindex")))
        },
        tabbable: function (t) {
            var i = e.attr(t, "tabindex"),
                n = isNaN(i);
            return (n || i >= 0) && s(t, !n)
        }
    }), e("<a>").outerWidth(1).jquery || e.each(["Width", "Height"], function (i, n) {
        function o(t, i, n, r) {
            return e.each(s, function () {
                i -= parseFloat(e.css(t, "padding" + this)) || 0, n && (i -= parseFloat(e.css(t, "border" + this + "Width")) || 0), r && (i -= parseFloat(e.css(t, "margin" + this)) || 0)
            }), i
        }
        var s = "Width" === n ? ["Left", "Right"] : ["Top", "Bottom"],
            r = n.toLowerCase(),
            a = {
                innerWidth: e.fn.innerWidth,
                innerHeight: e.fn.innerHeight,
                outerWidth: e.fn.outerWidth,
                outerHeight: e.fn.outerHeight
            };
        e.fn["inner" + n] = function (i) {
            return i === t ? a["inner" + n].call(this) : this.each(function () {
                e(this).css(r, o(this, i) + "px")
            })
        }, e.fn["outer" + n] = function (t, i) {
            return "number" != typeof t ? a["outer" + n].call(this, t) : this.each(function () {
                e(this).css(r, o(this, t, !0, i) + "px")
            })
        }
    }), e.fn.addBack || (e.fn.addBack = function (e) {
        return this.add(null == e ? this.prevObject : this.prevObject.filter(e))
    }), e("<a>").data("a-b", "a").removeData("a-b").data("a-b") && (e.fn.removeData = function (t) {
        return function (i) {
            return arguments.length ? t.call(this, e.camelCase(i)) : t.call(this)
        }
    }(e.fn.removeData)), e.ui.ie = !!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase()), e.support.selectstart = "onselectstart" in document.createElement("div"), e.fn.extend({
        disableSelection: function () {
            return this.bind((e.support.selectstart ? "selectstart" : "mousedown") + ".ui-disableSelection", function (e) {
                e.preventDefault()
            })
        },
        enableSelection: function () {
            return this.unbind(".ui-disableSelection")
        }
    }), e.extend(e.ui, {
        plugin: {
            add: function (t, i, n) {
                var s, r = e.ui[t].prototype;
                for (s in n) r.plugins[s] = r.plugins[s] || [], r.plugins[s].push([i, n[s]])
            },
            call: function (e, t, i) {
                var n, s = e.plugins[t];
                if (s && e.element[0].parentNode && 11 !== e.element[0].parentNode.nodeType)
                    for (n = 0; n < s.length; n++) e.options[s[n][0]] && s[n][1].apply(e.element, i)
            }
        },
        hasScroll: function (t, i) {
            if ("hidden" === e(t).css("overflow")) return !1;
            var n = i && "left" === i ? "scrollLeft" : "scrollTop",
                s = !1;
            return t[n] > 0 ? !0 : (t[n] = 1, s = t[n] > 0, t[n] = 0, s)
        }
    })
}(jQuery),
function (e, t) {
    var i = 0,
        n = Array.prototype.slice,
        s = e.cleanData;
    e.cleanData = function (t) {
        for (var n, i = 0; null != (n = t[i]); i++) try {
            e(n).triggerHandler("remove")
        } catch (r) {}
        s(t)
    }, e.widget = function (t, i, n) {
        var s, r, a, o, l = {},
            u = t.split(".")[0];
        t = t.split(".")[1], s = u + "-" + t, n || (n = i, i = e.Widget), e.expr[":"][s.toLowerCase()] = function (t) {
            return !!e.data(t, s)
        }, e[u] = e[u] || {}, r = e[u][t], a = e[u][t] = function (e, t) {
            return this._createWidget ? void(arguments.length && this._createWidget(e, t)) : new a(e, t)
        }, e.extend(a, r, {
            version: n.version,
            _proto: e.extend({}, n),
            _childConstructors: []
        }), o = new i, o.options = e.widget.extend({}, o.options), e.each(n, function (t, n) {
            return e.isFunction(n) ? void(l[t] = function () {
                var e = function () {
                        return i.prototype[t].apply(this, arguments)
                    },
                    s = function (e) {
                        return i.prototype[t].apply(this, e)
                    };
                return function () {
                    var r, t = this._super,
                        i = this._superApply;
                    return this._super = e, this._superApply = s, r = n.apply(this, arguments), this._super = t, this._superApply = i, r
                }
            }()) : void(l[t] = n)
        }), a.prototype = e.widget.extend(o, {
            widgetEventPrefix: r ? o.widgetEventPrefix || t : t
        }, l, {
            constructor: a,
            namespace: u,
            widgetName: t,
            widgetFullName: s
        }), r ? (e.each(r._childConstructors, function (t, i) {
            var n = i.prototype;
            e.widget(n.namespace + "." + n.widgetName, a, i._proto)
        }), delete r._childConstructors) : i._childConstructors.push(a), e.widget.bridge(t, a)
    }, e.widget.extend = function (i) {
        for (var o, l, s = n.call(arguments, 1), r = 0, a = s.length; a > r; r++)
            for (o in s[r]) l = s[r][o], s[r].hasOwnProperty(o) && l !== t && (i[o] = e.isPlainObject(l) ? e.isPlainObject(i[o]) ? e.widget.extend({}, i[o], l) : e.widget.extend({}, l) : l);
        return i
    }, e.widget.bridge = function (i, s) {
        var r = s.prototype.widgetFullName || i;
        e.fn[i] = function (a) {
            var o = "string" == typeof a,
                l = n.call(arguments, 1),
                u = this;
            return a = !o && l.length ? e.widget.extend.apply(null, [a].concat(l)) : a, this.each(o ? function () {
                var n, s = e.data(this, r);
                return s ? e.isFunction(s[a]) && "_" !== a.charAt(0) ? (n = s[a].apply(s, l), n !== s && n !== t ? (u = n && n.jquery ? u.pushStack(n.get()) : n, !1) : void 0) : e.error("no such method '" + a + "' for " + i + " widget instance") : e.error("cannot call methods on " + i + " prior to initialization; attempted to call method '" + a + "'")
            } : function () {
                var t = e.data(this, r);
                t ? t.option(a || {})._init() : e.data(this, r, new s(a, this))
            }), u
        }
    }, e.Widget = function () {}, e.Widget._childConstructors = [], e.Widget.prototype = {
        widgetName: "widget",
        widgetEventPrefix: "",
        defaultElement: "<div>",
        options: {
            disabled: !1,
            create: null
        },
        _createWidget: function (t, n) {
            n = e(n || this.defaultElement || this)[0], this.element = e(n), this.uuid = i++, this.eventNamespace = "." + this.widgetName + this.uuid, this.options = e.widget.extend({}, this.options, this._getCreateOptions(), t), this.bindings = e(), this.hoverable = e(), this.focusable = e(), n !== this && (e.data(n, this.widgetFullName, this), this._on(!0, this.element, {
                remove: function (e) {
                    e.target === n && this.destroy()
                }
            }), this.document = e(n.style ? n.ownerDocument : n.document || n), this.window = e(this.document[0].defaultView || this.document[0].parentWindow)), this._create(), this._trigger("create", null, this._getCreateEventData()), this._init()
        },
        _getCreateOptions: e.noop,
        _getCreateEventData: e.noop,
        _create: e.noop,
        _init: e.noop,
        destroy: function () {
            this._destroy(), this.element.unbind(this.eventNamespace).removeData(this.widgetName).removeData(this.widgetFullName).removeData(e.camelCase(this.widgetFullName)), this.widget().unbind(this.eventNamespace).removeAttr("aria-disabled").removeClass(this.widgetFullName + "-disabled ui-state-disabled"), this.bindings.unbind(this.eventNamespace), this.hoverable.removeClass("ui-state-hover"), this.focusable.removeClass("ui-state-focus")
        },
        _destroy: e.noop,
        widget: function () {
            return this.element
        },
        option: function (i, n) {
            var r, a, o, s = i;
            if (0 === arguments.length) return e.widget.extend({}, this.options);
            if ("string" == typeof i)
                if (s = {}, r = i.split("."), i = r.shift(), r.length) {
                    for (a = s[i] = e.widget.extend({}, this.options[i]), o = 0; o < r.length - 1; o++) a[r[o]] = a[r[o]] || {}, a = a[r[o]];
                    if (i = r.pop(), 1 === arguments.length) return a[i] === t ? null : a[i];
                    a[i] = n
                } else {
                    if (1 === arguments.length) return this.options[i] === t ? null : this.options[i];
                    s[i] = n
                }
            return this._setOptions(s), this
        },
        _setOptions: function (e) {
            var t;
            for (t in e) this._setOption(t, e[t]);
            return this
        },
        _setOption: function (e, t) {
            return this.options[e] = t, "disabled" === e && (this.widget().toggleClass(this.widgetFullName + "-disabled ui-state-disabled", !!t).attr("aria-disabled", t), this.hoverable.removeClass("ui-state-hover"), this.focusable.removeClass("ui-state-focus")), this
        },
        enable: function () {
            return this._setOption("disabled", !1)
        },
        disable: function () {
            return this._setOption("disabled", !0)
        },
        _on: function (t, i, n) {
            var s, r = this;
            "boolean" != typeof t && (n = i, i = t, t = !1), n ? (i = s = e(i), this.bindings = this.bindings.add(i)) : (n = i, i = this.element, s = this.widget()), e.each(n, function (n, a) {
                function o() {
                    return t || r.options.disabled !== !0 && !e(this).hasClass("ui-state-disabled") ? ("string" == typeof a ? r[a] : a).apply(r, arguments) : void 0
                }
                "string" != typeof a && (o.guid = a.guid = a.guid || o.guid || e.guid++);
                var l = n.match(/^(\w+)\s*(.*)$/),
                    u = l[1] + r.eventNamespace,
                    h = l[2];
                h ? s.delegate(h, u, o) : i.bind(u, o)
            })
        },
        _off: function (e, t) {
            t = (t || "").split(" ").join(this.eventNamespace + " ") + this.eventNamespace, e.unbind(t).undelegate(t)
        },
        _delay: function (e, t) {
            function i() {
                return ("string" == typeof e ? n[e] : e).apply(n, arguments)
            }
            var n = this;
            return setTimeout(i, t || 0)
        },
        _hoverable: function (t) {
            this.hoverable = this.hoverable.add(t), this._on(t, {
                mouseenter: function (t) {
                    e(t.currentTarget).addClass("ui-state-hover")
                },
                mouseleave: function (t) {
                    e(t.currentTarget).removeClass("ui-state-hover")
                }
            })
        },
        _focusable: function (t) {
            this.focusable = this.focusable.add(t), this._on(t, {
                focusin: function (t) {
                    e(t.currentTarget).addClass("ui-state-focus")
                },
                focusout: function (t) {
                    e(t.currentTarget).removeClass("ui-state-focus")
                }
            })
        },
        _trigger: function (t, i, n) {
            var s, r, a = this.options[t];
            if (n = n || {}, i = e.Event(i), i.type = (t === this.widgetEventPrefix ? t : this.widgetEventPrefix + t).toLowerCase(), i.target = this.element[0], r = i.originalEvent)
                for (s in r) s in i || (i[s] = r[s]);
            return this.element.trigger(i, n), !(e.isFunction(a) && a.apply(this.element[0], [i].concat(n)) === !1 || i.isDefaultPrevented())
        }
    }, e.each({
        show: "fadeIn",
        hide: "fadeOut"
    }, function (t, i) {
        e.Widget.prototype["_" + t] = function (n, s, r) {
            "string" == typeof s && (s = {
                effect: s
            });
            var a, o = s ? s === !0 || "number" == typeof s ? i : s.effect || i : t;
            s = s || {}, "number" == typeof s && (s = {
                duration: s
            }), a = !e.isEmptyObject(s), s.complete = r, s.delay && n.delay(s.delay), a && e.effects && e.effects.effect[o] ? n[t](s) : o !== t && n[o] ? n[o](s.duration, s.easing, r) : n.queue(function (i) {
                e(this)[t](), r && r.call(n[0]), i()
            })
        }
    })
}(jQuery),
function (e) {
    var i = !1;
    e(document).mouseup(function () {
        i = !1
    }), e.widget("ui.mouse", {
        version: "1.10.4",
        options: {
            cancel: "input,textarea,button,select,option",
            distance: 1,
            delay: 0
        },
        _mouseInit: function () {
            var t = this;
            this.element.bind("mousedown." + this.widgetName, function (e) {
                return t._mouseDown(e)
            }).bind("click." + this.widgetName, function (i) {
                return !0 === e.data(i.target, t.widgetName + ".preventClickEvent") ? (e.removeData(i.target, t.widgetName + ".preventClickEvent"), i.stopImmediatePropagation(), !1) : void 0
            }), this.started = !1
        },
        _mouseDestroy: function () {
            this.element.unbind("." + this.widgetName), this._mouseMoveDelegate && e(document).unbind("mousemove." + this.widgetName, this._mouseMoveDelegate).unbind("mouseup." + this.widgetName, this._mouseUpDelegate)
        },
        _mouseDown: function (t) {
            if (!i) {
                this._mouseStarted && this._mouseUp(t), this._mouseDownEvent = t;
                var n = this,
                    s = 1 === t.which,
                    r = "string" == typeof this.options.cancel && t.target.nodeName ? e(t.target).closest(this.options.cancel).length : !1;
                return s && !r && this._mouseCapture(t) ? (this.mouseDelayMet = !this.options.delay, this.mouseDelayMet || (this._mouseDelayTimer = setTimeout(function () {
                    n.mouseDelayMet = !0
                }, this.options.delay)), this._mouseDistanceMet(t) && this._mouseDelayMet(t) && (this._mouseStarted = this._mouseStart(t) !== !1, !this._mouseStarted) ? (t.preventDefault(), !0) : (!0 === e.data(t.target, this.widgetName + ".preventClickEvent") && e.removeData(t.target, this.widgetName + ".preventClickEvent"), this._mouseMoveDelegate = function (e) {
                    return n._mouseMove(e)
                }, this._mouseUpDelegate = function (e) {
                    return n._mouseUp(e)
                }, e(document).bind("mousemove." + this.widgetName, this._mouseMoveDelegate).bind("mouseup." + this.widgetName, this._mouseUpDelegate), t.preventDefault(), i = !0, !0)) : !0
            }
        },
        _mouseMove: function (t) {
            return e.ui.ie && (!document.documentMode || document.documentMode < 9) && !t.button ? this._mouseUp(t) : this._mouseStarted ? (this._mouseDrag(t), t.preventDefault()) : (this._mouseDistanceMet(t) && this._mouseDelayMet(t) && (this._mouseStarted = this._mouseStart(this._mouseDownEvent, t) !== !1, this._mouseStarted ? this._mouseDrag(t) : this._mouseUp(t)), !this._mouseStarted)
        },
        _mouseUp: function (t) {
            return e(document).unbind("mousemove." + this.widgetName, this._mouseMoveDelegate).unbind("mouseup." + this.widgetName, this._mouseUpDelegate), this._mouseStarted && (this._mouseStarted = !1, t.target === this._mouseDownEvent.target && e.data(t.target, this.widgetName + ".preventClickEvent", !0), this._mouseStop(t)), !1
        },
        _mouseDistanceMet: function (e) {
            return Math.max(Math.abs(this._mouseDownEvent.pageX - e.pageX), Math.abs(this._mouseDownEvent.pageY - e.pageY)) >= this.options.distance
        },
        _mouseDelayMet: function () {
            return this.mouseDelayMet
        },
        _mouseStart: function () {},
        _mouseDrag: function () {},
        _mouseStop: function () {},
        _mouseCapture: function () {
            return !0
        }
    })
}(jQuery),
function (e) {
    e.widget("ui.draggable", e.ui.mouse, {
        version: "1.10.4",
        widgetEventPrefix: "drag",
        options: {
            addClasses: !0,
            appendTo: "parent",
            axis: !1,
            connectToSortable: !1,
            containment: !1,
            cursor: "auto",
            cursorAt: !1,
            grid: !1,
            handle: !1,
            helper: "original",
            iframeFix: !1,
            opacity: !1,
            refreshPositions: !1,
            revert: !1,
            revertDuration: 500,
            scope: "default",
            scroll: !0,
            scrollSensitivity: 20,
            scrollSpeed: 20,
            snap: !1,
            snapMode: "both",
            snapTolerance: 20,
            stack: !1,
            zIndex: !1,
            drag: null,
            start: null,
            stop: null
        },
        _create: function () {
            "original" !== this.options.helper || /^(?:r|a|f)/.test(this.element.css("position")) || (this.element[0].style.position = "relative"), this.options.addClasses && this.element.addClass("ui-draggable"), this.options.disabled && this.element.addClass("ui-draggable-disabled"), this._mouseInit()
        },
        _destroy: function () {
            this.element.removeClass("ui-draggable ui-draggable-dragging ui-draggable-disabled"), this._mouseDestroy()
        },
        _mouseCapture: function (t) {
            var i = this.options;
            return this.helper || i.disabled || e(t.target).closest(".ui-resizable-handle").length > 0 ? !1 : (this.handle = this._getHandle(t), this.handle ? (e(i.iframeFix === !0 ? "iframe" : i.iframeFix).each(function () {
                e("<div class='ui-draggable-iframeFix' style='background: #fff;'></div>").css({
                    width: this.offsetWidth + "px",
                    height: this.offsetHeight + "px",
                    position: "absolute",
                    opacity: "0.001",
                    zIndex: 1e3
                }).css(e(this).offset()).appendTo("body")
            }), !0) : !1)
        },
        _mouseStart: function (t) {
            var i = this.options;
            return this.helper = this._createHelper(t), this.helper.addClass("ui-draggable-dragging"), this._cacheHelperProportions(), e.ui.ddmanager && (e.ui.ddmanager.current = this), this._cacheMargins(), this.cssPosition = this.helper.css("position"), this.scrollParent = this.helper.scrollParent(), this.offsetParent = this.helper.offsetParent(), this.offsetParentCssPosition = this.offsetParent.css("position"), this.offset = this.positionAbs = this.element.offset(), this.offset = {
                top: this.offset.top - this.margins.top,
                left: this.offset.left - this.margins.left
            }, this.offset.scroll = !1, e.extend(this.offset, {
                click: {
                    left: t.pageX - this.offset.left,
                    top: t.pageY - this.offset.top
                },
                parent: this._getParentOffset(),
                relative: this._getRelativeOffset()
            }), this.originalPosition = this.position = this._generatePosition(t), this.originalPageX = t.pageX, this.originalPageY = t.pageY, i.cursorAt && this._adjustOffsetFromHelper(i.cursorAt), this._setContainment(), this._trigger("start", t) === !1 ? (this._clear(), !1) : (this._cacheHelperProportions(), e.ui.ddmanager && !i.dropBehaviour && e.ui.ddmanager.prepareOffsets(this, t), this._mouseDrag(t, !0), e.ui.ddmanager && e.ui.ddmanager.dragStart(this, t), !0)
        },
        _mouseDrag: function (t, i) {
            if ("fixed" === this.offsetParentCssPosition && (this.offset.parent = this._getParentOffset()), this.position = this._generatePosition(t), this.positionAbs = this._convertPositionTo("absolute"), !i) {
                var n = this._uiHash();
                if (this._trigger("drag", t, n) === !1) return this._mouseUp({}), !1;
                this.position = n.position
            }
            return this.options.axis && "y" === this.options.axis || (this.helper[0].style.left = this.position.left + "px"), this.options.axis && "x" === this.options.axis || (this.helper[0].style.top = this.position.top + "px"), e.ui.ddmanager && e.ui.ddmanager.drag(this, t), !1
        },
        _mouseStop: function (t) {
            var i = this,
                n = !1;
            return e.ui.ddmanager && !this.options.dropBehaviour && (n = e.ui.ddmanager.drop(this, t)), this.dropped && (n = this.dropped, this.dropped = !1), "original" !== this.options.helper || e.contains(this.element[0].ownerDocument, this.element[0]) ? ("invalid" === this.options.revert && !n || "valid" === this.options.revert && n || this.options.revert === !0 || e.isFunction(this.options.revert) && this.options.revert.call(this.element, n) ? e(this.helper).animate(this.originalPosition, parseInt(this.options.revertDuration, 10), function () {
                i._trigger("stop", t) !== !1 && i._clear()
            }) : this._trigger("stop", t) !== !1 && this._clear(), !1) : !1
        },
        _mouseUp: function (t) {
            return e("div.ui-draggable-iframeFix").each(function () {
                this.parentNode.removeChild(this)
            }), e.ui.ddmanager && e.ui.ddmanager.dragStop(this, t), e.ui.mouse.prototype._mouseUp.call(this, t)
        },
        cancel: function () {
            return this.helper.is(".ui-draggable-dragging") ? this._mouseUp({}) : this._clear(), this
        },
        _getHandle: function (t) {
            return this.options.handle ? !!e(t.target).closest(this.element.find(this.options.handle)).length : !0
        },
        _createHelper: function (t) {
            var i = this.options,
                n = e.isFunction(i.helper) ? e(i.helper.apply(this.element[0], [t])) : "clone" === i.helper ? this.element.clone().removeAttr("id") : this.element;
            return n.parents("body").length || n.appendTo("parent" === i.appendTo ? this.element[0].parentNode : i.appendTo), n[0] === this.element[0] || /(fixed|absolute)/.test(n.css("position")) || n.css("position", "absolute"), n
        },
        _adjustOffsetFromHelper: function (t) {
            "string" == typeof t && (t = t.split(" ")), e.isArray(t) && (t = {
                left: +t[0],
                top: +t[1] || 0
            }), "left" in t && (this.offset.click.left = t.left + this.margins.left), "right" in t && (this.offset.click.left = this.helperProportions.width - t.right + this.margins.left), "top" in t && (this.offset.click.top = t.top + this.margins.top), "bottom" in t && (this.offset.click.top = this.helperProportions.height - t.bottom + this.margins.top)
        },
        _getParentOffset: function () {
            var t = this.offsetParent.offset();
            return "absolute" === this.cssPosition && this.scrollParent[0] !== document && e.contains(this.scrollParent[0], this.offsetParent[0]) && (t.left += this.scrollParent.scrollLeft(), t.top += this.scrollParent.scrollTop()), (this.offsetParent[0] === document.body || this.offsetParent[0].tagName && "html" === this.offsetParent[0].tagName.toLowerCase() && e.ui.ie) && (t = {
                top: 0,
                left: 0
            }), {
                top: t.top + (parseInt(this.offsetParent.css("borderTopWidth"), 10) || 0),
                left: t.left + (parseInt(this.offsetParent.css("borderLeftWidth"), 10) || 0)
            }
        },
        _getRelativeOffset: function () {
            if ("relative" === this.cssPosition) {
                var e = this.element.position();
                return {
                    top: e.top - (parseInt(this.helper.css("top"), 10) || 0) + this.scrollParent.scrollTop(),
                    left: e.left - (parseInt(this.helper.css("left"), 10) || 0) + this.scrollParent.scrollLeft()
                }
            }
            return {
                top: 0,
                left: 0
            }
        },
        _cacheMargins: function () {
            this.margins = {
                left: parseInt(this.element.css("marginLeft"), 10) || 0,
                top: parseInt(this.element.css("marginTop"), 10) || 0,
                right: parseInt(this.element.css("marginRight"), 10) || 0,
                bottom: parseInt(this.element.css("marginBottom"), 10) || 0
            }
        },
        _cacheHelperProportions: function () {
            this.helperProportions = {
                width: this.helper.outerWidth(),
                height: this.helper.outerHeight()
            }
        },
        _setContainment: function () {
            var t, i, n, s = this.options;
            return s.containment ? "window" === s.containment ? void(this.containment = [e(window).scrollLeft() - this.offset.relative.left - this.offset.parent.left, e(window).scrollTop() - this.offset.relative.top - this.offset.parent.top, e(window).scrollLeft() + e(window).width() - this.helperProportions.width - this.margins.left, e(window).scrollTop() + (e(window).height() || document.body.parentNode.scrollHeight) - this.helperProportions.height - this.margins.top]) : "document" === s.containment ? void(this.containment = [0, 0, e(document).width() - this.helperProportions.width - this.margins.left, (e(document).height() || document.body.parentNode.scrollHeight) - this.helperProportions.height - this.margins.top]) : s.containment.constructor === Array ? void(this.containment = s.containment) : ("parent" === s.containment && (s.containment = this.helper[0].parentNode), i = e(s.containment), n = i[0], void(n && (t = "hidden" !== i.css("overflow"), this.containment = [(parseInt(i.css("borderLeftWidth"), 10) || 0) + (parseInt(i.css("paddingLeft"), 10) || 0), (parseInt(i.css("borderTopWidth"), 10) || 0) + (parseInt(i.css("paddingTop"), 10) || 0), (t ? Math.max(n.scrollWidth, n.offsetWidth) : n.offsetWidth) - (parseInt(i.css("borderRightWidth"), 10) || 0) - (parseInt(i.css("paddingRight"), 10) || 0) - this.helperProportions.width - this.margins.left - this.margins.right, (t ? Math.max(n.scrollHeight, n.offsetHeight) : n.offsetHeight) - (parseInt(i.css("borderBottomWidth"), 10) || 0) - (parseInt(i.css("paddingBottom"), 10) || 0) - this.helperProportions.height - this.margins.top - this.margins.bottom], this.relative_container = i))) : void(this.containment = null)
        },
        _convertPositionTo: function (t, i) {
            i || (i = this.position);
            var n = "absolute" === t ? 1 : -1,
                s = "absolute" !== this.cssPosition || this.scrollParent[0] !== document && e.contains(this.scrollParent[0], this.offsetParent[0]) ? this.scrollParent : this.offsetParent;
            return this.offset.scroll || (this.offset.scroll = {
                top: s.scrollTop(),
                left: s.scrollLeft()
            }), {
                top: i.top + this.offset.relative.top * n + this.offset.parent.top * n - ("fixed" === this.cssPosition ? -this.scrollParent.scrollTop() : this.offset.scroll.top) * n,
                left: i.left + this.offset.relative.left * n + this.offset.parent.left * n - ("fixed" === this.cssPosition ? -this.scrollParent.scrollLeft() : this.offset.scroll.left) * n
            }
        },
        _generatePosition: function (t) {
            var i, n, s, r, a = this.options,
                o = "absolute" !== this.cssPosition || this.scrollParent[0] !== document && e.contains(this.scrollParent[0], this.offsetParent[0]) ? this.scrollParent : this.offsetParent,
                l = t.pageX,
                u = t.pageY;
            return this.offset.scroll || (this.offset.scroll = {
                top: o.scrollTop(),
                left: o.scrollLeft()
            }), this.originalPosition && (this.containment && (this.relative_container ? (n = this.relative_container.offset(), i = [this.containment[0] + n.left, this.containment[1] + n.top, this.containment[2] + n.left, this.containment[3] + n.top]) : i = this.containment, t.pageX - this.offset.click.left < i[0] && (l = i[0] + this.offset.click.left), t.pageY - this.offset.click.top < i[1] && (u = i[1] + this.offset.click.top), t.pageX - this.offset.click.left > i[2] && (l = i[2] + this.offset.click.left), t.pageY - this.offset.click.top > i[3] && (u = i[3] + this.offset.click.top)), a.grid && (s = a.grid[1] ? this.originalPageY + Math.round((u - this.originalPageY) / a.grid[1]) * a.grid[1] : this.originalPageY, u = i ? s - this.offset.click.top >= i[1] || s - this.offset.click.top > i[3] ? s : s - this.offset.click.top >= i[1] ? s - a.grid[1] : s + a.grid[1] : s, r = a.grid[0] ? this.originalPageX + Math.round((l - this.originalPageX) / a.grid[0]) * a.grid[0] : this.originalPageX, l = i ? r - this.offset.click.left >= i[0] || r - this.offset.click.left > i[2] ? r : r - this.offset.click.left >= i[0] ? r - a.grid[0] : r + a.grid[0] : r)), {
                top: u - this.offset.click.top - this.offset.relative.top - this.offset.parent.top + ("fixed" === this.cssPosition ? -this.scrollParent.scrollTop() : this.offset.scroll.top),
                left: l - this.offset.click.left - this.offset.relative.left - this.offset.parent.left + ("fixed" === this.cssPosition ? -this.scrollParent.scrollLeft() : this.offset.scroll.left)
            }
        },
        _clear: function () {
            this.helper.removeClass("ui-draggable-dragging"), this.helper[0] === this.element[0] || this.cancelHelperRemoval || this.helper.remove(), this.helper = null, this.cancelHelperRemoval = !1
        },
        _trigger: function (t, i, n) {
            return n = n || this._uiHash(), e.ui.plugin.call(this, t, [i, n]), "drag" === t && (this.positionAbs = this._convertPositionTo("absolute")), e.Widget.prototype._trigger.call(this, t, i, n)
        },
        plugins: {},
        _uiHash: function () {
            return {
                helper: this.helper,
                position: this.position,
                originalPosition: this.originalPosition,
                offset: this.positionAbs
            }
        }
    }), e.ui.plugin.add("draggable", "connectToSortable", {
        start: function (t, i) {
            var n = e(this).data("ui-draggable"),
                s = n.options,
                r = e.extend({}, i, {
                    item: n.element
                });
            n.sortables = [], e(s.connectToSortable).each(function () {
                var i = e.data(this, "ui-sortable");
                i && !i.options.disabled && (n.sortables.push({
                    instance: i,
                    shouldRevert: i.options.revert
                }), i.refreshPositions(), i._trigger("activate", t, r))
            })
        },
        stop: function (t, i) {
            var n = e(this).data("ui-draggable"),
                s = e.extend({}, i, {
                    item: n.element
                });
            e.each(n.sortables, function () {
                this.instance.isOver ? (this.instance.isOver = 0, n.cancelHelperRemoval = !0, this.instance.cancelHelperRemoval = !1, this.shouldRevert && (this.instance.options.revert = this.shouldRevert), this.instance._mouseStop(t), this.instance.options.helper = this.instance.options._helper, "original" === n.options.helper && this.instance.currentItem.css({
                    top: "auto",
                    left: "auto"
                })) : (this.instance.cancelHelperRemoval = !1, this.instance._trigger("deactivate", t, s))
            })
        },
        drag: function (t, i) {
            var n = e(this).data("ui-draggable"),
                s = this;
            e.each(n.sortables, function () {
                var r = !1,
                    a = this;
                this.instance.positionAbs = n.positionAbs, this.instance.helperProportions = n.helperProportions, this.instance.offset.click = n.offset.click, this.instance._intersectsWith(this.instance.containerCache) && (r = !0, e.each(n.sortables, function () {
                    return this.instance.positionAbs = n.positionAbs, this.instance.helperProportions = n.helperProportions, this.instance.offset.click = n.offset.click, this !== a && this.instance._intersectsWith(this.instance.containerCache) && e.contains(a.instance.element[0], this.instance.element[0]) && (r = !1), r
                })), r ? (this.instance.isOver || (this.instance.isOver = 1, this.instance.currentItem = e(s).clone().removeAttr("id").appendTo(this.instance.element).data("ui-sortable-item", !0), this.instance.options._helper = this.instance.options.helper, this.instance.options.helper = function () {
                    return i.helper[0]
                }, t.target = this.instance.currentItem[0], this.instance._mouseCapture(t, !0), this.instance._mouseStart(t, !0, !0), this.instance.offset.click.top = n.offset.click.top, this.instance.offset.click.left = n.offset.click.left, this.instance.offset.parent.left -= n.offset.parent.left - this.instance.offset.parent.left, this.instance.offset.parent.top -= n.offset.parent.top - this.instance.offset.parent.top, n._trigger("toSortable", t), n.dropped = this.instance.element, n.currentItem = n.element, this.instance.fromOutside = n), this.instance.currentItem && this.instance._mouseDrag(t)) : this.instance.isOver && (this.instance.isOver = 0, this.instance.cancelHelperRemoval = !0, this.instance.options.revert = !1, this.instance._trigger("out", t, this.instance._uiHash(this.instance)), this.instance._mouseStop(t, !0), this.instance.options.helper = this.instance.options._helper, this.instance.currentItem.remove(), this.instance.placeholder && this.instance.placeholder.remove(), n._trigger("fromSortable", t), n.dropped = !1)
            })
        }
    }), e.ui.plugin.add("draggable", "cursor", {
        start: function () {
            var t = e("body"),
                i = e(this).data("ui-draggable").options;
            t.css("cursor") && (i._cursor = t.css("cursor")), t.css("cursor", i.cursor)
        },
        stop: function () {
            var t = e(this).data("ui-draggable").options;
            t._cursor && e("body").css("cursor", t._cursor)
        }
    }), e.ui.plugin.add("draggable", "opacity", {
        start: function (t, i) {
            var n = e(i.helper),
                s = e(this).data("ui-draggable").options;
            n.css("opacity") && (s._opacity = n.css("opacity")), n.css("opacity", s.opacity)
        },
        stop: function (t, i) {
            var n = e(this).data("ui-draggable").options;
            n._opacity && e(i.helper).css("opacity", n._opacity)
        }
    }), e.ui.plugin.add("draggable", "scroll", {
        start: function () {
            var t = e(this).data("ui-draggable");
            t.scrollParent[0] !== document && "HTML" !== t.scrollParent[0].tagName && (t.overflowOffset = t.scrollParent.offset())
        },
        drag: function (t) {
            var i = e(this).data("ui-draggable"),
                n = i.options,
                s = !1;
            i.scrollParent[0] !== document && "HTML" !== i.scrollParent[0].tagName ? (n.axis && "x" === n.axis || (i.overflowOffset.top + i.scrollParent[0].offsetHeight - t.pageY < n.scrollSensitivity ? i.scrollParent[0].scrollTop = s = i.scrollParent[0].scrollTop + n.scrollSpeed : t.pageY - i.overflowOffset.top < n.scrollSensitivity && (i.scrollParent[0].scrollTop = s = i.scrollParent[0].scrollTop - n.scrollSpeed)), n.axis && "y" === n.axis || (i.overflowOffset.left + i.scrollParent[0].offsetWidth - t.pageX < n.scrollSensitivity ? i.scrollParent[0].scrollLeft = s = i.scrollParent[0].scrollLeft + n.scrollSpeed : t.pageX - i.overflowOffset.left < n.scrollSensitivity && (i.scrollParent[0].scrollLeft = s = i.scrollParent[0].scrollLeft - n.scrollSpeed))) : (n.axis && "x" === n.axis || (t.pageY - e(document).scrollTop() < n.scrollSensitivity ? s = e(document).scrollTop(e(document).scrollTop() - n.scrollSpeed) : e(window).height() - (t.pageY - e(document).scrollTop()) < n.scrollSensitivity && (s = e(document).scrollTop(e(document).scrollTop() + n.scrollSpeed))), n.axis && "y" === n.axis || (t.pageX - e(document).scrollLeft() < n.scrollSensitivity ? s = e(document).scrollLeft(e(document).scrollLeft() - n.scrollSpeed) : e(window).width() - (t.pageX - e(document).scrollLeft()) < n.scrollSensitivity && (s = e(document).scrollLeft(e(document).scrollLeft() + n.scrollSpeed)))), s !== !1 && e.ui.ddmanager && !n.dropBehaviour && e.ui.ddmanager.prepareOffsets(i, t)
        }
    }), e.ui.plugin.add("draggable", "snap", {
        start: function () {
            var t = e(this).data("ui-draggable"),
                i = t.options;
            t.snapElements = [], e(i.snap.constructor !== String ? i.snap.items || ":data(ui-draggable)" : i.snap).each(function () {
                var i = e(this),
                    n = i.offset();
                this !== t.element[0] && t.snapElements.push({
                    item: this,
                    width: i.outerWidth(),
                    height: i.outerHeight(),
                    top: n.top,
                    left: n.left
                })
            })
        },
        drag: function (t, i) {
            var n, s, r, a, o, l, u, h, f, c, d = e(this).data("ui-draggable"),
                p = d.options,
                g = p.snapTolerance,
                m = i.offset.left,
                v = m + d.helperProportions.width,
                b = i.offset.top,
                y = b + d.helperProportions.height;
            for (f = d.snapElements.length - 1; f >= 0; f--) o = d.snapElements[f].left, l = o + d.snapElements[f].width, u = d.snapElements[f].top, h = u + d.snapElements[f].height, o - g > v || m > l + g || u - g > y || b > h + g || !e.contains(d.snapElements[f].item.ownerDocument, d.snapElements[f].item) ? (d.snapElements[f].snapping && d.options.snap.release && d.options.snap.release.call(d.element, t, e.extend(d._uiHash(), {
                snapItem: d.snapElements[f].item
            })), d.snapElements[f].snapping = !1) : ("inner" !== p.snapMode && (n = Math.abs(u - y) <= g, s = Math.abs(h - b) <= g, r = Math.abs(o - v) <= g, a = Math.abs(l - m) <= g, n && (i.position.top = d._convertPositionTo("relative", {
                top: u - d.helperProportions.height,
                left: 0
            }).top - d.margins.top), s && (i.position.top = d._convertPositionTo("relative", {
                top: h,
                left: 0
            }).top - d.margins.top), r && (i.position.left = d._convertPositionTo("relative", {
                top: 0,
                left: o - d.helperProportions.width
            }).left - d.margins.left), a && (i.position.left = d._convertPositionTo("relative", {
                top: 0,
                left: l
            }).left - d.margins.left)), c = n || s || r || a, "outer" !== p.snapMode && (n = Math.abs(u - b) <= g, s = Math.abs(h - y) <= g, r = Math.abs(o - m) <= g, a = Math.abs(l - v) <= g, n && (i.position.top = d._convertPositionTo("relative", {
                top: u,
                left: 0
            }).top - d.margins.top), s && (i.position.top = d._convertPositionTo("relative", {
                top: h - d.helperProportions.height,
                left: 0
            }).top - d.margins.top), r && (i.position.left = d._convertPositionTo("relative", {
                top: 0,
                left: o
            }).left - d.margins.left), a && (i.position.left = d._convertPositionTo("relative", {
                top: 0,
                left: l - d.helperProportions.width
            }).left - d.margins.left)), !d.snapElements[f].snapping && (n || s || r || a || c) && d.options.snap.snap && d.options.snap.snap.call(d.element, t, e.extend(d._uiHash(), {
                snapItem: d.snapElements[f].item
            })), d.snapElements[f].snapping = n || s || r || a || c)
        }
    }), e.ui.plugin.add("draggable", "stack", {
        start: function () {
            var t, i = this.data("ui-draggable").options,
                n = e.makeArray(e(i.stack)).sort(function (t, i) {
                    return (parseInt(e(t).css("zIndex"), 10) || 0) - (parseInt(e(i).css("zIndex"), 10) || 0)
                });
            n.length && (t = parseInt(e(n[0]).css("zIndex"), 10) || 0, e(n).each(function (i) {
                e(this).css("zIndex", t + i)
            }), this.css("zIndex", t + n.length))
        }
    }), e.ui.plugin.add("draggable", "zIndex", {
        start: function (t, i) {
            var n = e(i.helper),
                s = e(this).data("ui-draggable").options;
            n.css("zIndex") && (s._zIndex = n.css("zIndex")), n.css("zIndex", s.zIndex)
        },
        stop: function (t, i) {
            var n = e(this).data("ui-draggable").options;
            n._zIndex && e(i.helper).css("zIndex", n._zIndex)
        }
    })
}(jQuery),
function (e) {
    function i(e, t, i) {
        return e > t && t + i > e
    }
    e.widget("ui.droppable", {
        version: "1.10.4",
        widgetEventPrefix: "drop",
        options: {
            accept: "*",
            activeClass: !1,
            addClasses: !0,
            greedy: !1,
            hoverClass: !1,
            scope: "default",
            tolerance: "intersect",
            activate: null,
            deactivate: null,
            drop: null,
            out: null,
            over: null
        },
        _create: function () {
            var t, i = this.options,
                n = i.accept;
            this.isover = !1, this.isout = !0, this.accept = e.isFunction(n) ? n : function (e) {
                return e.is(n)
            }, this.proportions = function () {
                return arguments.length ? void(t = arguments[0]) : t ? t : t = {
                    width: this.element[0].offsetWidth,
                    height: this.element[0].offsetHeight
                }
            }, e.ui.ddmanager.droppables[i.scope] = e.ui.ddmanager.droppables[i.scope] || [], e.ui.ddmanager.droppables[i.scope].push(this), i.addClasses && this.element.addClass("ui-droppable")
        },
        _destroy: function () {
            for (var t = 0, i = e.ui.ddmanager.droppables[this.options.scope]; t < i.length; t++) i[t] === this && i.splice(t, 1);
            this.element.removeClass("ui-droppable ui-droppable-disabled")
        },
        _setOption: function (t, i) {
            "accept" === t && (this.accept = e.isFunction(i) ? i : function (e) {
                return e.is(i)
            }), e.Widget.prototype._setOption.apply(this, arguments)
        },
        _activate: function (t) {
            var i = e.ui.ddmanager.current;
            this.options.activeClass && this.element.addClass(this.options.activeClass), i && this._trigger("activate", t, this.ui(i))
        },
        _deactivate: function (t) {
            var i = e.ui.ddmanager.current;
            this.options.activeClass && this.element.removeClass(this.options.activeClass), i && this._trigger("deactivate", t, this.ui(i))
        },
        _over: function (t) {
            var i = e.ui.ddmanager.current;
            i && (i.currentItem || i.element)[0] !== this.element[0] && this.accept.call(this.element[0], i.currentItem || i.element) && (this.options.hoverClass && this.element.addClass(this.options.hoverClass), this._trigger("over", t, this.ui(i)))
        },
        _out: function (t) {
            var i = e.ui.ddmanager.current;
            i && (i.currentItem || i.element)[0] !== this.element[0] && this.accept.call(this.element[0], i.currentItem || i.element) && (this.options.hoverClass && this.element.removeClass(this.options.hoverClass), this._trigger("out", t, this.ui(i)))
        },
        _drop: function (t, i) {
            var n = i || e.ui.ddmanager.current,
                s = !1;
            return n && (n.currentItem || n.element)[0] !== this.element[0] ? (this.element.find(":data(ui-droppable)").not(".ui-draggable-dragging").each(function () {
                var t = e.data(this, "ui-droppable");
                return t.options.greedy && !t.options.disabled && t.options.scope === n.options.scope && t.accept.call(t.element[0], n.currentItem || n.element) && e.ui.intersect(n, e.extend(t, {
                    offset: t.element.offset()
                }), t.options.tolerance) ? (s = !0, !1) : void 0
            }), s ? !1 : this.accept.call(this.element[0], n.currentItem || n.element) ? (this.options.activeClass && this.element.removeClass(this.options.activeClass), this.options.hoverClass && this.element.removeClass(this.options.hoverClass), this._trigger("drop", t, this.ui(n)), this.element) : !1) : !1
        },
        ui: function (e) {
            return {
                draggable: e.currentItem || e.element,
                helper: e.helper,
                position: e.position,
                offset: e.positionAbs
            }
        }
    }), e.ui.intersect = function (e, t, n) {
        if (!t.offset) return !1;
        var s, r, a = (e.positionAbs || e.position.absolute).left,
            o = (e.positionAbs || e.position.absolute).top,
            l = a + e.helperProportions.width,
            u = o + e.helperProportions.height,
            h = t.offset.left,
            f = t.offset.top,
            c = h + t.proportions().width,
            d = f + t.proportions().height;
        switch (n) {
            case "fit":
                return a >= h && c >= l && o >= f && d >= u;
            case "intersect":
                return h < a + e.helperProportions.width / 2 && l - e.helperProportions.width / 2 < c && f < o + e.helperProportions.height / 2 && u - e.helperProportions.height / 2 < d;
            case "pointer":
                return s = (e.positionAbs || e.position.absolute).left + (e.clickOffset || e.offset.click).left, r = (e.positionAbs || e.position.absolute).top + (e.clickOffset || e.offset.click).top, i(r, f, t.proportions().height) && i(s, h, t.proportions().width);
            case "touch":
                return (o >= f && d >= o || u >= f && d >= u || f > o && u > d) && (a >= h && c >= a || l >= h && c >= l || h > a && l > c);
            default:
                return !1
        }
    }, e.ui.ddmanager = {
        current: null,
        droppables: {
            "default": []
        },
        prepareOffsets: function (t, i) {
            var n, s, r = e.ui.ddmanager.droppables[t.options.scope] || [],
                a = i ? i.type : null,
                o = (t.currentItem || t.element).find(":data(ui-droppable)").addBack();
            e: for (n = 0; n < r.length; n++)
                if (!(r[n].options.disabled || t && !r[n].accept.call(r[n].element[0], t.currentItem || t.element))) {
                    for (s = 0; s < o.length; s++)
                        if (o[s] === r[n].element[0]) {
                            r[n].proportions().height = 0;
                            continue e
                        }
                    r[n].visible = "none" !== r[n].element.css("display"), r[n].visible && ("mousedown" === a && r[n]._activate.call(r[n], i), r[n].offset = r[n].element.offset(), r[n].proportions({
                        width: r[n].element[0].offsetWidth,
                        height: r[n].element[0].offsetHeight
                    }))
                }
        },
        drop: function (t, i) {
            var n = !1;
            return e.each((e.ui.ddmanager.droppables[t.options.scope] || []).slice(), function () {
                this.options && (!this.options.disabled && this.visible && e.ui.intersect(t, this, this.options.tolerance) && (n = this._drop.call(this, i) || n), !this.options.disabled && this.visible && this.accept.call(this.element[0], t.currentItem || t.element) && (this.isout = !0, this.isover = !1, this._deactivate.call(this, i)))
            }), n
        },
        dragStart: function (t, i) {
            t.element.parentsUntil("body").bind("scroll.droppable", function () {
                t.options.refreshPositions || e.ui.ddmanager.prepareOffsets(t, i)
            })
        },
        drag: function (t, i) {
            t.options.refreshPositions && e.ui.ddmanager.prepareOffsets(t, i), e.each(e.ui.ddmanager.droppables[t.options.scope] || [], function () {
                if (!this.options.disabled && !this.greedyChild && this.visible) {
                    var n, s, r, a = e.ui.intersect(t, this, this.options.tolerance),
                        o = !a && this.isover ? "isout" : a && !this.isover ? "isover" : null;
                    o && (this.options.greedy && (s = this.options.scope, r = this.element.parents(":data(ui-droppable)").filter(function () {
                        return e.data(this, "ui-droppable").options.scope === s
                    }), r.length && (n = e.data(r[0], "ui-droppable"), n.greedyChild = "isover" === o)), n && "isover" === o && (n.isover = !1, n.isout = !0, n._out.call(n, i)), this[o] = !0, this["isout" === o ? "isover" : "isout"] = !1, this["isover" === o ? "_over" : "_out"].call(this, i), n && "isout" === o && (n.isout = !1, n.isover = !0, n._over.call(n, i)))
                }
            })
        },
        dragStop: function (t, i) {
            t.element.parentsUntil("body").unbind("scroll.droppable"), t.options.refreshPositions || e.ui.ddmanager.prepareOffsets(t, i)
        }
    }
}(jQuery),
function (e) {
    function i(e) {
        return parseInt(e, 10) || 0
    }

    function n(e) {
        return !isNaN(parseInt(e, 10))
    }
    e.widget("ui.resizable", e.ui.mouse, {
        version: "1.10.4",
        widgetEventPrefix: "resize",
        options: {
            alsoResize: !1,
            animate: !1,
            animateDuration: "slow",
            animateEasing: "swing",
            aspectRatio: !1,
            autoHide: !1,
            containment: !1,
            ghost: !1,
            grid: !1,
            handles: "e,s,se",
            helper: !1,
            maxHeight: null,
            maxWidth: null,
            minHeight: 10,
            minWidth: 10,
            zIndex: 90,
            resize: null,
            start: null,
            stop: null
        },
        _create: function () {
            var t, i, n, s, r, a = this,
                o = this.options;
            if (this.element.addClass("ui-resizable"), e.extend(this, {
                    _aspectRatio: !!o.aspectRatio,
                    aspectRatio: o.aspectRatio,
                    originalElement: this.element,
                    _proportionallyResizeElements: [],
                    _helper: o.helper || o.ghost || o.animate ? o.helper || "ui-resizable-helper" : null
                }), this.element[0].nodeName.match(/canvas|textarea|input|select|button|img/i) && (this.element.wrap(e("<div class='ui-wrapper' style='overflow: hidden;'></div>").css({
                    position: this.element.css("position"),
                    width: this.element.outerWidth(),
                    height: this.element.outerHeight(),
                    top: this.element.css("top"),
                    left: this.element.css("left")
                })), this.element = this.element.parent().data("ui-resizable", this.element.data("ui-resizable")), this.elementIsWrapper = !0, this.element.css({
                    marginLeft: this.originalElement.css("marginLeft"),
                    marginTop: this.originalElement.css("marginTop"),
                    marginRight: this.originalElement.css("marginRight"),
                    marginBottom: this.originalElement.css("marginBottom")
                }), this.originalElement.css({
                    marginLeft: 0,
                    marginTop: 0,
                    marginRight: 0,
                    marginBottom: 0
                }), this.originalResizeStyle = this.originalElement.css("resize"), this.originalElement.css("resize", "none"), this._proportionallyResizeElements.push(this.originalElement.css({
                    position: "static",
                    zoom: 1,
                    display: "block"
                })), this.originalElement.css({
                    margin: this.originalElement.css("margin")
                }), this._proportionallyResize()), this.handles = o.handles || (e(".ui-resizable-handle", this.element).length ? {
                    n: ".ui-resizable-n",
                    e: ".ui-resizable-e",
                    s: ".ui-resizable-s",
                    w: ".ui-resizable-w",
                    se: ".ui-resizable-se",
                    sw: ".ui-resizable-sw",
                    ne: ".ui-resizable-ne",
                    nw: ".ui-resizable-nw"
                } : "e,s,se"), this.handles.constructor === String)
                for ("all" === this.handles && (this.handles = "n,e,s,w,se,sw,ne,nw"), t = this.handles.split(","), this.handles = {}, i = 0; i < t.length; i++) n = e.trim(t[i]), r = "ui-resizable-" + n, s = e("<div class='ui-resizable-handle " + r + "'></div>"), s.css({
                    zIndex: o.zIndex
                }), "se" === n && s.addClass("ui-icon ui-icon-gripsmall-diagonal-se"), this.handles[n] = ".ui-resizable-" + n, this.element.append(s);
            this._renderAxis = function (t) {
                var i, n, s, r;
                t = t || this.element;
                for (i in this.handles) this.handles[i].constructor === String && (this.handles[i] = e(this.handles[i], this.element).show()), this.elementIsWrapper && this.originalElement[0].nodeName.match(/textarea|input|select|button/i) && (n = e(this.handles[i], this.element), r = /sw|ne|nw|se|n|s/.test(i) ? n.outerHeight() : n.outerWidth(), s = ["padding", /ne|nw|n/.test(i) ? "Top" : /se|sw|s/.test(i) ? "Bottom" : /^e$/.test(i) ? "Right" : "Left"].join(""), t.css(s, r), this._proportionallyResize()), e(this.handles[i]).length
            }, this._renderAxis(this.element), this._handles = e(".ui-resizable-handle", this.element).disableSelection(), this._handles.mouseover(function () {
                a.resizing || (this.className && (s = this.className.match(/ui-resizable-(se|sw|ne|nw|n|e|s|w)/i)), a.axis = s && s[1] ? s[1] : "se")
            }), o.autoHide && (this._handles.hide(), e(this.element).addClass("ui-resizable-autohide").mouseenter(function () {
                o.disabled || (e(this).removeClass("ui-resizable-autohide"), a._handles.show())
            }).mouseleave(function () {
                o.disabled || a.resizing || (e(this).addClass("ui-resizable-autohide"), a._handles.hide())
            })), this._mouseInit()
        },
        _destroy: function () {
            this._mouseDestroy();
            var t, i = function (t) {
                e(t).removeClass("ui-resizable ui-resizable-disabled ui-resizable-resizing").removeData("resizable").removeData("ui-resizable").unbind(".resizable").find(".ui-resizable-handle").remove()
            };
            return this.elementIsWrapper && (i(this.element), t = this.element, this.originalElement.css({
                position: t.css("position"),
                width: t.outerWidth(),
                height: t.outerHeight(),
                top: t.css("top"),
                left: t.css("left")
            }).insertAfter(t), t.remove()), this.originalElement.css("resize", this.originalResizeStyle), i(this.originalElement), this
        },
        _mouseCapture: function (t) {
            var i, n, s = !1;
            for (i in this.handles) n = e(this.handles[i])[0], (n === t.target || e.contains(n, t.target)) && (s = !0);
            return !this.options.disabled && s
        },
        _mouseStart: function (t) {
            var n, s, r, a = this.options,
                o = this.element.position(),
                l = this.element;
            return this.resizing = !0, /absolute/.test(l.css("position")) ? l.css({
                position: "absolute",
                top: l.css("top"),
                left: l.css("left")
            }) : l.is(".ui-draggable") && l.css({
                position: "absolute",
                top: o.top,
                left: o.left
            }), this._renderProxy(), n = i(this.helper.css("left")), s = i(this.helper.css("top")), a.containment && (n += e(a.containment).scrollLeft() || 0, s += e(a.containment).scrollTop() || 0), this.offset = this.helper.offset(), this.position = {
                left: n,
                top: s
            }, this.size = this._helper ? {
                width: this.helper.width(),
                height: this.helper.height()
            } : {
                width: l.width(),
                height: l.height()
            }, this.originalSize = this._helper ? {
                width: l.outerWidth(),
                height: l.outerHeight()
            } : {
                width: l.width(),
                height: l.height()
            }, this.originalPosition = {
                left: n,
                top: s
            }, this.sizeDiff = {
                width: l.outerWidth() - l.width(),
                height: l.outerHeight() - l.height()
            }, this.originalMousePosition = {
                left: t.pageX,
                top: t.pageY
            }, this.aspectRatio = "number" == typeof a.aspectRatio ? a.aspectRatio : this.originalSize.width / this.originalSize.height || 1, r = e(".ui-resizable-" + this.axis).css("cursor"), e("body").css("cursor", "auto" === r ? this.axis + "-resize" : r), l.addClass("ui-resizable-resizing"), this._propagate("start", t), !0
        },
        _mouseDrag: function (t) {
            var i, n = this.helper,
                s = {},
                r = this.originalMousePosition,
                a = this.axis,
                o = this.position.top,
                l = this.position.left,
                u = this.size.width,
                h = this.size.height,
                f = t.pageX - r.left || 0,
                c = t.pageY - r.top || 0,
                d = this._change[a];
            return d ? (i = d.apply(this, [t, f, c]), this._updateVirtualBoundaries(t.shiftKey), (this._aspectRatio || t.shiftKey) && (i = this._updateRatio(i, t)), i = this._respectSize(i, t), this._updateCache(i), this._propagate("resize", t), this.position.top !== o && (s.top = this.position.top + "px"), this.position.left !== l && (s.left = this.position.left + "px"), this.size.width !== u && (s.width = this.size.width + "px"), this.size.height !== h && (s.height = this.size.height + "px"), n.css(s), !this._helper && this._proportionallyResizeElements.length && this._proportionallyResize(), e.isEmptyObject(s) || this._trigger("resize", t, this.ui()), !1) : !1
        },
        _mouseStop: function (t) {
            this.resizing = !1;
            var i, n, s, r, a, o, l, u = this.options,
                h = this;
            return this._helper && (i = this._proportionallyResizeElements, n = i.length && /textarea/i.test(i[0].nodeName), s = n && e.ui.hasScroll(i[0], "left") ? 0 : h.sizeDiff.height, r = n ? 0 : h.sizeDiff.width, a = {
                width: h.helper.width() - r,
                height: h.helper.height() - s
            }, o = parseInt(h.element.css("left"), 10) + (h.position.left - h.originalPosition.left) || null, l = parseInt(h.element.css("top"), 10) + (h.position.top - h.originalPosition.top) || null, u.animate || this.element.css(e.extend(a, {
                top: l,
                left: o
            })), h.helper.height(h.size.height), h.helper.width(h.size.width), this._helper && !u.animate && this._proportionallyResize()), e("body").css("cursor", "auto"), this.element.removeClass("ui-resizable-resizing"), this._propagate("stop", t), this._helper && this.helper.remove(), !1
        },
        _updateVirtualBoundaries: function (e) {
            var t, i, s, r, a, o = this.options;
            a = {
                minWidth: n(o.minWidth) ? o.minWidth : 0,
                maxWidth: n(o.maxWidth) ? o.maxWidth : 1 / 0,
                minHeight: n(o.minHeight) ? o.minHeight : 0,
                maxHeight: n(o.maxHeight) ? o.maxHeight : 1 / 0
            }, (this._aspectRatio || e) && (t = a.minHeight * this.aspectRatio, s = a.minWidth / this.aspectRatio, i = a.maxHeight * this.aspectRatio, r = a.maxWidth / this.aspectRatio, t > a.minWidth && (a.minWidth = t), s > a.minHeight && (a.minHeight = s), i < a.maxWidth && (a.maxWidth = i), r < a.maxHeight && (a.maxHeight = r)), this._vBoundaries = a
        },
        _updateCache: function (e) {
            this.offset = this.helper.offset(), n(e.left) && (this.position.left = e.left), n(e.top) && (this.position.top = e.top), n(e.height) && (this.size.height = e.height), n(e.width) && (this.size.width = e.width)
        },
        _updateRatio: function (e) {
            var t = this.position,
                i = this.size,
                s = this.axis;
            return n(e.height) ? e.width = e.height * this.aspectRatio : n(e.width) && (e.height = e.width / this.aspectRatio), "sw" === s && (e.left = t.left + (i.width - e.width), e.top = null), "nw" === s && (e.top = t.top + (i.height - e.height), e.left = t.left + (i.width - e.width)), e
        },
        _respectSize: function (e) {
            var t = this._vBoundaries,
                i = this.axis,
                s = n(e.width) && t.maxWidth && t.maxWidth < e.width,
                r = n(e.height) && t.maxHeight && t.maxHeight < e.height,
                a = n(e.width) && t.minWidth && t.minWidth > e.width,
                o = n(e.height) && t.minHeight && t.minHeight > e.height,
                l = this.originalPosition.left + this.originalSize.width,
                u = this.position.top + this.size.height,
                h = /sw|nw|w/.test(i),
                f = /nw|ne|n/.test(i);
            return a && (e.width = t.minWidth), o && (e.height = t.minHeight), s && (e.width = t.maxWidth), r && (e.height = t.maxHeight), a && h && (e.left = l - t.minWidth), s && h && (e.left = l - t.maxWidth), o && f && (e.top = u - t.minHeight), r && f && (e.top = u - t.maxHeight), e.width || e.height || e.left || !e.top ? e.width || e.height || e.top || !e.left || (e.left = null) : e.top = null, e
        },
        _proportionallyResize: function () {
            if (this._proportionallyResizeElements.length) {
                var e, t, i, n, s, r = this.helper || this.element;
                for (e = 0; e < this._proportionallyResizeElements.length; e++) {
                    if (s = this._proportionallyResizeElements[e], !this.borderDif)
                        for (this.borderDif = [], i = [s.css("borderTopWidth"), s.css("borderRightWidth"), s.css("borderBottomWidth"), s.css("borderLeftWidth")], n = [s.css("paddingTop"), s.css("paddingRight"), s.css("paddingBottom"), s.css("paddingLeft")], t = 0; t < i.length; t++) this.borderDif[t] = (parseInt(i[t], 10) || 0) + (parseInt(n[t], 10) || 0);
                    s.css({
                        height: r.height() - this.borderDif[0] - this.borderDif[2] || 0,
                        width: r.width() - this.borderDif[1] - this.borderDif[3] || 0
                    })
                }
            }
        },
        _renderProxy: function () {
            var t = this.element,
                i = this.options;
            this.elementOffset = t.offset(), this._helper ? (this.helper = this.helper || e("<div style='overflow:hidden;'></div>"), this.helper.addClass(this._helper).css({
                width: this.element.outerWidth() - 1,
                height: this.element.outerHeight() - 1,
                position: "absolute",
                left: this.elementOffset.left + "px",
                top: this.elementOffset.top + "px",
                zIndex: ++i.zIndex
            }), this.helper.appendTo("body").disableSelection()) : this.helper = this.element
        },
        _change: {
            e: function (e, t) {
                return {
                    width: this.originalSize.width + t
                }
            },
            w: function (e, t) {
                var i = this.originalSize,
                    n = this.originalPosition;
                return {
                    left: n.left + t,
                    width: i.width - t
                }
            },
            n: function (e, t, i) {
                var n = this.originalSize,
                    s = this.originalPosition;
                return {
                    top: s.top + i,
                    height: n.height - i
                }
            },
            s: function (e, t, i) {
                return {
                    height: this.originalSize.height + i
                }
            },
            se: function (t, i, n) {
                return e.extend(this._change.s.apply(this, arguments), this._change.e.apply(this, [t, i, n]))
            },
            sw: function (t, i, n) {
                return e.extend(this._change.s.apply(this, arguments), this._change.w.apply(this, [t, i, n]))
            },
            ne: function (t, i, n) {
                return e.extend(this._change.n.apply(this, arguments), this._change.e.apply(this, [t, i, n]))
            },
            nw: function (t, i, n) {
                return e.extend(this._change.n.apply(this, arguments), this._change.w.apply(this, [t, i, n]))
            }
        },
        _propagate: function (t, i) {
            e.ui.plugin.call(this, t, [i, this.ui()]), "resize" !== t && this._trigger(t, i, this.ui())
        },
        plugins: {},
        ui: function () {
            return {
                originalElement: this.originalElement,
                element: this.element,
                helper: this.helper,
                position: this.position,
                size: this.size,
                originalSize: this.originalSize,
                originalPosition: this.originalPosition
            }
        }
    }), e.ui.plugin.add("resizable", "animate", {
        stop: function (t) {
            var i = e(this).data("ui-resizable"),
                n = i.options,
                s = i._proportionallyResizeElements,
                r = s.length && /textarea/i.test(s[0].nodeName),
                a = r && e.ui.hasScroll(s[0], "left") ? 0 : i.sizeDiff.height,
                o = r ? 0 : i.sizeDiff.width,
                l = {
                    width: i.size.width - o,
                    height: i.size.height - a
                },
                u = parseInt(i.element.css("left"), 10) + (i.position.left - i.originalPosition.left) || null,
                h = parseInt(i.element.css("top"), 10) + (i.position.top - i.originalPosition.top) || null;
            i.element.animate(e.extend(l, h && u ? {
                top: h,
                left: u
            } : {}), {
                duration: n.animateDuration,
                easing: n.animateEasing,
                step: function () {
                    var n = {
                        width: parseInt(i.element.css("width"), 10),
                        height: parseInt(i.element.css("height"), 10),
                        top: parseInt(i.element.css("top"), 10),
                        left: parseInt(i.element.css("left"), 10)
                    };
                    s && s.length && e(s[0]).css({
                        width: n.width,
                        height: n.height
                    }), i._updateCache(n), i._propagate("resize", t)
                }
            })
        }
    }), e.ui.plugin.add("resizable", "containment", {
        start: function () {
            var t, n, s, r, a, o, l, u = e(this).data("ui-resizable"),
                h = u.options,
                f = u.element,
                c = h.containment,
                d = c instanceof e ? c.get(0) : /parent/.test(c) ? f.parent().get(0) : c;
            d && (u.containerElement = e(d), /document/.test(c) || c === document ? (u.containerOffset = {
                left: 0,
                top: 0
            }, u.containerPosition = {
                left: 0,
                top: 0
            }, u.parentData = {
                element: e(document),
                left: 0,
                top: 0,
                width: e(document).width(),
                height: e(document).height() || document.body.parentNode.scrollHeight
            }) : (t = e(d), n = [], e(["Top", "Right", "Left", "Bottom"]).each(function (e, s) {
                n[e] = i(t.css("padding" + s))
            }), u.containerOffset = t.offset(), u.containerPosition = t.position(), u.containerSize = {
                height: t.innerHeight() - n[3],
                width: t.innerWidth() - n[1]
            }, s = u.containerOffset, r = u.containerSize.height, a = u.containerSize.width, o = e.ui.hasScroll(d, "left") ? d.scrollWidth : a, l = e.ui.hasScroll(d) ? d.scrollHeight : r, u.parentData = {
                element: d,
                left: s.left,
                top: s.top,
                width: o,
                height: l
            }))
        },
        resize: function (t) {
            var i, n, s, r, a = e(this).data("ui-resizable"),
                o = a.options,
                l = a.containerOffset,
                u = a.position,
                h = a._aspectRatio || t.shiftKey,
                f = {
                    top: 0,
                    left: 0
                },
                c = a.containerElement;
            c[0] !== document && /static/.test(c.css("position")) && (f = l), u.left < (a._helper ? l.left : 0) && (a.size.width = a.size.width + (a._helper ? a.position.left - l.left : a.position.left - f.left), h && (a.size.height = a.size.width / a.aspectRatio), a.position.left = o.helper ? l.left : 0), u.top < (a._helper ? l.top : 0) && (a.size.height = a.size.height + (a._helper ? a.position.top - l.top : a.position.top), h && (a.size.width = a.size.height * a.aspectRatio), a.position.top = a._helper ? l.top : 0), a.offset.left = a.parentData.left + a.position.left, a.offset.top = a.parentData.top + a.position.top, i = Math.abs((a._helper ? a.offset.left - f.left : a.offset.left - f.left) + a.sizeDiff.width), n = Math.abs((a._helper ? a.offset.top - f.top : a.offset.top - l.top) + a.sizeDiff.height), s = a.containerElement.get(0) === a.element.parent().get(0), r = /relative|absolute/.test(a.containerElement.css("position")), s && r && (i -= Math.abs(a.parentData.left)), i + a.size.width >= a.parentData.width && (a.size.width = a.parentData.width - i, h && (a.size.height = a.size.width / a.aspectRatio)), n + a.size.height >= a.parentData.height && (a.size.height = a.parentData.height - n, h && (a.size.width = a.size.height * a.aspectRatio))
        },
        stop: function () {
            var t = e(this).data("ui-resizable"),
                i = t.options,
                n = t.containerOffset,
                s = t.containerPosition,
                r = t.containerElement,
                a = e(t.helper),
                o = a.offset(),
                l = a.outerWidth() - t.sizeDiff.width,
                u = a.outerHeight() - t.sizeDiff.height;
            t._helper && !i.animate && /relative/.test(r.css("position")) && e(this).css({
                left: o.left - s.left - n.left,
                width: l,
                height: u
            }), t._helper && !i.animate && /static/.test(r.css("position")) && e(this).css({
                left: o.left - s.left - n.left,
                width: l,
                height: u
            })
        }
    }), e.ui.plugin.add("resizable", "alsoResize", {
        start: function () {
            var t = e(this).data("ui-resizable"),
                i = t.options,
                n = function (t) {
                    e(t).each(function () {
                        var t = e(this);
                        t.data("ui-resizable-alsoresize", {
                            width: parseInt(t.width(), 10),
                            height: parseInt(t.height(), 10),
                            left: parseInt(t.css("left"), 10),
                            top: parseInt(t.css("top"), 10)
                        })
                    })
                };
            "object" != typeof i.alsoResize || i.alsoResize.parentNode ? n(i.alsoResize) : i.alsoResize.length ? (i.alsoResize = i.alsoResize[0], n(i.alsoResize)) : e.each(i.alsoResize, function (e) {
                n(e)
            })
        },
        resize: function (t, i) {
            var n = e(this).data("ui-resizable"),
                s = n.options,
                r = n.originalSize,
                a = n.originalPosition,
                o = {
                    height: n.size.height - r.height || 0,
                    width: n.size.width - r.width || 0,
                    top: n.position.top - a.top || 0,
                    left: n.position.left - a.left || 0
                },
                l = function (t, n) {
                    e(t).each(function () {
                        var t = e(this),
                            s = e(this).data("ui-resizable-alsoresize"),
                            r = {},
                            a = n && n.length ? n : t.parents(i.originalElement[0]).length ? ["width", "height"] : ["width", "height", "top", "left"];
                        e.each(a, function (e, t) {
                            var i = (s[t] || 0) + (o[t] || 0);
                            i && i >= 0 && (r[t] = i || null)
                        }), t.css(r)
                    })
                };
            "object" != typeof s.alsoResize || s.alsoResize.nodeType ? l(s.alsoResize) : e.each(s.alsoResize, function (e, t) {
                l(e, t)
            })
        },
        stop: function () {
            e(this).removeData("resizable-alsoresize")
        }
    }), e.ui.plugin.add("resizable", "ghost", {
        start: function () {
            var t = e(this).data("ui-resizable"),
                i = t.options,
                n = t.size;
            t.ghost = t.originalElement.clone(), t.ghost.css({
                opacity: .25,
                display: "block",
                position: "relative",
                height: n.height,
                width: n.width,
                margin: 0,
                left: 0,
                top: 0
            }).addClass("ui-resizable-ghost").addClass("string" == typeof i.ghost ? i.ghost : ""), t.ghost.appendTo(t.helper)
        },
        resize: function () {
            var t = e(this).data("ui-resizable");
            t.ghost && t.ghost.css({
                position: "relative",
                height: t.size.height,
                width: t.size.width
            })
        },
        stop: function () {
            var t = e(this).data("ui-resizable");
            t.ghost && t.helper && t.helper.get(0).removeChild(t.ghost.get(0))
        }
    }), e.ui.plugin.add("resizable", "grid", {
        resize: function () {
            var t = e(this).data("ui-resizable"),
                i = t.options,
                n = t.size,
                s = t.originalSize,
                r = t.originalPosition,
                a = t.axis,
                o = "number" == typeof i.grid ? [i.grid, i.grid] : i.grid,
                l = o[0] || 1,
                u = o[1] || 1,
                h = Math.round((n.width - s.width) / l) * l,
                f = Math.round((n.height - s.height) / u) * u,
                c = s.width + h,
                d = s.height + f,
                p = i.maxWidth && i.maxWidth < c,
                g = i.maxHeight && i.maxHeight < d,
                m = i.minWidth && i.minWidth > c,
                v = i.minHeight && i.minHeight > d;
            i.grid = o, m && (c += l), v && (d += u), p && (c -= l), g && (d -= u), /^(se|s|e)$/.test(a) ? (t.size.width = c, t.size.height = d) : /^(ne)$/.test(a) ? (t.size.width = c, t.size.height = d, t.position.top = r.top - f) : /^(sw)$/.test(a) ? (t.size.width = c, t.size.height = d, t.position.left = r.left - h) : (d - u > 0 ? (t.size.height = d, t.position.top = r.top - f) : (t.size.height = u, t.position.top = r.top + s.height - u), c - l > 0 ? (t.size.width = c, t.position.left = r.left - h) : (t.size.width = l, t.position.left = r.left + s.width - l))
        }
    })
}(jQuery),
function (e) {
    e.widget("ui.selectable", e.ui.mouse, {
        version: "1.10.4",
        options: {
            appendTo: "body",
            autoRefresh: !0,
            distance: 0,
            filter: "*",
            tolerance: "touch",
            selected: null,
            selecting: null,
            start: null,
            stop: null,
            unselected: null,
            unselecting: null
        },
        _create: function () {
            var t, i = this;
            this.element.addClass("ui-selectable"), this.dragged = !1, this.refresh = function () {
                t = e(i.options.filter, i.element[0]), t.addClass("ui-selectee"), t.each(function () {
                    var t = e(this),
                        i = t.offset();
                    e.data(this, "selectable-item", {
                        element: this,
                        $element: t,
                        left: i.left,
                        top: i.top,
                        right: i.left + t.outerWidth(),
                        bottom: i.top + t.outerHeight(),
                        startselected: !1,
                        selected: t.hasClass("ui-selected"),
                        selecting: t.hasClass("ui-selecting"),
                        unselecting: t.hasClass("ui-unselecting")
                    })
                })
            }, this.refresh(), this.selectees = t.addClass("ui-selectee"), this._mouseInit(), this.helper = e("<div class='ui-selectable-helper'></div>")
        },
        _destroy: function () {
            this.selectees.removeClass("ui-selectee").removeData("selectable-item"), this.element.removeClass("ui-selectable ui-selectable-disabled"), this._mouseDestroy()
        },
        _mouseStart: function (t) {
            var i = this,
                n = this.options;
            this.opos = [t.pageX, t.pageY], this.options.disabled || (this.selectees = e(n.filter, this.element[0]), this._trigger("start", t), e(n.appendTo).append(this.helper), this.helper.css({
                left: t.pageX,
                top: t.pageY,
                width: 0,
                height: 0
            }), n.autoRefresh && this.refresh(), this.selectees.filter(".ui-selected").each(function () {
                var n = e.data(this, "selectable-item");
                n.startselected = !0, t.metaKey || t.ctrlKey || (n.$element.removeClass("ui-selected"), n.selected = !1, n.$element.addClass("ui-unselecting"), n.unselecting = !0, i._trigger("unselecting", t, {
                    unselecting: n.element
                }))
            }), e(t.target).parents().addBack().each(function () {
                var n, s = e.data(this, "selectable-item");
                return s ? (n = !t.metaKey && !t.ctrlKey || !s.$element.hasClass("ui-selected"), s.$element.removeClass(n ? "ui-unselecting" : "ui-selected").addClass(n ? "ui-selecting" : "ui-unselecting"), s.unselecting = !n, s.selecting = n, s.selected = n, n ? i._trigger("selecting", t, {
                    selecting: s.element
                }) : i._trigger("unselecting", t, {
                    unselecting: s.element
                }), !1) : void 0
            }))
        },
        _mouseDrag: function (t) {
            if (this.dragged = !0, !this.options.disabled) {
                var i, n = this,
                    s = this.options,
                    r = this.opos[0],
                    a = this.opos[1],
                    o = t.pageX,
                    l = t.pageY;
                return r > o && (i = o, o = r, r = i), a > l && (i = l, l = a, a = i), this.helper.css({
                    left: r,
                    top: a,
                    width: o - r,
                    height: l - a
                }), this.selectees.each(function () {
                    var i = e.data(this, "selectable-item"),
                        u = !1;
                    i && i.element !== n.element[0] && ("touch" === s.tolerance ? u = !(i.left > o || i.right < r || i.top > l || i.bottom < a) : "fit" === s.tolerance && (u = i.left > r && i.right < o && i.top > a && i.bottom < l), u ? (i.selected && (i.$element.removeClass("ui-selected"), i.selected = !1), i.unselecting && (i.$element.removeClass("ui-unselecting"), i.unselecting = !1), i.selecting || (i.$element.addClass("ui-selecting"), i.selecting = !0, n._trigger("selecting", t, {
                        selecting: i.element
                    }))) : (i.selecting && ((t.metaKey || t.ctrlKey) && i.startselected ? (i.$element.removeClass("ui-selecting"), i.selecting = !1, i.$element.addClass("ui-selected"), i.selected = !0) : (i.$element.removeClass("ui-selecting"), i.selecting = !1, i.startselected && (i.$element.addClass("ui-unselecting"), i.unselecting = !0), n._trigger("unselecting", t, {
                        unselecting: i.element
                    }))), i.selected && (t.metaKey || t.ctrlKey || i.startselected || (i.$element.removeClass("ui-selected"), i.selected = !1, i.$element.addClass("ui-unselecting"), i.unselecting = !0, n._trigger("unselecting", t, {
                        unselecting: i.element
                    })))))
                }), !1
            }
        },
        _mouseStop: function (t) {
            var i = this;
            return this.dragged = !1, e(".ui-unselecting", this.element[0]).each(function () {
                var n = e.data(this, "selectable-item");
                n.$element.removeClass("ui-unselecting"), n.unselecting = !1, n.startselected = !1, i._trigger("unselected", t, {
                    unselected: n.element
                })
            }), e(".ui-selecting", this.element[0]).each(function () {
                var n = e.data(this, "selectable-item");
                n.$element.removeClass("ui-selecting").addClass("ui-selected"), n.selecting = !1, n.selected = !0, n.startselected = !0, i._trigger("selected", t, {
                    selected: n.element
                })
            }), this._trigger("stop", t), this.helper.remove(), !1
        }
    })
}(jQuery),
function (e) {
    function i(e, t, i) {
        return e > t && t + i > e
    }

    function n(e) {
        return /left|right/.test(e.css("float")) || /inline|table-cell/.test(e.css("display"))
    }
    e.widget("ui.sortable", e.ui.mouse, {
        version: "1.10.4",
        widgetEventPrefix: "sort",
        ready: !1,
        options: {
            appendTo: "parent",
            axis: !1,
            connectWith: !1,
            containment: !1,
            cursor: "auto",
            cursorAt: !1,
            dropOnEmpty: !0,
            forcePlaceholderSize: !1,
            forceHelperSize: !1,
            grid: !1,
            handle: !1,
            helper: "original",
            items: "> *",
            opacity: !1,
            placeholder: !1,
            revert: !1,
            scroll: !0,
            scrollSensitivity: 20,
            scrollSpeed: 20,
            scope: "default",
            tolerance: "intersect",
            zIndex: 1e3,
            activate: null,
            beforeStop: null,
            change: null,
            deactivate: null,
            out: null,
            over: null,
            receive: null,
            remove: null,
            sort: null,
            start: null,
            stop: null,
            update: null
        },
        _create: function () {
            var e = this.options;
            this.containerCache = {}, this.element.addClass("ui-sortable"), this.refresh(), this.floating = this.items.length ? "x" === e.axis || n(this.items[0].item) : !1, this.offset = this.element.offset(), this._mouseInit(), this.ready = !0
        },
        _destroy: function () {
            this.element.removeClass("ui-sortable ui-sortable-disabled"), this._mouseDestroy();
            for (var e = this.items.length - 1; e >= 0; e--) this.items[e].item.removeData(this.widgetName + "-item");
            return this
        },
        _setOption: function (t, i) {
            "disabled" === t ? (this.options[t] = i, this.widget().toggleClass("ui-sortable-disabled", !!i)) : e.Widget.prototype._setOption.apply(this, arguments)
        },
        _mouseCapture: function (t, i) {
            var n = null,
                s = !1,
                r = this;
            return this.reverting ? !1 : this.options.disabled || "static" === this.options.type ? !1 : (this._refreshItems(t), e(t.target).parents().each(function () {
                return e.data(this, r.widgetName + "-item") === r ? (n = e(this), !1) : void 0
            }), e.data(t.target, r.widgetName + "-item") === r && (n = e(t.target)), n && (!this.options.handle || i || (e(this.options.handle, n).find("*").addBack().each(function () {
                this === t.target && (s = !0)
            }), s)) ? (this.currentItem = n, this._removeCurrentsFromItems(), !0) : !1)
        },
        _mouseStart: function (t, i, n) {
            var s, r, a = this.options;
            if (this.currentContainer = this, this.refreshPositions(), this.helper = this._createHelper(t), this._cacheHelperProportions(), this._cacheMargins(), this.scrollParent = this.helper.scrollParent(), this.offset = this.currentItem.offset(), this.offset = {
                    top: this.offset.top - this.margins.top,
                    left: this.offset.left - this.margins.left
                }, e.extend(this.offset, {
                    click: {
                        left: t.pageX - this.offset.left,
                        top: t.pageY - this.offset.top
                    },
                    parent: this._getParentOffset(),
                    relative: this._getRelativeOffset()
                }), this.helper.css("position", "absolute"), this.cssPosition = this.helper.css("position"), this.originalPosition = this._generatePosition(t), this.originalPageX = t.pageX, this.originalPageY = t.pageY, a.cursorAt && this._adjustOffsetFromHelper(a.cursorAt), this.domPosition = {
                    prev: this.currentItem.prev()[0],
                    parent: this.currentItem.parent()[0]
                }, this.helper[0] !== this.currentItem[0] && this.currentItem.hide(), this._createPlaceholder(), a.containment && this._setContainment(), a.cursor && "auto" !== a.cursor && (r = this.document.find("body"), this.storedCursor = r.css("cursor"), r.css("cursor", a.cursor), this.storedStylesheet = e("<style>*{ cursor: " + a.cursor + " !important; }</style>").appendTo(r)), a.opacity && (this.helper.css("opacity") && (this._storedOpacity = this.helper.css("opacity")), this.helper.css("opacity", a.opacity)), a.zIndex && (this.helper.css("zIndex") && (this._storedZIndex = this.helper.css("zIndex")), this.helper.css("zIndex", a.zIndex)), this.scrollParent[0] !== document && "HTML" !== this.scrollParent[0].tagName && (this.overflowOffset = this.scrollParent.offset()), this._trigger("start", t, this._uiHash()), this._preserveHelperProportions || this._cacheHelperProportions(), !n)
                for (s = this.containers.length - 1; s >= 0; s--) this.containers[s]._trigger("activate", t, this._uiHash(this));
            return e.ui.ddmanager && (e.ui.ddmanager.current = this), e.ui.ddmanager && !a.dropBehaviour && e.ui.ddmanager.prepareOffsets(this, t), this.dragging = !0, this.helper.addClass("ui-sortable-helper"), this._mouseDrag(t), !0
        },
        _mouseDrag: function (t) {
            var i, n, s, r, a = this.options,
                o = !1;
            for (this.position = this._generatePosition(t), this.positionAbs = this._convertPositionTo("absolute"), this.lastPositionAbs || (this.lastPositionAbs = this.positionAbs), this.options.scroll && (this.scrollParent[0] !== document && "HTML" !== this.scrollParent[0].tagName ? (this.overflowOffset.top + this.scrollParent[0].offsetHeight - t.pageY < a.scrollSensitivity ? this.scrollParent[0].scrollTop = o = this.scrollParent[0].scrollTop + a.scrollSpeed : t.pageY - this.overflowOffset.top < a.scrollSensitivity && (this.scrollParent[0].scrollTop = o = this.scrollParent[0].scrollTop - a.scrollSpeed), this.overflowOffset.left + this.scrollParent[0].offsetWidth - t.pageX < a.scrollSensitivity ? this.scrollParent[0].scrollLeft = o = this.scrollParent[0].scrollLeft + a.scrollSpeed : t.pageX - this.overflowOffset.left < a.scrollSensitivity && (this.scrollParent[0].scrollLeft = o = this.scrollParent[0].scrollLeft - a.scrollSpeed)) : (t.pageY - e(document).scrollTop() < a.scrollSensitivity ? o = e(document).scrollTop(e(document).scrollTop() - a.scrollSpeed) : e(window).height() - (t.pageY - e(document).scrollTop()) < a.scrollSensitivity && (o = e(document).scrollTop(e(document).scrollTop() + a.scrollSpeed)), t.pageX - e(document).scrollLeft() < a.scrollSensitivity ? o = e(document).scrollLeft(e(document).scrollLeft() - a.scrollSpeed) : e(window).width() - (t.pageX - e(document).scrollLeft()) < a.scrollSensitivity && (o = e(document).scrollLeft(e(document).scrollLeft() + a.scrollSpeed))), o !== !1 && e.ui.ddmanager && !a.dropBehaviour && e.ui.ddmanager.prepareOffsets(this, t)), this.positionAbs = this._convertPositionTo("absolute"), this.options.axis && "y" === this.options.axis || (this.helper[0].style.left = this.position.left + "px"), this.options.axis && "x" === this.options.axis || (this.helper[0].style.top = this.position.top + "px"), i = this.items.length - 1; i >= 0; i--)
                if (n = this.items[i], s = n.item[0], r = this._intersectsWithPointer(n), r && n.instance === this.currentContainer && s !== this.currentItem[0] && this.placeholder[1 === r ? "next" : "prev"]()[0] !== s && !e.contains(this.placeholder[0], s) && ("semi-dynamic" === this.options.type ? !e.contains(this.element[0], s) : !0)) {
                    if (this.direction = 1 === r ? "down" : "up", "pointer" !== this.options.tolerance && !this._intersectsWithSides(n)) break;
                    this._rearrange(t, n), this._trigger("change", t, this._uiHash());
                    break
                }
            return this._contactContainers(t), e.ui.ddmanager && e.ui.ddmanager.drag(this, t), this._trigger("sort", t, this._uiHash()), this.lastPositionAbs = this.positionAbs, !1
        },
        _mouseStop: function (t, i) {
            if (t) {
                if (e.ui.ddmanager && !this.options.dropBehaviour && e.ui.ddmanager.drop(this, t), this.options.revert) {
                    var n = this,
                        s = this.placeholder.offset(),
                        r = this.options.axis,
                        a = {};
                    r && "x" !== r || (a.left = s.left - this.offset.parent.left - this.margins.left + (this.offsetParent[0] === document.body ? 0 : this.offsetParent[0].scrollLeft)), r && "y" !== r || (a.top = s.top - this.offset.parent.top - this.margins.top + (this.offsetParent[0] === document.body ? 0 : this.offsetParent[0].scrollTop)), this.reverting = !0, e(this.helper).animate(a, parseInt(this.options.revert, 10) || 500, function () {
                        n._clear(t)
                    })
                } else this._clear(t, i);
                return !1
            }
        },
        cancel: function () {
            if (this.dragging) {
                this._mouseUp({
                    target: null
                }), "original" === this.options.helper ? this.currentItem.css(this._storedCSS).removeClass("ui-sortable-helper") : this.currentItem.show();
                for (var t = this.containers.length - 1; t >= 0; t--) this.containers[t]._trigger("deactivate", null, this._uiHash(this)), this.containers[t].containerCache.over && (this.containers[t]._trigger("out", null, this._uiHash(this)), this.containers[t].containerCache.over = 0)
            }
            return this.placeholder && (this.placeholder[0].parentNode && this.placeholder[0].parentNode.removeChild(this.placeholder[0]), "original" !== this.options.helper && this.helper && this.helper[0].parentNode && this.helper.remove(), e.extend(this, {
                helper: null,
                dragging: !1,
                reverting: !1,
                _noFinalSort: null
            }), this.domPosition.prev ? e(this.domPosition.prev).after(this.currentItem) : e(this.domPosition.parent).prepend(this.currentItem)), this
        },
        serialize: function (t) {
            var i = this._getItemsAsjQuery(t && t.connected),
                n = [];
            return t = t || {}, e(i).each(function () {
                var i = (e(t.item || this).attr(t.attribute || "id") || "").match(t.expression || /(.+)[\-=_](.+)/);
                i && n.push((t.key || i[1] + "[]") + "=" + (t.key && t.expression ? i[1] : i[2]))
            }), !n.length && t.key && n.push(t.key + "="), n.join("&")
        },
        toArray: function (t) {
            var i = this._getItemsAsjQuery(t && t.connected),
                n = [];
            return t = t || {}, i.each(function () {
                n.push(e(t.item || this).attr(t.attribute || "id") || "")
            }), n
        },
        _intersectsWith: function (e) {
            var t = this.positionAbs.left,
                i = t + this.helperProportions.width,
                n = this.positionAbs.top,
                s = n + this.helperProportions.height,
                r = e.left,
                a = r + e.width,
                o = e.top,
                l = o + e.height,
                u = this.offset.click.top,
                h = this.offset.click.left,
                f = "x" === this.options.axis || n + u > o && l > n + u,
                c = "y" === this.options.axis || t + h > r && a > t + h,
                d = f && c;
            return "pointer" === this.options.tolerance || this.options.forcePointerForContainers || "pointer" !== this.options.tolerance && this.helperProportions[this.floating ? "width" : "height"] > e[this.floating ? "width" : "height"] ? d : r < t + this.helperProportions.width / 2 && i - this.helperProportions.width / 2 < a && o < n + this.helperProportions.height / 2 && s - this.helperProportions.height / 2 < l
        },
        _intersectsWithPointer: function (e) {
            var t = "x" === this.options.axis || i(this.positionAbs.top + this.offset.click.top, e.top, e.height),
                n = "y" === this.options.axis || i(this.positionAbs.left + this.offset.click.left, e.left, e.width),
                s = t && n,
                r = this._getDragVerticalDirection(),
                a = this._getDragHorizontalDirection();
            return s ? this.floating ? a && "right" === a || "down" === r ? 2 : 1 : r && ("down" === r ? 2 : 1) : !1
        },
        _intersectsWithSides: function (e) {
            var t = i(this.positionAbs.top + this.offset.click.top, e.top + e.height / 2, e.height),
                n = i(this.positionAbs.left + this.offset.click.left, e.left + e.width / 2, e.width),
                s = this._getDragVerticalDirection(),
                r = this._getDragHorizontalDirection();
            return this.floating && r ? "right" === r && n || "left" === r && !n : s && ("down" === s && t || "up" === s && !t)
        },
        _getDragVerticalDirection: function () {
            var e = this.positionAbs.top - this.lastPositionAbs.top;
            return 0 !== e && (e > 0 ? "down" : "up")
        },
        _getDragHorizontalDirection: function () {
            var e = this.positionAbs.left - this.lastPositionAbs.left;
            return 0 !== e && (e > 0 ? "right" : "left")
        },
        refresh: function (e) {
            return this._refreshItems(e), this.refreshPositions(), this
        },
        _connectWith: function () {
            var e = this.options;
            return e.connectWith.constructor === String ? [e.connectWith] : e.connectWith
        },
        _getItemsAsjQuery: function (t) {
            function u() {
                a.push(this)
            }
            var i, n, s, r, a = [],
                o = [],
                l = this._connectWith();
            if (l && t)
                for (i = l.length - 1; i >= 0; i--)
                    for (s = e(l[i]), n = s.length - 1; n >= 0; n--) r = e.data(s[n], this.widgetFullName), r && r !== this && !r.options.disabled && o.push([e.isFunction(r.options.items) ? r.options.items.call(r.element) : e(r.options.items, r.element).not(".ui-sortable-helper").not(".ui-sortable-placeholder"), r]);
            for (o.push([e.isFunction(this.options.items) ? this.options.items.call(this.element, null, {
                    options: this.options,
                    item: this.currentItem
                }) : e(this.options.items, this.element).not(".ui-sortable-helper").not(".ui-sortable-placeholder"), this]), i = o.length - 1; i >= 0; i--) o[i][0].each(u);
            return e(a)
        },
        _removeCurrentsFromItems: function () {
            var t = this.currentItem.find(":data(" + this.widgetName + "-item)");
            this.items = e.grep(this.items, function (e) {
                for (var i = 0; i < t.length; i++)
                    if (t[i] === e.item[0]) return !1;
                return !0
            })
        },
        _refreshItems: function (t) {
            this.items = [], this.containers = [this];
            var i, n, s, r, a, o, l, u, h = this.items,
                f = [[e.isFunction(this.options.items) ? this.options.items.call(this.element[0], t, {
                    item: this.currentItem
                }) : e(this.options.items, this.element), this]],
                c = this._connectWith();
            if (c && this.ready)
                for (i = c.length - 1; i >= 0; i--)
                    for (s = e(c[i]), n = s.length - 1; n >= 0; n--) r = e.data(s[n], this.widgetFullName), r && r !== this && !r.options.disabled && (f.push([e.isFunction(r.options.items) ? r.options.items.call(r.element[0], t, {
                        item: this.currentItem
                    }) : e(r.options.items, r.element), r]), this.containers.push(r));
            for (i = f.length - 1; i >= 0; i--)
                for (a = f[i][1], o = f[i][0], n = 0, u = o.length; u > n; n++) l = e(o[n]), l.data(this.widgetName + "-item", a), h.push({
                    item: l,
                    instance: a,
                    width: 0,
                    height: 0,
                    left: 0,
                    top: 0
                })
        },
        refreshPositions: function (t) {
            this.offsetParent && this.helper && (this.offset.parent = this._getParentOffset());
            var i, n, s, r;
            for (i = this.items.length - 1; i >= 0; i--) n = this.items[i], n.instance !== this.currentContainer && this.currentContainer && n.item[0] !== this.currentItem[0] || (s = this.options.toleranceElement ? e(this.options.toleranceElement, n.item) : n.item, t || (n.width = s.outerWidth(), n.height = s.outerHeight()), r = s.offset(), n.left = r.left, n.top = r.top);
            if (this.options.custom && this.options.custom.refreshContainers) this.options.custom.refreshContainers.call(this);
            else
                for (i = this.containers.length - 1; i >= 0; i--) r = this.containers[i].element.offset(), this.containers[i].containerCache.left = r.left, this.containers[i].containerCache.top = r.top, this.containers[i].containerCache.width = this.containers[i].element.outerWidth(), this.containers[i].containerCache.height = this.containers[i].element.outerHeight();
            return this
        },
        _createPlaceholder: function (t) {
            t = t || this;
            var i, n = t.options;
            n.placeholder && n.placeholder.constructor !== String || (i = n.placeholder, n.placeholder = {
                element: function () {
                    var n = t.currentItem[0].nodeName.toLowerCase(),
                        s = e("<" + n + ">", t.document[0]).addClass(i || t.currentItem[0].className + " ui-sortable-placeholder").removeClass("ui-sortable-helper");
                    return "tr" === n ? t.currentItem.children().each(function () {
                        e("<td>&#160;</td>", t.document[0]).attr("colspan", e(this).attr("colspan") || 1).appendTo(s)
                    }) : "img" === n && s.attr("src", t.currentItem.attr("src")), i || s.css("visibility", "hidden"), s
                },
                update: function (e, s) {
                    (!i || n.forcePlaceholderSize) && (s.height() || s.height(t.currentItem.innerHeight() - parseInt(t.currentItem.css("paddingTop") || 0, 10) - parseInt(t.currentItem.css("paddingBottom") || 0, 10)), s.width() || s.width(t.currentItem.innerWidth() - parseInt(t.currentItem.css("paddingLeft") || 0, 10) - parseInt(t.currentItem.css("paddingRight") || 0, 10)))
                }
            }), t.placeholder = e(n.placeholder.element.call(t.element, t.currentItem)), t.currentItem.after(t.placeholder), n.placeholder.update(t, t.placeholder)
        },
        _contactContainers: function (t) {
            var s, r, a, o, l, u, h, f, c, d, p = null,
                g = null;
            for (s = this.containers.length - 1; s >= 0; s--)
                if (!e.contains(this.currentItem[0], this.containers[s].element[0]))
                    if (this._intersectsWith(this.containers[s].containerCache)) {
                        if (p && e.contains(this.containers[s].element[0], p.element[0])) continue;
                        p = this.containers[s], g = s
                    } else this.containers[s].containerCache.over && (this.containers[s]._trigger("out", t, this._uiHash(this)), this.containers[s].containerCache.over = 0);
            if (p)
                if (1 === this.containers.length) this.containers[g].containerCache.over || (this.containers[g]._trigger("over", t, this._uiHash(this)), this.containers[g].containerCache.over = 1);
                else {
                    for (a = 1e4, o = null, d = p.floating || n(this.currentItem), l = d ? "left" : "top", u = d ? "width" : "height", h = this.positionAbs[l] + this.offset.click[l], r = this.items.length - 1; r >= 0; r--) e.contains(this.containers[g].element[0], this.items[r].item[0]) && this.items[r].item[0] !== this.currentItem[0] && (!d || i(this.positionAbs.top + this.offset.click.top, this.items[r].top, this.items[r].height)) && (f = this.items[r].item.offset()[l], c = !1, Math.abs(f - h) > Math.abs(f + this.items[r][u] - h) && (c = !0, f += this.items[r][u]), Math.abs(f - h) < a && (a = Math.abs(f - h), o = this.items[r], this.direction = c ? "up" : "down"));
                    if (!o && !this.options.dropOnEmpty) return;
                    if (this.currentContainer === this.containers[g]) return;
                    o ? this._rearrange(t, o, null, !0) : this._rearrange(t, null, this.containers[g].element, !0), this._trigger("change", t, this._uiHash()), this.containers[g]._trigger("change", t, this._uiHash(this)), this.currentContainer = this.containers[g], this.options.placeholder.update(this.currentContainer, this.placeholder), this.containers[g]._trigger("over", t, this._uiHash(this)), this.containers[g].containerCache.over = 1
                }
        },
        _createHelper: function (t) {
            var i = this.options,
                n = e.isFunction(i.helper) ? e(i.helper.apply(this.element[0], [t, this.currentItem])) : "clone" === i.helper ? this.currentItem.clone() : this.currentItem;
            return n.parents("body").length || e("parent" !== i.appendTo ? i.appendTo : this.currentItem[0].parentNode)[0].appendChild(n[0]), n[0] === this.currentItem[0] && (this._storedCSS = {
                width: this.currentItem[0].style.width,
                height: this.currentItem[0].style.height,
                position: this.currentItem.css("position"),
                top: this.currentItem.css("top"),
                left: this.currentItem.css("left")
            }), (!n[0].style.width || i.forceHelperSize) && n.width(this.currentItem.width()), (!n[0].style.height || i.forceHelperSize) && n.height(this.currentItem.height()), n
        },
        _adjustOffsetFromHelper: function (t) {
            "string" == typeof t && (t = t.split(" ")), e.isArray(t) && (t = {
                left: +t[0],
                top: +t[1] || 0
            }), "left" in t && (this.offset.click.left = t.left + this.margins.left), "right" in t && (this.offset.click.left = this.helperProportions.width - t.right + this.margins.left), "top" in t && (this.offset.click.top = t.top + this.margins.top), "bottom" in t && (this.offset.click.top = this.helperProportions.height - t.bottom + this.margins.top)
        },
        _getParentOffset: function () {
            this.offsetParent = this.helper.offsetParent();
            var t = this.offsetParent.offset();
            return "absolute" === this.cssPosition && this.scrollParent[0] !== document && e.contains(this.scrollParent[0], this.offsetParent[0]) && (t.left += this.scrollParent.scrollLeft(), t.top += this.scrollParent.scrollTop()), (this.offsetParent[0] === document.body || this.offsetParent[0].tagName && "html" === this.offsetParent[0].tagName.toLowerCase() && e.ui.ie) && (t = {
                top: 0,
                left: 0
            }), {
                top: t.top + (parseInt(this.offsetParent.css("borderTopWidth"), 10) || 0),
                left: t.left + (parseInt(this.offsetParent.css("borderLeftWidth"), 10) || 0)
            }
        },
        _getRelativeOffset: function () {
            if ("relative" === this.cssPosition) {
                var e = this.currentItem.position();
                return {
                    top: e.top - (parseInt(this.helper.css("top"), 10) || 0) + this.scrollParent.scrollTop(),
                    left: e.left - (parseInt(this.helper.css("left"), 10) || 0) + this.scrollParent.scrollLeft()
                }
            }
            return {
                top: 0,
                left: 0
            }
        },
        _cacheMargins: function () {
            this.margins = {
                left: parseInt(this.currentItem.css("marginLeft"), 10) || 0,
                top: parseInt(this.currentItem.css("marginTop"), 10) || 0
            }
        },
        _cacheHelperProportions: function () {
            this.helperProportions = {
                width: this.helper.outerWidth(),
                height: this.helper.outerHeight()
            }
        },
        _setContainment: function () {
            var t, i, n, s = this.options;
            "parent" === s.containment && (s.containment = this.helper[0].parentNode), ("document" === s.containment || "window" === s.containment) && (this.containment = [0 - this.offset.relative.left - this.offset.parent.left, 0 - this.offset.relative.top - this.offset.parent.top, e("document" === s.containment ? document : window).width() - this.helperProportions.width - this.margins.left, (e("document" === s.containment ? document : window).height() || document.body.parentNode.scrollHeight) - this.helperProportions.height - this.margins.top]), /^(document|window|parent)$/.test(s.containment) || (t = e(s.containment)[0], i = e(s.containment).offset(), n = "hidden" !== e(t).css("overflow"), this.containment = [i.left + (parseInt(e(t).css("borderLeftWidth"), 10) || 0) + (parseInt(e(t).css("paddingLeft"), 10) || 0) - this.margins.left, i.top + (parseInt(e(t).css("borderTopWidth"), 10) || 0) + (parseInt(e(t).css("paddingTop"), 10) || 0) - this.margins.top, i.left + (n ? Math.max(t.scrollWidth, t.offsetWidth) : t.offsetWidth) - (parseInt(e(t).css("borderLeftWidth"), 10) || 0) - (parseInt(e(t).css("paddingRight"), 10) || 0) - this.helperProportions.width - this.margins.left, i.top + (n ? Math.max(t.scrollHeight, t.offsetHeight) : t.offsetHeight) - (parseInt(e(t).css("borderTopWidth"), 10) || 0) - (parseInt(e(t).css("paddingBottom"), 10) || 0) - this.helperProportions.height - this.margins.top])
        },
        _convertPositionTo: function (t, i) {
            i || (i = this.position);
            var n = "absolute" === t ? 1 : -1,
                s = "absolute" !== this.cssPosition || this.scrollParent[0] !== document && e.contains(this.scrollParent[0], this.offsetParent[0]) ? this.scrollParent : this.offsetParent,
                r = /(html|body)/i.test(s[0].tagName);
            return {
                top: i.top + this.offset.relative.top * n + this.offset.parent.top * n - ("fixed" === this.cssPosition ? -this.scrollParent.scrollTop() : r ? 0 : s.scrollTop()) * n,
                left: i.left + this.offset.relative.left * n + this.offset.parent.left * n - ("fixed" === this.cssPosition ? -this.scrollParent.scrollLeft() : r ? 0 : s.scrollLeft()) * n
            }
        },
        _generatePosition: function (t) {
            var i, n, s = this.options,
                r = t.pageX,
                a = t.pageY,
                o = "absolute" !== this.cssPosition || this.scrollParent[0] !== document && e.contains(this.scrollParent[0], this.offsetParent[0]) ? this.scrollParent : this.offsetParent,
                l = /(html|body)/i.test(o[0].tagName);
            return "relative" !== this.cssPosition || this.scrollParent[0] !== document && this.scrollParent[0] !== this.offsetParent[0] || (this.offset.relative = this._getRelativeOffset()), this.originalPosition && (this.containment && (t.pageX - this.offset.click.left < this.containment[0] && (r = this.containment[0] + this.offset.click.left), t.pageY - this.offset.click.top < this.containment[1] && (a = this.containment[1] + this.offset.click.top), t.pageX - this.offset.click.left > this.containment[2] && (r = this.containment[2] + this.offset.click.left), t.pageY - this.offset.click.top > this.containment[3] && (a = this.containment[3] + this.offset.click.top)), s.grid && (i = this.originalPageY + Math.round((a - this.originalPageY) / s.grid[1]) * s.grid[1], a = this.containment ? i - this.offset.click.top >= this.containment[1] && i - this.offset.click.top <= this.containment[3] ? i : i - this.offset.click.top >= this.containment[1] ? i - s.grid[1] : i + s.grid[1] : i, n = this.originalPageX + Math.round((r - this.originalPageX) / s.grid[0]) * s.grid[0], r = this.containment ? n - this.offset.click.left >= this.containment[0] && n - this.offset.click.left <= this.containment[2] ? n : n - this.offset.click.left >= this.containment[0] ? n - s.grid[0] : n + s.grid[0] : n)), {
                top: a - this.offset.click.top - this.offset.relative.top - this.offset.parent.top + ("fixed" === this.cssPosition ? -this.scrollParent.scrollTop() : l ? 0 : o.scrollTop()),
                left: r - this.offset.click.left - this.offset.relative.left - this.offset.parent.left + ("fixed" === this.cssPosition ? -this.scrollParent.scrollLeft() : l ? 0 : o.scrollLeft())
            }
        },
        _rearrange: function (e, t, i, n) {
            i ? i[0].appendChild(this.placeholder[0]) : t.item[0].parentNode.insertBefore(this.placeholder[0], "down" === this.direction ? t.item[0] : t.item[0].nextSibling), this.counter = this.counter ? ++this.counter : 1;
            var s = this.counter;
            this._delay(function () {
                s === this.counter && this.refreshPositions(!n)
            })
        },
        _clear: function (e, t) {
            function s(e, t, i) {
                return function (n) {
                    i._trigger(e, n, t._uiHash(t))
                }
            }
            this.reverting = !1;
            var i, n = [];
            if (!this._noFinalSort && this.currentItem.parent().length && this.placeholder.before(this.currentItem), this._noFinalSort = null, this.helper[0] === this.currentItem[0]) {
                for (i in this._storedCSS)("auto" === this._storedCSS[i] || "static" === this._storedCSS[i]) && (this._storedCSS[i] = "");
                this.currentItem.css(this._storedCSS).removeClass("ui-sortable-helper")
            } else this.currentItem.show();
            for (this.fromOutside && !t && n.push(function (e) {
                    this._trigger("receive", e, this._uiHash(this.fromOutside))
                }), !this.fromOutside && this.domPosition.prev === this.currentItem.prev().not(".ui-sortable-helper")[0] && this.domPosition.parent === this.currentItem.parent()[0] || t || n.push(function (e) {
                    this._trigger("update", e, this._uiHash())
                }), this !== this.currentContainer && (t || (n.push(function (e) {
                    this._trigger("remove", e, this._uiHash())
                }), n.push(function (e) {
                    return function (t) {
                        e._trigger("receive", t, this._uiHash(this))
                    }
                }.call(this, this.currentContainer)), n.push(function (e) {
                    return function (t) {
                        e._trigger("update", t, this._uiHash(this))
                    }
                }.call(this, this.currentContainer)))), i = this.containers.length - 1; i >= 0; i--) t || n.push(s("deactivate", this, this.containers[i])), this.containers[i].containerCache.over && (n.push(s("out", this, this.containers[i])), this.containers[i].containerCache.over = 0);
            if (this.storedCursor && (this.document.find("body").css("cursor", this.storedCursor), this.storedStylesheet.remove()), this._storedOpacity && this.helper.css("opacity", this._storedOpacity), this._storedZIndex && this.helper.css("zIndex", "auto" === this._storedZIndex ? "" : this._storedZIndex), this.dragging = !1, this.cancelHelperRemoval) {
                if (!t) {
                    for (this._trigger("beforeStop", e, this._uiHash()), i = 0; i < n.length; i++) n[i].call(this, e);
                    this._trigger("stop", e, this._uiHash())
                }
                return this.fromOutside = !1, !1
            }
            if (t || this._trigger("beforeStop", e, this._uiHash()), this.placeholder[0].parentNode.removeChild(this.placeholder[0]), this.helper[0] !== this.currentItem[0] && this.helper.remove(), this.helper = null, !t) {
                for (i = 0; i < n.length; i++) n[i].call(this, e);
                this._trigger("stop", e, this._uiHash())
            }
            return this.fromOutside = !1, !0
        },
        _trigger: function () {
            e.Widget.prototype._trigger.apply(this, arguments) === !1 && this.cancel()
        },
        _uiHash: function (t) {
            var i = t || this;
            return {
                helper: i.helper,
                placeholder: i.placeholder || e([]),
                position: i.position,
                originalPosition: i.originalPosition,
                offset: i.positionAbs,
                item: i.currentItem,
                sender: t ? t.element : null
            }
        }
    })
}(jQuery),
function (e, t) {
    var i = "ui-effects-";
    e.effects = {
            effect: {}
        },
        function (e, t) {
            function c(e, t, i) {
                var n = o[t.type] || {};
                return null == e ? i || !t.def ? null : t.def : (e = n.floor ? ~~e : parseFloat(e), isNaN(e) ? t.def : n.mod ? (e + n.mod) % n.mod : 0 > e ? 0 : n.max < e ? n.max : e)
            }

            function d(t) {
                var i = r(),
                    n = i._rgba = [];
                return t = t.toLowerCase(), f(s, function (e, s) {
                    var r, o = s.re.exec(t),
                        l = o && s.parse(o),
                        u = s.space || "rgba";
                    return l ? (r = i[u](l), i[a[u].cache] = r[a[u].cache], n = i._rgba = r._rgba, !1) : void 0
                }), n.length ? ("0,0,0,0" === n.join() && e.extend(n, h.transparent), i) : h[t]
            }

            function p(e, t, i) {
                return i = (i + 1) % 1, 1 > 6 * i ? e + (t - e) * i * 6 : 1 > 2 * i ? t : 2 > 3 * i ? e + (t - e) * (2 / 3 - i) * 6 : e
            }
            var h, i = "backgroundColor borderBottomColor borderLeftColor borderRightColor borderTopColor color columnRuleColor outlineColor textDecorationColor textEmphasisColor",
                n = /^([\-+])=\s*(\d+\.?\d*)/,
                s = [{
                    re: /rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
                    parse: function (e) {
                        return [e[1], e[2], e[3], e[4]]
                    }
                }, {
                    re: /rgba?\(\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
                    parse: function (e) {
                        return [2.55 * e[1], 2.55 * e[2], 2.55 * e[3], e[4]]
                    }
                }, {
                    re: /#([a-f0-9]{2})([a-f0-9]{2})([a-f0-9]{2})/,
                    parse: function (e) {
                        return [parseInt(e[1], 16), parseInt(e[2], 16), parseInt(e[3], 16)]
                    }
                }, {
                    re: /#([a-f0-9])([a-f0-9])([a-f0-9])/,
                    parse: function (e) {
                        return [parseInt(e[1] + e[1], 16), parseInt(e[2] + e[2], 16), parseInt(e[3] + e[3], 16)]
                    }
                }, {
                    re: /hsla?\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
                    space: "hsla",
                    parse: function (e) {
                        return [e[1], e[2] / 100, e[3] / 100, e[4]]
                    }
                }],
                r = e.Color = function (t, i, n, s) {
                    return new e.Color.fn.parse(t, i, n, s)
                },
                a = {
                    rgba: {
                        props: {
                            red: {
                                idx: 0,
                                type: "byte"
                            },
                            green: {
                                idx: 1,
                                type: "byte"
                            },
                            blue: {
                                idx: 2,
                                type: "byte"
                            }
                        }
                    },
                    hsla: {
                        props: {
                            hue: {
                                idx: 0,
                                type: "degrees"
                            },
                            saturation: {
                                idx: 1,
                                type: "percent"
                            },
                            lightness: {
                                idx: 2,
                                type: "percent"
                            }
                        }
                    }
                },
                o = {
                    "byte": {
                        floor: !0,
                        max: 255
                    },
                    percent: {
                        max: 1
                    },
                    degrees: {
                        mod: 360,
                        floor: !0
                    }
                },
                l = r.support = {},
                u = e("<p>")[0],
                f = e.each;
            u.style.cssText = "background-color:rgba(1,1,1,.5)", l.rgba = u.style.backgroundColor.indexOf("rgba") > -1, f(a, function (e, t) {
                t.cache = "_" + e, t.props.alpha = {
                    idx: 3,
                    type: "percent",
                    def: 1
                }
            }), r.fn = e.extend(r.prototype, {
                parse: function (i, n, s, o) {
                    if (i === t) return this._rgba = [null, null, null, null], this;
                    (i.jquery || i.nodeType) && (i = e(i).css(n), n = t);
                    var l = this,
                        u = e.type(i),
                        p = this._rgba = [];
                    return n !== t && (i = [i, n, s, o], u = "array"), "string" === u ? this.parse(d(i) || h._default) : "array" === u ? (f(a.rgba.props, function (e, t) {
                        p[t.idx] = c(i[t.idx], t)
                    }), this) : "object" === u ? (i instanceof r ? f(a, function (e, t) {
                        i[t.cache] && (l[t.cache] = i[t.cache].slice())
                    }) : f(a, function (t, n) {
                        var s = n.cache;
                        f(n.props, function (e, t) {
                            if (!l[s] && n.to) {
                                if ("alpha" === e || null == i[e]) return;
                                l[s] = n.to(l._rgba)
                            }
                            l[s][t.idx] = c(i[e], t, !0)
                        }), l[s] && e.inArray(null, l[s].slice(0, 3)) < 0 && (l[s][3] = 1, n.from && (l._rgba = n.from(l[s])))
                    }), this) : void 0
                },
                is: function (e) {
                    var t = r(e),
                        i = !0,
                        n = this;
                    return f(a, function (e, s) {
                        var r, a = t[s.cache];
                        return a && (r = n[s.cache] || s.to && s.to(n._rgba) || [], f(s.props, function (e, t) {
                            return null != a[t.idx] ? i = a[t.idx] === r[t.idx] : void 0
                        })), i
                    }), i
                },
                _space: function () {
                    var e = [],
                        t = this;
                    return f(a, function (i, n) {
                        t[n.cache] && e.push(i)
                    }), e.pop()
                },
                transition: function (e, t) {
                    var i = r(e),
                        n = i._space(),
                        s = a[n],
                        l = 0 === this.alpha() ? r("transparent") : this,
                        u = l[s.cache] || s.to(l._rgba),
                        h = u.slice();
                    return i = i[s.cache], f(s.props, function (e, n) {
                        var s = n.idx,
                            r = u[s],
                            a = i[s],
                            l = o[n.type] || {};
                        null !== a && (null === r ? h[s] = a : (l.mod && (a - r > l.mod / 2 ? r += l.mod : r - a > l.mod / 2 && (r -= l.mod)), h[s] = c((a - r) * t + r, n)))
                    }), this[n](h)
                },
                blend: function (t) {
                    if (1 === this._rgba[3]) return this;
                    var i = this._rgba.slice(),
                        n = i.pop(),
                        s = r(t)._rgba;
                    return r(e.map(i, function (e, t) {
                        return (1 - n) * s[t] + n * e
                    }))
                },
                toRgbaString: function () {
                    var t = "rgba(",
                        i = e.map(this._rgba, function (e, t) {
                            return null == e ? t > 2 ? 1 : 0 : e
                        });
                    return 1 === i[3] && (i.pop(), t = "rgb("), t + i.join() + ")"
                },
                toHslaString: function () {
                    var t = "hsla(",
                        i = e.map(this.hsla(), function (e, t) {
                            return null == e && (e = t > 2 ? 1 : 0), t && 3 > t && (e = Math.round(100 * e) + "%"), e
                        });
                    return 1 === i[3] && (i.pop(), t = "hsl("), t + i.join() + ")"
                },
                toHexString: function (t) {
                    var i = this._rgba.slice(),
                        n = i.pop();
                    return t && i.push(~~(255 * n)), "#" + e.map(i, function (e) {
                        return e = (e || 0).toString(16), 1 === e.length ? "0" + e : e
                    }).join("")
                },
                toString: function () {
                    return 0 === this._rgba[3] ? "transparent" : this.toRgbaString()
                }
            }), r.fn.parse.prototype = r.fn, a.hsla.to = function (e) {
                if (null == e[0] || null == e[1] || null == e[2]) return [null, null, null, e[3]];
                var h, f, t = e[0] / 255,
                    i = e[1] / 255,
                    n = e[2] / 255,
                    s = e[3],
                    r = Math.max(t, i, n),
                    a = Math.min(t, i, n),
                    o = r - a,
                    l = r + a,
                    u = .5 * l;
                return h = a === r ? 0 : t === r ? 60 * (i - n) / o + 360 : i === r ? 60 * (n - t) / o + 120 : 60 * (t - i) / o + 240, f = 0 === o ? 0 : .5 >= u ? o / l : o / (2 - l), [Math.round(h) % 360, f, u, null == s ? 1 : s]
            }, a.hsla.from = function (e) {
                if (null == e[0] || null == e[1] || null == e[2]) return [null, null, null, e[3]];
                var t = e[0] / 360,
                    i = e[1],
                    n = e[2],
                    s = e[3],
                    r = .5 >= n ? n * (1 + i) : n + i - n * i,
                    a = 2 * n - r;
                return [Math.round(255 * p(a, r, t + 1 / 3)), Math.round(255 * p(a, r, t)), Math.round(255 * p(a, r, t - 1 / 3)), s]
            }, f(a, function (i, s) {
                var a = s.props,
                    o = s.cache,
                    l = s.to,
                    u = s.from;
                r.fn[i] = function (i) {
                    if (l && !this[o] && (this[o] = l(this._rgba)), i === t) return this[o].slice();
                    var n, s = e.type(i),
                        h = "array" === s || "object" === s ? i : arguments,
                        d = this[o].slice();
                    return f(a, function (e, t) {
                        var i = h["object" === s ? e : t.idx];
                        null == i && (i = d[t.idx]), d[t.idx] = c(i, t)
                    }), u ? (n = r(u(d)), n[o] = d, n) : r(d)
                }, f(a, function (t, s) {
                    r.fn[t] || (r.fn[t] = function (r) {
                        var h, a = e.type(r),
                            o = "alpha" === t ? this._hsla ? "hsla" : "rgba" : i,
                            l = this[o](),
                            u = l[s.idx];
                        return "undefined" === a ? u : ("function" === a && (r = r.call(this, u), a = e.type(r)), null == r && s.empty ? this : ("string" === a && (h = n.exec(r), h && (r = u + parseFloat(h[2]) * ("+" === h[1] ? 1 : -1))), l[s.idx] = r, this[o](l)))
                    })
                })
            }), r.hook = function (t) {
                var i = t.split(" ");
                f(i, function (t, i) {
                    e.cssHooks[i] = {
                        set: function (t, n) {
                            var s, a, o = "";
                            if ("transparent" !== n && ("string" !== e.type(n) || (s = d(n)))) {
                                if (n = r(s || n), !l.rgba && 1 !== n._rgba[3]) {
                                    for (a = "backgroundColor" === i ? t.parentNode : t;
                                        ("" === o || "transparent" === o) && a && a.style;) try {
                                        o = e.css(a, "backgroundColor"), a = a.parentNode
                                    } catch (u) {}
                                    n = n.blend(o && "transparent" !== o ? o : "_default")
                                }
                                n = n.toRgbaString()
                            }
                            try {
                                t.style[i] = n
                            } catch (u) {}
                        }
                    }, e.fx.step[i] = function (t) {
                        t.colorInit || (t.start = r(t.elem, i), t.end = r(t.end), t.colorInit = !0), e.cssHooks[i].set(t.elem, t.start.transition(t.end, t.pos))
                    }
                })
            }, r.hook(i), e.cssHooks.borderColor = {
                expand: function (e) {
                    var t = {};
                    return f(["Top", "Right", "Bottom", "Left"], function (i, n) {
                        t["border" + n + "Color"] = e
                    }), t
                }
            }, h = e.Color.names = {
                aqua: "#00ffff",
                black: "#000000",
                blue: "#0000ff",
                fuchsia: "#ff00ff",
                gray: "#808080",
                green: "#008000",
                lime: "#00ff00",
                maroon: "#800000",
                navy: "#000080",
                olive: "#808000",
                purple: "#800080",
                red: "#ff0000",
                silver: "#c0c0c0",
                teal: "#008080",
                white: "#ffffff",
                yellow: "#ffff00",
                transparent: [null, null, null, 0],
                _default: "#ffffff"
            }
        }(jQuery),
        function () {
            function s(t) {
                var i, n, s = t.ownerDocument.defaultView ? t.ownerDocument.defaultView.getComputedStyle(t, null) : t.currentStyle,
                    r = {};
                if (s && s.length && s[0] && s[s[0]])
                    for (n = s.length; n--;) i = s[n], "string" == typeof s[i] && (r[e.camelCase(i)] = s[i]);
                else
                    for (i in s) "string" == typeof s[i] && (r[i] = s[i]);
                return r
            }

            function r(t, i) {
                var r, a, s = {};
                for (r in i) a = i[r], t[r] !== a && (n[r] || (e.fx.step[r] || !isNaN(parseFloat(a))) && (s[r] = a));
                return s
            }
            var i = ["add", "remove", "toggle"],
                n = {
                    border: 1,
                    borderBottom: 1,
                    borderColor: 1,
                    borderLeft: 1,
                    borderRight: 1,
                    borderTop: 1,
                    borderWidth: 1,
                    margin: 1,
                    padding: 1
                };
            e.each(["borderLeftStyle", "borderRightStyle", "borderBottomStyle", "borderTopStyle"], function (t, i) {
                e.fx.step[i] = function (e) {
                    ("none" !== e.end && !e.setAttr || 1 === e.pos && !e.setAttr) && (jQuery.style(e.elem, i, e.end), e.setAttr = !0)
                }
            }), e.fn.addBack || (e.fn.addBack = function (e) {
                return this.add(null == e ? this.prevObject : this.prevObject.filter(e))
            }), e.effects.animateClass = function (t, n, a, o) {
                var l = e.speed(n, a, o);
                return this.queue(function () {
                    var o, n = e(this),
                        a = n.attr("class") || "",
                        u = l.children ? n.find("*").addBack() : n;
                    u = u.map(function () {
                        var t = e(this);
                        return {
                            el: t,
                            start: s(this)
                        }
                    }), o = function () {
                        e.each(i, function (e, i) {
                            t[i] && n[i + "Class"](t[i])
                        })
                    }, o(), u = u.map(function () {
                        return this.end = s(this.el[0]), this.diff = r(this.start, this.end), this
                    }), n.attr("class", a), u = u.map(function () {
                        var t = this,
                            i = e.Deferred(),
                            n = e.extend({}, l, {
                                queue: !1,
                                complete: function () {
                                    i.resolve(t)
                                }
                            });
                        return this.el.animate(this.diff, n), i.promise()
                    }), e.when.apply(e, u.get()).done(function () {
                        o(), e.each(arguments, function () {
                            var t = this.el;
                            e.each(this.diff, function (e) {
                                t.css(e, "")
                            })
                        }), l.complete.call(n[0])
                    })
                })
            }, e.fn.extend({
                addClass: function (t) {
                    return function (i, n, s, r) {
                        return n ? e.effects.animateClass.call(this, {
                            add: i
                        }, n, s, r) : t.apply(this, arguments)
                    }
                }(e.fn.addClass),
                removeClass: function (t) {
                    return function (i, n, s, r) {
                        return arguments.length > 1 ? e.effects.animateClass.call(this, {
                            remove: i
                        }, n, s, r) : t.apply(this, arguments)
                    }
                }(e.fn.removeClass),
                toggleClass: function (i) {
                    return function (n, s, r, a, o) {
                        return "boolean" == typeof s || s === t ? r ? e.effects.animateClass.call(this, s ? {
                            add: n
                        } : {
                            remove: n
                        }, r, a, o) : i.apply(this, arguments) : e.effects.animateClass.call(this, {
                            toggle: n
                        }, s, r, a)
                    }
                }(e.fn.toggleClass),
                switchClass: function (t, i, n, s, r) {
                    return e.effects.animateClass.call(this, {
                        add: i,
                        remove: t
                    }, n, s, r)
                }
            })
        }(),
        function () {
            function n(t, i, n, s) {
                return e.isPlainObject(t) && (i = t, t = t.effect), t = {
                    effect: t
                }, null == i && (i = {}), e.isFunction(i) && (s = i, n = null, i = {}), ("number" == typeof i || e.fx.speeds[i]) && (s = n, n = i, i = {}), e.isFunction(n) && (s = n, n = null), i && e.extend(t, i), n = n || i.duration, t.duration = e.fx.off ? 0 : "number" == typeof n ? n : n in e.fx.speeds ? e.fx.speeds[n] : e.fx.speeds._default, t.complete = s || i.complete, t
            }

            function s(t) {
                return !t || "number" == typeof t || e.fx.speeds[t] ? !0 : "string" != typeof t || e.effects.effect[t] ? e.isFunction(t) ? !0 : "object" != typeof t || t.effect ? !1 : !0 : !0
            }
            e.extend(e.effects, {
                version: "1.10.4",
                save: function (e, t) {
                    for (var n = 0; n < t.length; n++) null !== t[n] && e.data(i + t[n], e[0].style[t[n]])
                },
                restore: function (e, n) {
                    var s, r;
                    for (r = 0; r < n.length; r++) null !== n[r] && (s = e.data(i + n[r]), s === t && (s = ""), e.css(n[r], s))
                },
                setMode: function (e, t) {
                    return "toggle" === t && (t = e.is(":hidden") ? "show" : "hide"), t
                },
                getBaseline: function (e, t) {
                    var i, n;
                    switch (e[0]) {
                        case "top":
                            i = 0;
                            break;
                        case "middle":
                            i = .5;
                            break;
                        case "bottom":
                            i = 1;
                            break;
                        default:
                            i = e[0] / t.height
                    }
                    switch (e[1]) {
                        case "left":
                            n = 0;
                            break;
                        case "center":
                            n = .5;
                            break;
                        case "right":
                            n = 1;
                            break;
                        default:
                            n = e[1] / t.width
                    }
                    return {
                        x: n,
                        y: i
                    }
                },
                createWrapper: function (t) {
                    if (t.parent().is(".ui-effects-wrapper")) return t.parent();
                    var i = {
                            width: t.outerWidth(!0),
                            height: t.outerHeight(!0),
                            "float": t.css("float")
                        },
                        n = e("<div></div>").addClass("ui-effects-wrapper").css({
                            fontSize: "100%",
                            background: "transparent",
                            border: "none",
                            margin: 0,
                            padding: 0
                        }),
                        s = {
                            width: t.width(),
                            height: t.height()
                        },
                        r = document.activeElement;
                    try {
                        r.id
                    } catch (a) {
                        r = document.body
                    }
                    return t.wrap(n), (t[0] === r || e.contains(t[0], r)) && e(r).focus(), n = t.parent(), "static" === t.css("position") ? (n.css({
                        position: "relative"
                    }), t.css({
                        position: "relative"
                    })) : (e.extend(i, {
                        position: t.css("position"),
                        zIndex: t.css("z-index")
                    }), e.each(["top", "left", "bottom", "right"], function (e, n) {
                        i[n] = t.css(n), isNaN(parseInt(i[n], 10)) && (i[n] = "auto")
                    }), t.css({
                        position: "relative",
                        top: 0,
                        left: 0,
                        right: "auto",
                        bottom: "auto"
                    })), t.css(s), n.css(i).show()
                },
                removeWrapper: function (t) {
                    var i = document.activeElement;
                    return t.parent().is(".ui-effects-wrapper") && (t.parent().replaceWith(t), (t[0] === i || e.contains(t[0], i)) && e(i).focus()), t
                },
                setTransition: function (t, i, n, s) {
                    return s = s || {}, e.each(i, function (e, i) {
                        var r = t.cssUnit(i);
                        r[0] > 0 && (s[i] = r[0] * n + r[1])
                    }), s
                }
            }), e.fn.extend({
                effect: function () {
                    function a(i) {
                        function o() {
                            e.isFunction(s) && s.call(n[0]), e.isFunction(i) && i()
                        }
                        var n = e(this),
                            s = t.complete,
                            a = t.mode;
                        (n.is(":hidden") ? "hide" === a : "show" === a) ? (n[a](), o()) : r.call(n[0], t, o)
                    }
                    var t = n.apply(this, arguments),
                        i = t.mode,
                        s = t.queue,
                        r = e.effects.effect[t.effect];
                    return e.fx.off || !r ? i ? this[i](t.duration, t.complete) : this.each(function () {
                        t.complete && t.complete.call(this)
                    }) : s === !1 ? this.each(a) : this.queue(s || "fx", a)
                },
                show: function (e) {
                    return function (t) {
                        if (s(t)) return e.apply(this, arguments);
                        var i = n.apply(this, arguments);
                        return i.mode = "show", this.effect.call(this, i)
                    }
                }(e.fn.show),
                hide: function (e) {
                    return function (t) {
                        if (s(t)) return e.apply(this, arguments);
                        var i = n.apply(this, arguments);
                        return i.mode = "hide", this.effect.call(this, i)
                    }
                }(e.fn.hide),
                toggle: function (e) {
                    return function (t) {
                        if (s(t) || "boolean" == typeof t) return e.apply(this, arguments);
                        var i = n.apply(this, arguments);
                        return i.mode = "toggle", this.effect.call(this, i)
                    }
                }(e.fn.toggle),
                cssUnit: function (t) {
                    var i = this.css(t),
                        n = [];
                    return e.each(["em", "px", "%", "pt"], function (e, t) {
                        i.indexOf(t) > 0 && (n = [parseFloat(i), t])
                    }), n
                }
            })
        }(),
        function () {
            var t = {};
            e.each(["Quad", "Cubic", "Quart", "Quint", "Expo"], function (e, i) {
                t[i] = function (t) {
                    return Math.pow(t, e + 2)
                }
            }), e.extend(t, {
                Sine: function (e) {
                    return 1 - Math.cos(e * Math.PI / 2)
                },
                Circ: function (e) {
                    return 1 - Math.sqrt(1 - e * e)
                },
                Elastic: function (e) {
                    return 0 === e || 1 === e ? e : -Math.pow(2, 8 * (e - 1)) * Math.sin((80 * (e - 1) - 7.5) * Math.PI / 15)
                },
                Back: function (e) {
                    return e * e * (3 * e - 2)
                },
                Bounce: function (e) {
                    for (var t, i = 4; e < ((t = Math.pow(2, --i)) - 1) / 11;);
                    return 1 / Math.pow(4, 3 - i) - 7.5625 * Math.pow((3 * t - 2) / 22 - e, 2)
                }
            }), e.each(t, function (t, i) {
                e.easing["easeIn" + t] = i, e.easing["easeOut" + t] = function (e) {
                    return 1 - i(1 - e)
                }, e.easing["easeInOut" + t] = function (e) {
                    return .5 > e ? i(2 * e) / 2 : 1 - i(-2 * e + 2) / 2
                }
            })
        }()
}(jQuery),
function (e) {
    var i = 0,
        n = {},
        s = {};
    n.height = n.paddingTop = n.paddingBottom = n.borderTopWidth = n.borderBottomWidth = "hide", s.height = s.paddingTop = s.paddingBottom = s.borderTopWidth = s.borderBottomWidth = "show", e.widget("ui.accordion", {
        version: "1.10.4",
        options: {
            active: 0,
            animate: {},
            collapsible: !1,
            event: "click",
            header: "> li > :first-child,> :not(li):even",
            heightStyle: "auto",
            icons: {
                activeHeader: "ui-icon-triangle-1-s",
                header: "ui-icon-triangle-1-e"
            },
            activate: null,
            beforeActivate: null
        },
        _create: function () {
            var t = this.options;
            this.prevShow = this.prevHide = e(), this.element.addClass("ui-accordion ui-widget ui-helper-reset").attr("role", "tablist"), t.collapsible || t.active !== !1 && null != t.active || (t.active = 0), this._processPanels(), t.active < 0 && (t.active += this.headers.length), this._refresh()
        },
        _getCreateEventData: function () {
            return {
                header: this.active,
                panel: this.active.length ? this.active.next() : e(),
                content: this.active.length ? this.active.next() : e()
            }
        },
        _createIcons: function () {
            var t = this.options.icons;
            t && (e("<span>").addClass("ui-accordion-header-icon ui-icon " + t.header).prependTo(this.headers), this.active.children(".ui-accordion-header-icon").removeClass(t.header).addClass(t.activeHeader), this.headers.addClass("ui-accordion-icons"))
        },
        _destroyIcons: function () {
            this.headers.removeClass("ui-accordion-icons").children(".ui-accordion-header-icon").remove()
        },
        _destroy: function () {
            var e;
            this.element.removeClass("ui-accordion ui-widget ui-helper-reset").removeAttr("role"), this.headers.removeClass("ui-accordion-header ui-accordion-header-active ui-helper-reset ui-state-default ui-corner-all ui-state-active ui-state-disabled ui-corner-top").removeAttr("role").removeAttr("aria-expanded").removeAttr("aria-selected").removeAttr("aria-controls").removeAttr("tabIndex").each(function () {
                /^ui-accordion/.test(this.id) && this.removeAttribute("id")
            }), this._destroyIcons(), e = this.headers.next().css("display", "").removeAttr("role").removeAttr("aria-hidden").removeAttr("aria-labelledby").removeClass("ui-helper-reset ui-widget-content ui-corner-bottom ui-accordion-content ui-accordion-content-active ui-state-disabled").each(function () {
                /^ui-accordion/.test(this.id) && this.removeAttribute("id")
            }), "content" !== this.options.heightStyle && e.css("height", "")
        },
        _setOption: function (e, t) {
            return "active" === e ? void this._activate(t) : ("event" === e && (this.options.event && this._off(this.headers, this.options.event), this._setupEvents(t)), this._super(e, t), "collapsible" !== e || t || this.options.active !== !1 || this._activate(0), "icons" === e && (this._destroyIcons(), t && this._createIcons()), void("disabled" === e && this.headers.add(this.headers.next()).toggleClass("ui-state-disabled", !!t)))
        },
        _keydown: function (t) {
            if (!t.altKey && !t.ctrlKey) {
                var i = e.ui.keyCode,
                    n = this.headers.length,
                    s = this.headers.index(t.target),
                    r = !1;
                switch (t.keyCode) {
                    case i.RIGHT:
                    case i.DOWN:
                        r = this.headers[(s + 1) % n];
                        break;
                    case i.LEFT:
                    case i.UP:
                        r = this.headers[(s - 1 + n) % n];
                        break;
                    case i.SPACE:
                    case i.ENTER:
                        this._eventHandler(t);
                        break;
                    case i.HOME:
                        r = this.headers[0];
                        break;
                    case i.END:
                        r = this.headers[n - 1]
                }
                r && (e(t.target).attr("tabIndex", -1), e(r).attr("tabIndex", 0), r.focus(), t.preventDefault())
            }
        },
        _panelKeyDown: function (t) {
            t.keyCode === e.ui.keyCode.UP && t.ctrlKey && e(t.currentTarget).prev().focus()
        },
        refresh: function () {
            var t = this.options;
            this._processPanels(), t.active === !1 && t.collapsible === !0 || !this.headers.length ? (t.active = !1, this.active = e()) : t.active === !1 ? this._activate(0) : this.active.length && !e.contains(this.element[0], this.active[0]) ? this.headers.length === this.headers.find(".ui-state-disabled").length ? (t.active = !1, this.active = e()) : this._activate(Math.max(0, t.active - 1)) : t.active = this.headers.index(this.active), this._destroyIcons(), this._refresh()
        },
        _processPanels: function () {
            this.headers = this.element.find(this.options.header).addClass("ui-accordion-header ui-helper-reset ui-state-default ui-corner-all"), this.headers.next().addClass("ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom").filter(":not(.ui-accordion-content-active)").hide()
        },
        _refresh: function () {
            var t, n = this.options,
                s = n.heightStyle,
                r = this.element.parent(),
                a = this.accordionId = "ui-accordion-" + (this.element.attr("id") || ++i);
            this.active = this._findActive(n.active).addClass("ui-accordion-header-active ui-state-active ui-corner-top").removeClass("ui-corner-all"), this.active.next().addClass("ui-accordion-content-active").show(), this.headers.attr("role", "tab").each(function (t) {
                var i = e(this),
                    n = i.attr("id"),
                    s = i.next(),
                    r = s.attr("id");
                n || (n = a + "-header-" + t, i.attr("id", n)), r || (r = a + "-panel-" + t, s.attr("id", r)), i.attr("aria-controls", r), s.attr("aria-labelledby", n)
            }).next().attr("role", "tabpanel"), this.headers.not(this.active).attr({
                "aria-selected": "false",
                "aria-expanded": "false",
                tabIndex: -1
            }).next().attr({
                "aria-hidden": "true"
            }).hide(), this.active.length ? this.active.attr({
                "aria-selected": "true",
                "aria-expanded": "true",
                tabIndex: 0
            }).next().attr({
                "aria-hidden": "false"
            }) : this.headers.eq(0).attr("tabIndex", 0), this._createIcons(), this._setupEvents(n.event), "fill" === s ? (t = r.height(), this.element.siblings(":visible").each(function () {
                var i = e(this),
                    n = i.css("position");
                "absolute" !== n && "fixed" !== n && (t -= i.outerHeight(!0))
            }), this.headers.each(function () {
                t -= e(this).outerHeight(!0)
            }), this.headers.next().each(function () {
                e(this).height(Math.max(0, t - e(this).innerHeight() + e(this).height()))
            }).css("overflow", "auto")) : "auto" === s && (t = 0, this.headers.next().each(function () {
                t = Math.max(t, e(this).css("height", "").height())
            }).height(t))
        },
        _activate: function (t) {
            var i = this._findActive(t)[0];
            i !== this.active[0] && (i = i || this.active[0], this._eventHandler({
                target: i,
                currentTarget: i,
                preventDefault: e.noop
            }))
        },
        _findActive: function (t) {
            return "number" == typeof t ? this.headers.eq(t) : e()
        },
        _setupEvents: function (t) {
            var i = {
                keydown: "_keydown"
            };
            t && e.each(t.split(" "), function (e, t) {
                i[t] = "_eventHandler"
            }), this._off(this.headers.add(this.headers.next())), this._on(this.headers, i), this._on(this.headers.next(), {
                keydown: "_panelKeyDown"
            }), this._hoverable(this.headers), this._focusable(this.headers)
        },
        _eventHandler: function (t) {
            var i = this.options,
                n = this.active,
                s = e(t.currentTarget),
                r = s[0] === n[0],
                a = r && i.collapsible,
                o = a ? e() : s.next(),
                l = n.next(),
                u = {
                    oldHeader: n,
                    oldPanel: l,
                    newHeader: a ? e() : s,
                    newPanel: o
                };
            t.preventDefault(), r && !i.collapsible || this._trigger("beforeActivate", t, u) === !1 || (i.active = a ? !1 : this.headers.index(s), this.active = r ? e() : s, this._toggle(u), n.removeClass("ui-accordion-header-active ui-state-active"), i.icons && n.children(".ui-accordion-header-icon").removeClass(i.icons.activeHeader).addClass(i.icons.header), r || (s.removeClass("ui-corner-all").addClass("ui-accordion-header-active ui-state-active ui-corner-top"), i.icons && s.children(".ui-accordion-header-icon").removeClass(i.icons.header).addClass(i.icons.activeHeader), s.next().addClass("ui-accordion-content-active")))
        },
        _toggle: function (t) {
            var i = t.newPanel,
                n = this.prevShow.length ? this.prevShow : t.oldPanel;
            this.prevShow.add(this.prevHide).stop(!0, !0), this.prevShow = i, this.prevHide = n, this.options.animate ? this._animate(i, n, t) : (n.hide(), i.show(), this._toggleComplete(t)), n.attr({
                "aria-hidden": "true"
            }), n.prev().attr("aria-selected", "false"), i.length && n.length ? n.prev().attr({
                tabIndex: -1,
                "aria-expanded": "false"
            }) : i.length && this.headers.filter(function () {
                return 0 === e(this).attr("tabIndex")
            }).attr("tabIndex", -1), i.attr("aria-hidden", "false").prev().attr({
                "aria-selected": "true",
                tabIndex: 0,
                "aria-expanded": "true"
            })
        },
        _animate: function (e, t, i) {
            var r, a, o, l = this,
                u = 0,
                h = e.length && (!t.length || e.index() < t.index()),
                f = this.options.animate || {},
                c = h && f.down || f,
                d = function () {
                    l._toggleComplete(i)
                };
            return "number" == typeof c && (o = c), "string" == typeof c && (a = c), a = a || c.easing || f.easing, o = o || c.duration || f.duration, t.length ? e.length ? (r = e.show().outerHeight(), t.animate(n, {
                duration: o,
                easing: a,
                step: function (e, t) {
                    t.now = Math.round(e)
                }
            }), void e.hide().animate(s, {
                duration: o,
                easing: a,
                complete: d,
                step: function (e, i) {
                    i.now = Math.round(e), "height" !== i.prop ? u += i.now : "content" !== l.options.heightStyle && (i.now = Math.round(r - t.outerHeight() - u), u = 0)
                }
            })) : t.animate(n, o, a, d) : e.animate(s, o, a, d)
        },
        _toggleComplete: function (e) {
            var t = e.oldPanel;
            t.removeClass("ui-accordion-content-active").prev().removeClass("ui-corner-top").addClass("ui-corner-all"), t.length && (t.parent()[0].className = t.parent()[0].className), this._trigger("activate", null, e)
        }
    })
}(jQuery),
function (e) {
    e.widget("ui.autocomplete", {
        version: "1.10.4",
        defaultElement: "<input>",
        options: {
            appendTo: null,
            autoFocus: !1,
            delay: 300,
            minLength: 1,
            position: {
                my: "left top",
                at: "left bottom",
                collision: "none"
            },
            source: null,
            change: null,
            close: null,
            focus: null,
            open: null,
            response: null,
            search: null,
            select: null
        },
        requestIndex: 0,
        pending: 0,
        _create: function () {
            var t, i, n, s = this.element[0].nodeName.toLowerCase(),
                r = "textarea" === s,
                a = "input" === s;
            this.isMultiLine = r ? !0 : a ? !1 : this.element.prop("isContentEditable"), this.valueMethod = this.element[r || a ? "val" : "text"], this.isNewMenu = !0, this.element.addClass("ui-autocomplete-input").attr("autocomplete", "off"), this._on(this.element, {
                keydown: function (s) {
                    if (this.element.prop("readOnly")) return t = !0, n = !0, void(i = !0);
                    t = !1, n = !1, i = !1;
                    var r = e.ui.keyCode;
                    switch (s.keyCode) {
                        case r.PAGE_UP:
                            t = !0, this._move("previousPage", s);
                            break;
                        case r.PAGE_DOWN:
                            t = !0, this._move("nextPage", s);
                            break;
                        case r.UP:
                            t = !0, this._keyEvent("previous", s);
                            break;
                        case r.DOWN:
                            t = !0, this._keyEvent("next", s);
                            break;
                        case r.ENTER:
                        case r.NUMPAD_ENTER:
                            this.menu.active && (t = !0, s.preventDefault(), this.menu.select(s));
                            break;
                        case r.TAB:
                            this.menu.active && this.menu.select(s);
                            break;
                        case r.ESCAPE:
                            this.menu.element.is(":visible") && (this._value(this.term), this.close(s), s.preventDefault());
                            break;
                        default:
                            i = !0, this._searchTimeout(s)
                    }
                },
                keypress: function (n) {
                    if (t) return t = !1, void((!this.isMultiLine || this.menu.element.is(":visible")) && n.preventDefault());
                    if (!i) {
                        var s = e.ui.keyCode;
                        switch (n.keyCode) {
                            case s.PAGE_UP:
                                this._move("previousPage", n);
                                break;
                            case s.PAGE_DOWN:
                                this._move("nextPage", n);
                                break;
                            case s.UP:
                                this._keyEvent("previous", n);
                                break;
                            case s.DOWN:
                                this._keyEvent("next", n)
                        }
                    }
                },
                input: function (e) {
                    return n ? (n = !1, void e.preventDefault()) : void this._searchTimeout(e)
                },
                focus: function () {
                    this.selectedItem = null, this.previous = this._value()
                },
                blur: function (e) {
                    return this.cancelBlur ? void delete this.cancelBlur : (clearTimeout(this.searching), this.close(e), void this._change(e))
                }
            }), this._initSource(), this.menu = e("<ul>").addClass("ui-autocomplete ui-front").appendTo(this._appendTo()).menu({
                role: null
            }).hide().data("ui-menu"), this._on(this.menu.element, {
                mousedown: function (t) {
                    t.preventDefault(), this.cancelBlur = !0, this._delay(function () {
                        delete this.cancelBlur
                    });
                    var i = this.menu.element[0];
                    e(t.target).closest(".ui-menu-item").length || this._delay(function () {
                        var t = this;
                        this.document.one("mousedown", function (n) {
                            n.target === t.element[0] || n.target === i || e.contains(i, n.target) || t.close()
                        })
                    })
                },
                menufocus: function (t, i) {
                    if (this.isNewMenu && (this.isNewMenu = !1, t.originalEvent && /^mouse/.test(t.originalEvent.type))) return this.menu.blur(), void this.document.one("mousemove", function () {
                        e(t.target).trigger(t.originalEvent)
                    });
                    var n = i.item.data("ui-autocomplete-item");
                    !1 !== this._trigger("focus", t, {
                        item: n
                    }) ? t.originalEvent && /^key/.test(t.originalEvent.type) && this._value(n.value) : this.liveRegion.text(n.value)
                },
                menuselect: function (e, t) {
                    var i = t.item.data("ui-autocomplete-item"),
                        n = this.previous;
                    this.element[0] !== this.document[0].activeElement && (this.element.focus(), this.previous = n, this._delay(function () {
                        this.previous = n, this.selectedItem = i
                    })), !1 !== this._trigger("select", e, {
                        item: i
                    }) && this._value(i.value), this.term = this._value(), this.close(e), this.selectedItem = i
                }
            }), this.liveRegion = e("<span>", {
                role: "status",
                "aria-live": "polite"
            }).addClass("ui-helper-hidden-accessible").insertBefore(this.element), this._on(this.window, {
                beforeunload: function () {
                    this.element.removeAttr("autocomplete")
                }
            })
        },
        _destroy: function () {
            clearTimeout(this.searching), this.element.removeClass("ui-autocomplete-input").removeAttr("autocomplete"), this.menu.element.remove(), this.liveRegion.remove()
        },
        _setOption: function (e, t) {
            this._super(e, t), "source" === e && this._initSource(), "appendTo" === e && this.menu.element.appendTo(this._appendTo()), "disabled" === e && t && this.xhr && this.xhr.abort()
        },
        _appendTo: function () {
            var t = this.options.appendTo;
            return t && (t = t.jquery || t.nodeType ? e(t) : this.document.find(t).eq(0)), t || (t = this.element.closest(".ui-front")), t.length || (t = this.document[0].body), t
        },
        _initSource: function () {
            var t, i, n = this;
            e.isArray(this.options.source) ? (t = this.options.source, this.source = function (i, n) {
                n(e.ui.autocomplete.filter(t, i.term))
            }) : "string" == typeof this.options.source ? (i = this.options.source, this.source = function (t, s) {
                n.xhr && n.xhr.abort(), n.xhr = e.ajax({
                    url: i,
                    data: t,
                    dataType: "json",
                    success: function (e) {
                        s(e)
                    },
                    error: function () {
                        s([])
                    }
                })
            }) : this.source = this.options.source
        },
        _searchTimeout: function (e) {
            clearTimeout(this.searching), this.searching = this._delay(function () {
                this.term !== this._value() && (this.selectedItem = null, this.search(null, e))
            }, this.options.delay)
        },
        search: function (e, t) {
            return e = null != e ? e : this._value(), this.term = this._value(), e.length < this.options.minLength ? this.close(t) : this._trigger("search", t) !== !1 ? this._search(e) : void 0
        },
        _search: function (e) {
            this.pending++, this.element.addClass("ui-autocomplete-loading"), this.cancelSearch = !1, this.source({
                term: e
            }, this._response())
        },
        _response: function () {
            var t = ++this.requestIndex;
            return e.proxy(function (e) {
                t === this.requestIndex && this.__response(e), this.pending--, this.pending || this.element.removeClass("ui-autocomplete-loading")
            }, this)
        },
        __response: function (e) {
            e && (e = this._normalize(e)), this._trigger("response", null, {
                content: e
            }), !this.options.disabled && e && e.length && !this.cancelSearch ? (this._suggest(e), this._trigger("open")) : this._close()
        },
        close: function (e) {
            this.cancelSearch = !0, this._close(e)
        },
        _close: function (e) {
            this.menu.element.is(":visible") && (this.menu.element.hide(), this.menu.blur(), this.isNewMenu = !0, this._trigger("close", e))
        },
        _change: function (e) {
            this.previous !== this._value() && this._trigger("change", e, {
                item: this.selectedItem
            })
        },
        _normalize: function (t) {
            return t.length && t[0].label && t[0].value ? t : e.map(t, function (t) {
                return "string" == typeof t ? {
                    label: t,
                    value: t
                } : e.extend({
                    label: t.label || t.value,
                    value: t.value || t.label
                }, t)
            })
        },
        _suggest: function (t) {
            var i = this.menu.element.empty();
            this._renderMenu(i, t), this.isNewMenu = !0, this.menu.refresh(), i.show(), this._resizeMenu(), i.position(e.extend({
                of: this.element
            }, this.options.position)), this.options.autoFocus && this.menu.next()
        },
        _resizeMenu: function () {
            var e = this.menu.element;
            e.outerWidth(Math.max(e.width("").outerWidth() + 1, this.element.outerWidth()))
        },
        _renderMenu: function (t, i) {
            var n = this;
            e.each(i, function (e, i) {
                n._renderItemData(t, i)
            })
        },
        _renderItemData: function (e, t) {
            return this._renderItem(e, t).data("ui-autocomplete-item", t)
        },
        _renderItem: function (t, i) {
            return e("<li>").append(e("<a>").text(i.label)).appendTo(t)
        },
        _move: function (e, t) {
            return this.menu.element.is(":visible") ? this.menu.isFirstItem() && /^previous/.test(e) || this.menu.isLastItem() && /^next/.test(e) ? (this._value(this.term), void this.menu.blur()) : void this.menu[e](t) : void this.search(null, t)
        },
        widget: function () {
            return this.menu.element
        },
        _value: function () {
            return this.valueMethod.apply(this.element, arguments)
        },
        _keyEvent: function (e, t) {
            (!this.isMultiLine || this.menu.element.is(":visible")) && (this._move(e, t), t.preventDefault())
        }
    }), e.extend(e.ui.autocomplete, {
        escapeRegex: function (e) {
            return e.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&")
        },
        filter: function (t, i) {
            var n = new RegExp(e.ui.autocomplete.escapeRegex(i), "i");
            return e.grep(t, function (e) {
                return n.test(e.label || e.value || e)
            })
        }
    }), e.widget("ui.autocomplete", e.ui.autocomplete, {
        options: {
            messages: {
                noResults: "No search results.",
                results: function (e) {
                    return e + (e > 1 ? " results are" : " result is") + " available, use up and down arrow keys to navigate."
                }
            }
        },
        __response: function (e) {
            var t;
            this._superApply(arguments), this.options.disabled || this.cancelSearch || (t = e && e.length ? this.options.messages.results(e.length) : this.options.messages.noResults, this.liveRegion.text(t))
        }
    })
}(jQuery),
function (e) {
    var i, n = "ui-button ui-widget ui-state-default ui-corner-all",
        s = "ui-button-icons-only ui-button-icon-only ui-button-text-icons ui-button-text-icon-primary ui-button-text-icon-secondary ui-button-text-only",
        r = function () {
            var t = e(this);
            setTimeout(function () {
                t.find(":ui-button").button("refresh")
            }, 1)
        },
        a = function (t) {
            var i = t.name,
                n = t.form,
                s = e([]);
            return i && (i = i.replace(/'/g, "\\'"), s = n ? e(n).find("[name='" + i + "']") : e("[name='" + i + "']", t.ownerDocument).filter(function () {
                return !this.form
            })), s
        };
    e.widget("ui.button", {
        version: "1.10.4",
        defaultElement: "<button>",
        options: {
            disabled: null,
            text: !0,
            label: null,
            icons: {
                primary: null,
                secondary: null
            }
        },
        _create: function () {
            this.element.closest("form").unbind("reset" + this.eventNamespace).bind("reset" + this.eventNamespace, r), "boolean" != typeof this.options.disabled ? this.options.disabled = !!this.element.prop("disabled") : this.element.prop("disabled", this.options.disabled), this._determineButtonType(), this.hasTitle = !!this.buttonElement.attr("title");
            var t = this,
                s = this.options,
                o = "checkbox" === this.type || "radio" === this.type,
                l = o ? "" : "ui-state-active";
            null === s.label && (s.label = "input" === this.type ? this.buttonElement.val() : this.buttonElement.html()), this._hoverable(this.buttonElement), this.buttonElement.addClass(n).attr("role", "button").bind("mouseenter" + this.eventNamespace, function () {
                s.disabled || this === i && e(this).addClass("ui-state-active")
            }).bind("mouseleave" + this.eventNamespace, function () {
                s.disabled || e(this).removeClass(l)
            }).bind("click" + this.eventNamespace, function (e) {
                s.disabled && (e.preventDefault(), e.stopImmediatePropagation())
            }), this._on({
                focus: function () {
                    this.buttonElement.addClass("ui-state-focus")
                },
                blur: function () {
                    this.buttonElement.removeClass("ui-state-focus")
                }
            }), o && this.element.bind("change" + this.eventNamespace, function () {
                t.refresh()
            }), "checkbox" === this.type ? this.buttonElement.bind("click" + this.eventNamespace, function () {
                return s.disabled ? !1 : void 0
            }) : "radio" === this.type ? this.buttonElement.bind("click" + this.eventNamespace, function () {
                if (s.disabled) return !1;
                e(this).addClass("ui-state-active"), t.buttonElement.attr("aria-pressed", "true");
                var i = t.element[0];
                a(i).not(i).map(function () {
                    return e(this).button("widget")[0]
                }).removeClass("ui-state-active").attr("aria-pressed", "false")
            }) : (this.buttonElement.bind("mousedown" + this.eventNamespace, function () {
                return s.disabled ? !1 : (e(this).addClass("ui-state-active"), i = this, void t.document.one("mouseup", function () {
                    i = null
                }))
            }).bind("mouseup" + this.eventNamespace, function () {
                return s.disabled ? !1 : void e(this).removeClass("ui-state-active")
            }).bind("keydown" + this.eventNamespace, function (t) {
                return s.disabled ? !1 : void((t.keyCode === e.ui.keyCode.SPACE || t.keyCode === e.ui.keyCode.ENTER) && e(this).addClass("ui-state-active"))
            }).bind("keyup" + this.eventNamespace + " blur" + this.eventNamespace, function () {
                e(this).removeClass("ui-state-active")
            }), this.buttonElement.is("a") && this.buttonElement.keyup(function (t) {
                t.keyCode === e.ui.keyCode.SPACE && e(this).click()
            })), this._setOption("disabled", s.disabled), this._resetButton()
        },
        _determineButtonType: function () {
            var e, t, i;
            this.type = this.element.is("[type=checkbox]") ? "checkbox" : this.element.is("[type=radio]") ? "radio" : this.element.is("input") ? "input" : "button", "checkbox" === this.type || "radio" === this.type ? (e = this.element.parents().last(), t = "label[for='" + this.element.attr("id") + "']", this.buttonElement = e.find(t), this.buttonElement.length || (e = e.length ? e.siblings() : this.element.siblings(), this.buttonElement = e.filter(t), this.buttonElement.length || (this.buttonElement = e.find(t))), this.element.addClass("ui-helper-hidden-accessible"), i = this.element.is(":checked"), i && this.buttonElement.addClass("ui-state-active"), this.buttonElement.prop("aria-pressed", i)) : this.buttonElement = this.element
        },
        widget: function () {
            return this.buttonElement
        },
        _destroy: function () {
            this.element.removeClass("ui-helper-hidden-accessible"), this.buttonElement.removeClass(n + " ui-state-active " + s).removeAttr("role").removeAttr("aria-pressed").html(this.buttonElement.find(".ui-button-text").html()), this.hasTitle || this.buttonElement.removeAttr("title")
        },
        _setOption: function (e, t) {
            return this._super(e, t), "disabled" === e ? (this.element.prop("disabled", !!t), void(t && this.buttonElement.removeClass("ui-state-focus"))) : void this._resetButton()
        },
        refresh: function () {
            var t = this.element.is("input, button") ? this.element.is(":disabled") : this.element.hasClass("ui-button-disabled");
            t !== this.options.disabled && this._setOption("disabled", t), "radio" === this.type ? a(this.element[0]).each(function () {
                e(this).is(":checked") ? e(this).button("widget").addClass("ui-state-active").attr("aria-pressed", "true") : e(this).button("widget").removeClass("ui-state-active").attr("aria-pressed", "false")
            }) : "checkbox" === this.type && (this.element.is(":checked") ? this.buttonElement.addClass("ui-state-active").attr("aria-pressed", "true") : this.buttonElement.removeClass("ui-state-active").attr("aria-pressed", "false"))
        },
        _resetButton: function () {
            if ("input" === this.type) return void(this.options.label && this.element.val(this.options.label));
            var t = this.buttonElement.removeClass(s),
                i = e("<span></span>", this.document[0]).addClass("ui-button-text").html(this.options.label).appendTo(t.empty()).text(),
                n = this.options.icons,
                r = n.primary && n.secondary,
                a = [];
            n.primary || n.secondary ? (this.options.text && a.push("ui-button-text-icon" + (r ? "s" : n.primary ? "-primary" : "-secondary")), n.primary && t.prepend("<span class='ui-button-icon-primary ui-icon " + n.primary + "'></span>"), n.secondary && t.append("<span class='ui-button-icon-secondary ui-icon " + n.secondary + "'></span>"), this.options.text || (a.push(r ? "ui-button-icons-only" : "ui-button-icon-only"), this.hasTitle || t.attr("title", e.trim(i)))) : a.push("ui-button-text-only"), t.addClass(a.join(" "))
        }
    }), e.widget("ui.buttonset", {
        version: "1.10.4",
        options: {
            items: "button, input[type=button], input[type=submit], input[type=reset], input[type=checkbox], input[type=radio], a, :data(ui-button)"
        },
        _create: function () {
            this.element.addClass("ui-buttonset")
        },
        _init: function () {
            this.refresh()
        },
        _setOption: function (e, t) {
            "disabled" === e && this.buttons.button("option", e, t), this._super(e, t)
        },
        refresh: function () {
            var t = "rtl" === this.element.css("direction");
            this.buttons = this.element.find(this.options.items).filter(":ui-button").button("refresh").end().not(":ui-button").button().end().map(function () {
                return e(this).button("widget")[0]
            }).removeClass("ui-corner-all ui-corner-left ui-corner-right").filter(":first").addClass(t ? "ui-corner-right" : "ui-corner-left").end().filter(":last").addClass(t ? "ui-corner-left" : "ui-corner-right").end().end()
        },
        _destroy: function () {
            this.element.removeClass("ui-buttonset"), this.buttons.map(function () {
                return e(this).button("widget")[0]
            }).removeClass("ui-corner-left ui-corner-right").end().button("destroy")
        }
    })
}(jQuery),
function (e, t) {
    function s() {
        this._curInst = null, this._keyEvent = !1, this._disabledInputs = [], this._datepickerShowing = !1, this._inDialog = !1, this._mainDivId = "ui-datepicker-div", this._inlineClass = "ui-datepicker-inline", this._appendClass = "ui-datepicker-append", this._triggerClass = "ui-datepicker-trigger", this._dialogClass = "ui-datepicker-dialog", this._disableClass = "ui-datepicker-disabled", this._unselectableClass = "ui-datepicker-unselectable", this._currentClass = "ui-datepicker-current-day", this._dayOverClass = "ui-datepicker-days-cell-over", this.regional = [], this.regional[""] = {
            closeText: "Done",
            prevText: "Prev",
            nextText: "Next",
            currentText: "Today",
            monthNames: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
            monthNamesShort: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
            dayNames: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
            dayNamesShort: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
            dayNamesMin: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
            weekHeader: "Wk",
            dateFormat: "mm/dd/yy",
            firstDay: 0,
            isRTL: !1,
            showMonthAfterYear: !1,
            yearSuffix: ""
        }, this._defaults = {
            showOn: "focus",
            showAnim: "fadeIn",
            showOptions: {},
            defaultDate: null,
            appendText: "",
            buttonText: "...",
            buttonImage: "",
            buttonImageOnly: !1,
            hideIfNoPrevNext: !1,
            navigationAsDateFormat: !1,
            gotoCurrent: !1,
            changeMonth: !1,
            changeYear: !1,
            yearRange: "c-10:c+10",
            showOtherMonths: !1,
            selectOtherMonths: !1,
            showWeek: !1,
            calculateWeek: this.iso8601Week,
            shortYearCutoff: "+10",
            minDate: null,
            maxDate: null,
            duration: "fast",
            beforeShowDay: null,
            beforeShow: null,
            onSelect: null,
            onChangeMonthYear: null,
            onClose: null,
            numberOfMonths: 1,
            showCurrentAtPos: 0,
            stepMonths: 1,
            stepBigMonths: 12,
            altField: "",
            altFormat: "",
            constrainInput: !0,
            showButtonPanel: !1,
            autoSize: !1,
            disabled: !1
        }, e.extend(this._defaults, this.regional[""]), this.dpDiv = r(e("<div id='" + this._mainDivId + "' class='ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all'></div>"))
    }

    function r(t) {
        var i = "button, .ui-datepicker-prev, .ui-datepicker-next, .ui-datepicker-calendar td a";
        return t.delegate(i, "mouseout", function () {
            e(this).removeClass("ui-state-hover"), -1 !== this.className.indexOf("ui-datepicker-prev") && e(this).removeClass("ui-datepicker-prev-hover"), -1 !== this.className.indexOf("ui-datepicker-next") && e(this).removeClass("ui-datepicker-next-hover")
        }).delegate(i, "mouseover", function () {
            e.datepicker._isDisabledDatepicker(n.inline ? t.parent()[0] : n.input[0]) || (e(this).parents(".ui-datepicker-calendar").find("a").removeClass("ui-state-hover"), e(this).addClass("ui-state-hover"), -1 !== this.className.indexOf("ui-datepicker-prev") && e(this).addClass("ui-datepicker-prev-hover"), -1 !== this.className.indexOf("ui-datepicker-next") && e(this).addClass("ui-datepicker-next-hover"))
        })
    }

    function a(t, i) {
        e.extend(t, i);
        for (var n in i) null == i[n] && (t[n] = i[n]);
        return t
    }
    e.extend(e.ui, {
        datepicker: {
            version: "1.10.4"
        }
    });
    var n, i = "datepicker";
    e.extend(s.prototype, {
        markerClassName: "hasDatepicker",
        maxRows: 4,
        _widgetDatepicker: function () {
            return this.dpDiv
        },
        setDefaults: function (e) {
            return a(this._defaults, e || {}), this
        },
        _attachDatepicker: function (t, i) {
            var n, s, r;
            n = t.nodeName.toLowerCase(), s = "div" === n || "span" === n, t.id || (this.uuid += 1, t.id = "dp" + this.uuid), r = this._newInst(e(t), s), r.settings = e.extend({}, i || {}), "input" === n ? this._connectDatepicker(t, r) : s && this._inlineDatepicker(t, r)
        },
        _newInst: function (t, i) {
            var n = t[0].id.replace(/([^A-Za-z0-9_\-])/g, "\\\\$1");
            return {
                id: n,
                input: t,
                selectedDay: 0,
                selectedMonth: 0,
                selectedYear: 0,
                drawMonth: 0,
                drawYear: 0,
                inline: i,
                dpDiv: i ? r(e("<div class='" + this._inlineClass + " ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all'></div>")) : this.dpDiv
            }
        },
        _connectDatepicker: function (t, n) {
            var s = e(t);
            n.append = e([]), n.trigger = e([]), s.hasClass(this.markerClassName) || (this._attachments(s, n), s.addClass(this.markerClassName).keydown(this._doKeyDown).keypress(this._doKeyPress).keyup(this._doKeyUp), this._autoSize(n), e.data(t, i, n), n.settings.disabled && this._disableDatepicker(t))
        },
        _attachments: function (t, i) {
            var n, s, r, a = this._get(i, "appendText"),
                o = this._get(i, "isRTL");
            i.append && i.append.remove(), a && (i.append = e("<span class='" + this._appendClass + "'>" + a + "</span>"), t[o ? "before" : "after"](i.append)), t.unbind("focus", this._showDatepicker), i.trigger && i.trigger.remove(), n = this._get(i, "showOn"), ("focus" === n || "both" === n) && t.focus(this._showDatepicker), ("button" === n || "both" === n) && (s = this._get(i, "buttonText"), r = this._get(i, "buttonImage"), i.trigger = e(this._get(i, "buttonImageOnly") ? e("<img/>").addClass(this._triggerClass).attr({
                src: r,
                alt: s,
                title: s
            }) : e("<button type='button'></button>").addClass(this._triggerClass).html(r ? e("<img/>").attr({
                src: r,
                alt: s,
                title: s
            }) : s)), t[o ? "before" : "after"](i.trigger), i.trigger.click(function () {
                return e.datepicker._datepickerShowing && e.datepicker._lastInput === t[0] ? e.datepicker._hideDatepicker() : e.datepicker._datepickerShowing && e.datepicker._lastInput !== t[0] ? (e.datepicker._hideDatepicker(), e.datepicker._showDatepicker(t[0])) : e.datepicker._showDatepicker(t[0]), !1
            }))
        },
        _autoSize: function (e) {
            if (this._get(e, "autoSize") && !e.inline) {
                var t, i, n, s, r = new Date(2009, 11, 20),
                    a = this._get(e, "dateFormat");
                a.match(/[DM]/) && (t = function (e) {
                    for (i = 0, n = 0, s = 0; s < e.length; s++) e[s].length > i && (i = e[s].length, n = s);
                    return n
                }, r.setMonth(t(this._get(e, a.match(/MM/) ? "monthNames" : "monthNamesShort"))), r.setDate(t(this._get(e, a.match(/DD/) ? "dayNames" : "dayNamesShort")) + 20 - r.getDay())), e.input.attr("size", this._formatDate(e, r).length)
            }
        },
        _inlineDatepicker: function (t, n) {
            var s = e(t);
            s.hasClass(this.markerClassName) || (s.addClass(this.markerClassName).append(n.dpDiv), e.data(t, i, n), this._setDate(n, this._getDefaultDate(n), !0), this._updateDatepicker(n), this._updateAlternate(n), n.settings.disabled && this._disableDatepicker(t), n.dpDiv.css("display", "block"))
        },
        _dialogDatepicker: function (t, n, s, r, o) {
            var l, u, h, f, c, d = this._dialogInst;
            return d || (this.uuid += 1, l = "dp" + this.uuid, this._dialogInput = e("<input type='text' id='" + l + "' style='position: absolute; top: -100px; width: 0px;'/>"), this._dialogInput.keydown(this._doKeyDown), e("body").append(this._dialogInput), d = this._dialogInst = this._newInst(this._dialogInput, !1), d.settings = {}, e.data(this._dialogInput[0], i, d)), a(d.settings, r || {}), n = n && n.constructor === Date ? this._formatDate(d, n) : n, this._dialogInput.val(n), this._pos = o ? o.length ? o : [o.pageX, o.pageY] : null, this._pos || (u = document.documentElement.clientWidth, h = document.documentElement.clientHeight, f = document.documentElement.scrollLeft || document.body.scrollLeft, c = document.documentElement.scrollTop || document.body.scrollTop, this._pos = [u / 2 - 100 + f, h / 2 - 150 + c]), this._dialogInput.css("left", this._pos[0] + 20 + "px").css("top", this._pos[1] + "px"), d.settings.onSelect = s, this._inDialog = !0, this.dpDiv.addClass(this._dialogClass), this._showDatepicker(this._dialogInput[0]), e.blockUI && e.blockUI(this.dpDiv), e.data(this._dialogInput[0], i, d), this
        },
        _destroyDatepicker: function (t) {
            var n, s = e(t),
                r = e.data(t, i);
            s.hasClass(this.markerClassName) && (n = t.nodeName.toLowerCase(), e.removeData(t, i), "input" === n ? (r.append.remove(), r.trigger.remove(), s.removeClass(this.markerClassName).unbind("focus", this._showDatepicker).unbind("keydown", this._doKeyDown).unbind("keypress", this._doKeyPress).unbind("keyup", this._doKeyUp)) : ("div" === n || "span" === n) && s.removeClass(this.markerClassName).empty())
        },
        _enableDatepicker: function (t) {
            var n, s, r = e(t),
                a = e.data(t, i);
            r.hasClass(this.markerClassName) && (n = t.nodeName.toLowerCase(), "input" === n ? (t.disabled = !1, a.trigger.filter("button").each(function () {
                this.disabled = !1
            }).end().filter("img").css({
                opacity: "1.0",
                cursor: ""
            })) : ("div" === n || "span" === n) && (s = r.children("." + this._inlineClass), s.children().removeClass("ui-state-disabled"), s.find("select.ui-datepicker-month, select.ui-datepicker-year").prop("disabled", !1)), this._disabledInputs = e.map(this._disabledInputs, function (e) {
                return e === t ? null : e
            }))
        },
        _disableDatepicker: function (t) {
            var n, s, r = e(t),
                a = e.data(t, i);
            r.hasClass(this.markerClassName) && (n = t.nodeName.toLowerCase(), "input" === n ? (t.disabled = !0, a.trigger.filter("button").each(function () {
                this.disabled = !0
            }).end().filter("img").css({
                opacity: "0.5",
                cursor: "default"
            })) : ("div" === n || "span" === n) && (s = r.children("." + this._inlineClass), s.children().addClass("ui-state-disabled"), s.find("select.ui-datepicker-month, select.ui-datepicker-year").prop("disabled", !0)), this._disabledInputs = e.map(this._disabledInputs, function (e) {
                return e === t ? null : e
            }), this._disabledInputs[this._disabledInputs.length] = t)
        },
        _isDisabledDatepicker: function (e) {
            if (!e) return !1;
            for (var t = 0; t < this._disabledInputs.length; t++)
                if (this._disabledInputs[t] === e) return !0;
            return !1
        },
        _getInst: function (t) {
            try {
                return e.data(t, i)
            } catch (n) {
                throw "Missing instance data for this datepicker"
            }
        },
        _optionDatepicker: function (i, n, s) {
            var r, o, l, u, h = this._getInst(i);
            return 2 === arguments.length && "string" == typeof n ? "defaults" === n ? e.extend({}, e.datepicker._defaults) : h ? "all" === n ? e.extend({}, h.settings) : this._get(h, n) : null : (r = n || {}, "string" == typeof n && (r = {}, r[n] = s), void(h && (this._curInst === h && this._hideDatepicker(), o = this._getDateDatepicker(i, !0), l = this._getMinMaxDate(h, "min"), u = this._getMinMaxDate(h, "max"), a(h.settings, r), null !== l && r.dateFormat !== t && r.minDate === t && (h.settings.minDate = this._formatDate(h, l)), null !== u && r.dateFormat !== t && r.maxDate === t && (h.settings.maxDate = this._formatDate(h, u)), "disabled" in r && (r.disabled ? this._disableDatepicker(i) : this._enableDatepicker(i)), this._attachments(e(i), h), this._autoSize(h), this._setDate(h, o), this._updateAlternate(h), this._updateDatepicker(h))))
        },
        _changeDatepicker: function (e, t, i) {
            this._optionDatepicker(e, t, i)
        },
        _refreshDatepicker: function (e) {
            var t = this._getInst(e);
            t && this._updateDatepicker(t)
        },
        _setDateDatepicker: function (e, t) {
            var i = this._getInst(e);
            i && (this._setDate(i, t), this._updateDatepicker(i), this._updateAlternate(i))
        },
        _getDateDatepicker: function (e, t) {
            var i = this._getInst(e);
            return i && !i.inline && this._setDateFromField(i, t), i ? this._getDate(i) : null
        },
        _doKeyDown: function (t) {
            var i, n, s, r = e.datepicker._getInst(t.target),
                a = !0,
                o = r.dpDiv.is(".ui-datepicker-rtl");
            if (r._keyEvent = !0, e.datepicker._datepickerShowing) switch (t.keyCode) {
                case 9:
                    e.datepicker._hideDatepicker(), a = !1;
                    break;
                case 13:
                    return s = e("td." + e.datepicker._dayOverClass + ":not(." + e.datepicker._currentClass + ")", r.dpDiv), s[0] && e.datepicker._selectDay(t.target, r.selectedMonth, r.selectedYear, s[0]), i = e.datepicker._get(r, "onSelect"), i ? (n = e.datepicker._formatDate(r), i.apply(r.input ? r.input[0] : null, [n, r])) : e.datepicker._hideDatepicker(), !1;
                case 27:
                    e.datepicker._hideDatepicker();
                    break;
                case 33:
                    e.datepicker._adjustDate(t.target, t.ctrlKey ? -e.datepicker._get(r, "stepBigMonths") : -e.datepicker._get(r, "stepMonths"), "M");
                    break;
                case 34:
                    e.datepicker._adjustDate(t.target, t.ctrlKey ? +e.datepicker._get(r, "stepBigMonths") : +e.datepicker._get(r, "stepMonths"), "M");
                    break;
                case 35:
                    (t.ctrlKey || t.metaKey) && e.datepicker._clearDate(t.target), a = t.ctrlKey || t.metaKey;
                    break;
                case 36:
                    (t.ctrlKey || t.metaKey) && e.datepicker._gotoToday(t.target), a = t.ctrlKey || t.metaKey;
                    break;
                case 37:
                    (t.ctrlKey || t.metaKey) && e.datepicker._adjustDate(t.target, o ? 1 : -1, "D"), a = t.ctrlKey || t.metaKey, t.originalEvent.altKey && e.datepicker._adjustDate(t.target, t.ctrlKey ? -e.datepicker._get(r, "stepBigMonths") : -e.datepicker._get(r, "stepMonths"), "M");
                    break;
                case 38:
                    (t.ctrlKey || t.metaKey) && e.datepicker._adjustDate(t.target, -7, "D"), a = t.ctrlKey || t.metaKey;
                    break;
                case 39:
                    (t.ctrlKey || t.metaKey) && e.datepicker._adjustDate(t.target, o ? -1 : 1, "D"), a = t.ctrlKey || t.metaKey, t.originalEvent.altKey && e.datepicker._adjustDate(t.target, t.ctrlKey ? +e.datepicker._get(r, "stepBigMonths") : +e.datepicker._get(r, "stepMonths"), "M");
                    break;
                case 40:
                    (t.ctrlKey || t.metaKey) && e.datepicker._adjustDate(t.target, 7, "D"), a = t.ctrlKey || t.metaKey;
                    break;
                default:
                    a = !1
            } else 36 === t.keyCode && t.ctrlKey ? e.datepicker._showDatepicker(this) : a = !1;
            a && (t.preventDefault(), t.stopPropagation())
        },
        _doKeyPress: function (t) {
            var i, n, s = e.datepicker._getInst(t.target);
            return e.datepicker._get(s, "constrainInput") ? (i = e.datepicker._possibleChars(e.datepicker._get(s, "dateFormat")), n = String.fromCharCode(null == t.charCode ? t.keyCode : t.charCode), t.ctrlKey || t.metaKey || " " > n || !i || i.indexOf(n) > -1) : void 0
        },
        _doKeyUp: function (t) {
            var i, n = e.datepicker._getInst(t.target);
            if (n.input.val() !== n.lastVal) try {
                i = e.datepicker.parseDate(e.datepicker._get(n, "dateFormat"), n.input ? n.input.val() : null, e.datepicker._getFormatConfig(n)), i && (e.datepicker._setDateFromField(n), e.datepicker._updateAlternate(n), e.datepicker._updateDatepicker(n))
            } catch (s) {}
            return !0
        },
        _showDatepicker: function (t) {
            if (t = t.target || t, "input" !== t.nodeName.toLowerCase() && (t = e("input", t.parentNode)[0]), !e.datepicker._isDisabledDatepicker(t) && e.datepicker._lastInput !== t) {
                var i, n, s, r, o, l, u;
                i = e.datepicker._getInst(t), e.datepicker._curInst && e.datepicker._curInst !== i && (e.datepicker._curInst.dpDiv.stop(!0, !0), i && e.datepicker._datepickerShowing && e.datepicker._hideDatepicker(e.datepicker._curInst.input[0])), n = e.datepicker._get(i, "beforeShow"), s = n ? n.apply(t, [t, i]) : {}, s !== !1 && (a(i.settings, s), i.lastVal = null, e.datepicker._lastInput = t, e.datepicker._setDateFromField(i), e.datepicker._inDialog && (t.value = ""), e.datepicker._pos || (e.datepicker._pos = e.datepicker._findPos(t), e.datepicker._pos[1] += t.offsetHeight), r = !1, e(t).parents().each(function () {
                    return r |= "fixed" === e(this).css("position"), !r
                }), o = {
                    left: e.datepicker._pos[0],
                    top: e.datepicker._pos[1]
                }, e.datepicker._pos = null, i.dpDiv.empty(), i.dpDiv.css({
                    position: "absolute",
                    display: "block",
                    top: "-1000px"
                }), e.datepicker._updateDatepicker(i), o = e.datepicker._checkOffset(i, o, r), i.dpDiv.css({
                    position: e.datepicker._inDialog && e.blockUI ? "static" : r ? "fixed" : "absolute",
                    display: "none",
                    left: o.left + "px",
                    top: o.top + "px"
                }), i.inline || (l = e.datepicker._get(i, "showAnim"), u = e.datepicker._get(i, "duration"), i.dpDiv.zIndex(e(t).zIndex() + 1), e.datepicker._datepickerShowing = !0, e.effects && e.effects.effect[l] ? i.dpDiv.show(l, e.datepicker._get(i, "showOptions"), u) : i.dpDiv[l || "show"](l ? u : null), e.datepicker._shouldFocusInput(i) && i.input.focus(), e.datepicker._curInst = i))
            }
        },
        _updateDatepicker: function (t) {
            this.maxRows = 4, n = t, t.dpDiv.empty().append(this._generateHTML(t)), this._attachHandlers(t), t.dpDiv.find("." + this._dayOverClass + " a").mouseover();
            var i, s = this._getNumberOfMonths(t),
                r = s[1],
                a = 17;
            t.dpDiv.removeClass("ui-datepicker-multi-2 ui-datepicker-multi-3 ui-datepicker-multi-4").width(""), r > 1 && t.dpDiv.addClass("ui-datepicker-multi-" + r).css("width", a * r + "em"), t.dpDiv[(1 !== s[0] || 1 !== s[1] ? "add" : "remove") + "Class"]("ui-datepicker-multi"), t.dpDiv[(this._get(t, "isRTL") ? "add" : "remove") + "Class"]("ui-datepicker-rtl"), t === e.datepicker._curInst && e.datepicker._datepickerShowing && e.datepicker._shouldFocusInput(t) && t.input.focus(), t.yearshtml && (i = t.yearshtml, setTimeout(function () {
                i === t.yearshtml && t.yearshtml && t.dpDiv.find("select.ui-datepicker-year:first").replaceWith(t.yearshtml), i = t.yearshtml = null
            }, 0))
        },
        _shouldFocusInput: function (e) {
            return e.input && e.input.is(":visible") && !e.input.is(":disabled") && !e.input.is(":focus")
        },
        _checkOffset: function (t, i, n) {
            var s = t.dpDiv.outerWidth(),
                r = t.dpDiv.outerHeight(),
                a = t.input ? t.input.outerWidth() : 0,
                o = t.input ? t.input.outerHeight() : 0,
                l = document.documentElement.clientWidth + (n ? 0 : e(document).scrollLeft()),
                u = document.documentElement.clientHeight + (n ? 0 : e(document).scrollTop());
            return i.left -= this._get(t, "isRTL") ? s - a : 0, i.left -= n && i.left === t.input.offset().left ? e(document).scrollLeft() : 0, i.top -= n && i.top === t.input.offset().top + o ? e(document).scrollTop() : 0, i.left -= Math.min(i.left, i.left + s > l && l > s ? Math.abs(i.left + s - l) : 0), i.top -= Math.min(i.top, i.top + r > u && u > r ? Math.abs(r + o) : 0), i
        },
        _findPos: function (t) {
            for (var i, n = this._getInst(t), s = this._get(n, "isRTL"); t && ("hidden" === t.type || 1 !== t.nodeType || e.expr.filters.hidden(t));) t = t[s ? "previousSibling" : "nextSibling"];
            return i = e(t).offset(), [i.left, i.top]
        },
        _hideDatepicker: function (t) {
            var n, s, r, a, o = this._curInst;
            !o || t && o !== e.data(t, i) || this._datepickerShowing && (n = this._get(o, "showAnim"), s = this._get(o, "duration"), r = function () {
                e.datepicker._tidyDialog(o)
            }, e.effects && (e.effects.effect[n] || e.effects[n]) ? o.dpDiv.hide(n, e.datepicker._get(o, "showOptions"), s, r) : o.dpDiv["slideDown" === n ? "slideUp" : "fadeIn" === n ? "fadeOut" : "hide"](n ? s : null, r), n || r(), this._datepickerShowing = !1, a = this._get(o, "onClose"), a && a.apply(o.input ? o.input[0] : null, [o.input ? o.input.val() : "", o]), this._lastInput = null, this._inDialog && (this._dialogInput.css({
                position: "absolute",
                left: "0",
                top: "-100px"
            }), e.blockUI && (e.unblockUI(), e("body").append(this.dpDiv))), this._inDialog = !1)
        },
        _tidyDialog: function (e) {
            e.dpDiv.removeClass(this._dialogClass).unbind(".ui-datepicker-calendar")
        },
        _checkExternalClick: function (t) {
            if (e.datepicker._curInst) {
                var i = e(t.target),
                    n = e.datepicker._getInst(i[0]);
                (i[0].id !== e.datepicker._mainDivId && 0 === i.parents("#" + e.datepicker._mainDivId).length && !i.hasClass(e.datepicker.markerClassName) && !i.closest("." + e.datepicker._triggerClass).length && e.datepicker._datepickerShowing && (!e.datepicker._inDialog || !e.blockUI) || i.hasClass(e.datepicker.markerClassName) && e.datepicker._curInst !== n) && e.datepicker._hideDatepicker()
            }
        },
        _adjustDate: function (t, i, n) {
            var s = e(t),
                r = this._getInst(s[0]);
            this._isDisabledDatepicker(s[0]) || (this._adjustInstDate(r, i + ("M" === n ? this._get(r, "showCurrentAtPos") : 0), n), this._updateDatepicker(r))
        },
        _gotoToday: function (t) {
            var i, n = e(t),
                s = this._getInst(n[0]);
            this._get(s, "gotoCurrent") && s.currentDay ? (s.selectedDay = s.currentDay, s.drawMonth = s.selectedMonth = s.currentMonth, s.drawYear = s.selectedYear = s.currentYear) : (i = new Date, s.selectedDay = i.getDate(), s.drawMonth = s.selectedMonth = i.getMonth(), s.drawYear = s.selectedYear = i.getFullYear()), this._notifyChange(s), this._adjustDate(n)
        },
        _selectMonthYear: function (t, i, n) {
            var s = e(t),
                r = this._getInst(s[0]);
            r["selected" + ("M" === n ? "Month" : "Year")] = r["draw" + ("M" === n ? "Month" : "Year")] = parseInt(i.options[i.selectedIndex].value, 10), this._notifyChange(r), this._adjustDate(s)
        },
        _selectDay: function (t, i, n, s) {
            var r, a = e(t);
            e(s).hasClass(this._unselectableClass) || this._isDisabledDatepicker(a[0]) || (r = this._getInst(a[0]), r.selectedDay = r.currentDay = e("a", s).html(), r.selectedMonth = r.currentMonth = i, r.selectedYear = r.currentYear = n, this._selectDate(t, this._formatDate(r, r.currentDay, r.currentMonth, r.currentYear)))
        },
        _clearDate: function (t) {
            var i = e(t);
            this._selectDate(i, "")
        },
        _selectDate: function (t, i) {
            var n, s = e(t),
                r = this._getInst(s[0]);
            i = null != i ? i : this._formatDate(r), r.input && r.input.val(i), this._updateAlternate(r), n = this._get(r, "onSelect"), n ? n.apply(r.input ? r.input[0] : null, [i, r]) : r.input && r.input.trigger("change"), r.inline ? this._updateDatepicker(r) : (this._hideDatepicker(), this._lastInput = r.input[0], "object" != typeof r.input[0] && r.input.focus(), this._lastInput = null)
        },
        _updateAlternate: function (t) {
            var i, n, s, r = this._get(t, "altField");
            r && (i = this._get(t, "altFormat") || this._get(t, "dateFormat"), n = this._getDate(t), s = this.formatDate(i, n, this._getFormatConfig(t)), e(r).each(function () {
                e(this).val(s)
            }))
        },
        noWeekends: function (e) {
            var t = e.getDay();
            return [t > 0 && 6 > t, ""]
        },
        iso8601Week: function (e) {
            var t, i = new Date(e.getTime());
            return i.setDate(i.getDate() + 4 - (i.getDay() || 7)), t = i.getTime(), i.setMonth(0), i.setDate(1), Math.floor(Math.round((t - i) / 864e5) / 7) + 1
        },
        parseDate: function (t, i, n) {
            if (null == t || null == i) throw "Invalid arguments";
            if (i = "object" == typeof i ? i.toString() : i + "", "" === i) return null;
            var s, r, a, y, o = 0,
                l = (n ? n.shortYearCutoff : null) || this._defaults.shortYearCutoff,
                u = "string" != typeof l ? l : (new Date).getFullYear() % 100 + parseInt(l, 10),
                h = (n ? n.dayNamesShort : null) || this._defaults.dayNamesShort,
                f = (n ? n.dayNames : null) || this._defaults.dayNames,
                c = (n ? n.monthNamesShort : null) || this._defaults.monthNamesShort,
                d = (n ? n.monthNames : null) || this._defaults.monthNames,
                p = -1,
                g = -1,
                m = -1,
                v = -1,
                b = !1,
                _ = function (e) {
                    var i = s + 1 < t.length && t.charAt(s + 1) === e;
                    return i && s++, i
                },
                w = function (e) {
                    var t = _(e),
                        n = "@" === e ? 14 : "!" === e ? 20 : "y" === e && t ? 4 : "o" === e ? 3 : 2,
                        s = new RegExp("^\\d{1," + n + "}"),
                        r = i.substring(o).match(s);
                    if (!r) throw "Missing number at position " + o;
                    return o += r[0].length, parseInt(r[0], 10)
                },
                x = function (t, n, s) {
                    var r = -1,
                        a = e.map(_(t) ? s : n, function (e, t) {
                            return [[t, e]]
                        }).sort(function (e, t) {
                            return -(e[1].length - t[1].length)
                        });
                    if (e.each(a, function (e, t) {
                            var n = t[1];
                            return i.substr(o, n.length).toLowerCase() === n.toLowerCase() ? (r = t[0], o += n.length, !1) : void 0
                        }), -1 !== r) return r + 1;
                    throw "Unknown name at position " + o
                },
                k = function () {
                    if (i.charAt(o) !== t.charAt(s)) throw "Unexpected literal at position " + o;
                    o++
                };
            for (s = 0; s < t.length; s++)
                if (b) "'" !== t.charAt(s) || _("'") ? k() : b = !1;
                else switch (t.charAt(s)) {
                    case "d":
                        m = w("d");
                        break;
                    case "D":
                        x("D", h, f);
                        break;
                    case "o":
                        v = w("o");
                        break;
                    case "m":
                        g = w("m");
                        break;
                    case "M":
                        g = x("M", c, d);
                        break;
                    case "y":
                        p = w("y");
                        break;
                    case "@":
                        y = new Date(w("@")), p = y.getFullYear(), g = y.getMonth() + 1, m = y.getDate();
                        break;
                    case "!":
                        y = new Date((w("!") - this._ticksTo1970) / 1e4), p = y.getFullYear(), g = y.getMonth() + 1, m = y.getDate();
                        break;
                    case "'":
                        _("'") ? k() : b = !0;
                        break;
                    default:
                        k()
                }
                if (o < i.length && (a = i.substr(o), !/^\s+/.test(a))) throw "Extra/unparsed characters found in date: " + a;
            if (-1 === p ? p = (new Date).getFullYear() : 100 > p && (p += (new Date).getFullYear() - (new Date).getFullYear() % 100 + (u >= p ? 0 : -100)), v > -1)
                for (g = 1, m = v;;) {
                    if (r = this._getDaysInMonth(p, g - 1), r >= m) break;
                    g++, m -= r
                }
            if (y = this._daylightSavingAdjust(new Date(p, g - 1, m)), y.getFullYear() !== p || y.getMonth() + 1 !== g || y.getDate() !== m) throw "Invalid date";
            return y
        },
        ATOM: "yy-mm-dd",
        COOKIE: "D, dd M yy",
        ISO_8601: "yy-mm-dd",
        RFC_822: "D, d M y",
        RFC_850: "DD, dd-M-y",
        RFC_1036: "D, d M y",
        RFC_1123: "D, d M yy",
        RFC_2822: "D, d M yy",
        RSS: "D, d M y",
        TICKS: "!",
        TIMESTAMP: "@",
        W3C: "yy-mm-dd",
        _ticksTo1970: 24 * (718685 + Math.floor(492.5) - Math.floor(19.7) + Math.floor(4.925)) * 60 * 60 * 1e7,
        formatDate: function (e, t, i) {
            if (!t) return "";
            var n, s = (i ? i.dayNamesShort : null) || this._defaults.dayNamesShort,
                r = (i ? i.dayNames : null) || this._defaults.dayNames,
                a = (i ? i.monthNamesShort : null) || this._defaults.monthNamesShort,
                o = (i ? i.monthNames : null) || this._defaults.monthNames,
                l = function (t) {
                    var i = n + 1 < e.length && e.charAt(n + 1) === t;
                    return i && n++, i
                },
                u = function (e, t, i) {
                    var n = "" + t;
                    if (l(e))
                        for (; n.length < i;) n = "0" + n;
                    return n
                },
                h = function (e, t, i, n) {
                    return l(e) ? n[t] : i[t]
                },
                f = "",
                c = !1;
            if (t)
                for (n = 0; n < e.length; n++)
                    if (c) "'" !== e.charAt(n) || l("'") ? f += e.charAt(n) : c = !1;
                    else switch (e.charAt(n)) {
                        case "d":
                            f += u("d", t.getDate(), 2);
                            break;
                        case "D":
                            f += h("D", t.getDay(), s, r);
                            break;
                        case "o":
                            f += u("o", Math.round((new Date(t.getFullYear(), t.getMonth(), t.getDate()).getTime() - new Date(t.getFullYear(), 0, 0).getTime()) / 864e5), 3);
                            break;
                        case "m":
                            f += u("m", t.getMonth() + 1, 2);
                            break;
                        case "M":
                            f += h("M", t.getMonth(), a, o);
                            break;
                        case "y":
                            f += l("y") ? t.getFullYear() : (t.getYear() % 100 < 10 ? "0" : "") + t.getYear() % 100;
                            break;
                        case "@":
                            f += t.getTime();
                            break;
                        case "!":
                            f += 1e4 * t.getTime() + this._ticksTo1970;
                            break;
                        case "'":
                            l("'") ? f += "'" : c = !0;
                            break;
                        default:
                            f += e.charAt(n)
                    }
                    return f
        },
        _possibleChars: function (e) {
            var t, i = "",
                n = !1,
                s = function (i) {
                    var n = t + 1 < e.length && e.charAt(t + 1) === i;
                    return n && t++, n
                };
            for (t = 0; t < e.length; t++)
                if (n) "'" !== e.charAt(t) || s("'") ? i += e.charAt(t) : n = !1;
                else switch (e.charAt(t)) {
                    case "d":
                    case "m":
                    case "y":
                    case "@":
                        i += "0123456789";
                        break;
                    case "D":
                    case "M":
                        return null;
                    case "'":
                        s("'") ? i += "'" : n = !0;
                        break;
                    default:
                        i += e.charAt(t)
                }
                return i
        },
        _get: function (e, i) {
            return e.settings[i] !== t ? e.settings[i] : this._defaults[i]
        },
        _setDateFromField: function (e, t) {
            if (e.input.val() !== e.lastVal) {
                var i = this._get(e, "dateFormat"),
                    n = e.lastVal = e.input ? e.input.val() : null,
                    s = this._getDefaultDate(e),
                    r = s,
                    a = this._getFormatConfig(e);
                try {
                    r = this.parseDate(i, n, a) || s
                } catch (o) {
                    n = t ? "" : n
                }
                e.selectedDay = r.getDate(), e.drawMonth = e.selectedMonth = r.getMonth(), e.drawYear = e.selectedYear = r.getFullYear(), e.currentDay = n ? r.getDate() : 0, e.currentMonth = n ? r.getMonth() : 0, e.currentYear = n ? r.getFullYear() : 0, this._adjustInstDate(e)
            }
        },
        _getDefaultDate: function (e) {
            return this._restrictMinMax(e, this._determineDate(e, this._get(e, "defaultDate"), new Date))
        },
        _determineDate: function (t, i, n) {
            var s = function (e) {
                    var t = new Date;
                    return t.setDate(t.getDate() + e), t
                },
                r = function (i) {
                    try {
                        return e.datepicker.parseDate(e.datepicker._get(t, "dateFormat"), i, e.datepicker._getFormatConfig(t))
                    } catch (n) {}
                    for (var s = (i.toLowerCase().match(/^c/) ? e.datepicker._getDate(t) : null) || new Date, r = s.getFullYear(), a = s.getMonth(), o = s.getDate(), l = /([+\-]?[0-9]+)\s*(d|D|w|W|m|M|y|Y)?/g, u = l.exec(i); u;) {
                        switch (u[2] || "d") {
                            case "d":
                            case "D":
                                o += parseInt(u[1], 10);
                                break;
                            case "w":
                            case "W":
                                o += 7 * parseInt(u[1], 10);
                                break;
                            case "m":
                            case "M":
                                a += parseInt(u[1], 10), o = Math.min(o, e.datepicker._getDaysInMonth(r, a));
                                break;
                            case "y":
                            case "Y":
                                r += parseInt(u[1], 10), o = Math.min(o, e.datepicker._getDaysInMonth(r, a))
                        }
                        u = l.exec(i)
                    }
                    return new Date(r, a, o)
                },
                a = null == i || "" === i ? n : "string" == typeof i ? r(i) : "number" == typeof i ? isNaN(i) ? n : s(i) : new Date(i.getTime());
            return a = a && "Invalid Date" === a.toString() ? n : a, a && (a.setHours(0), a.setMinutes(0), a.setSeconds(0), a.setMilliseconds(0)), this._daylightSavingAdjust(a)
        },
        _daylightSavingAdjust: function (e) {
            return e ? (e.setHours(e.getHours() > 12 ? e.getHours() + 2 : 0), e) : null
        },
        _setDate: function (e, t, i) {
            var n = !t,
                s = e.selectedMonth,
                r = e.selectedYear,
                a = this._restrictMinMax(e, this._determineDate(e, t, new Date));
            e.selectedDay = e.currentDay = a.getDate(), e.drawMonth = e.selectedMonth = e.currentMonth = a.getMonth(), e.drawYear = e.selectedYear = e.currentYear = a.getFullYear(), s === e.selectedMonth && r === e.selectedYear || i || this._notifyChange(e), this._adjustInstDate(e), e.input && e.input.val(n ? "" : this._formatDate(e))
        },
        _getDate: function (e) {
            var t = !e.currentYear || e.input && "" === e.input.val() ? null : this._daylightSavingAdjust(new Date(e.currentYear, e.currentMonth, e.currentDay));
            return t
        },
        _attachHandlers: function (t) {
            var i = this._get(t, "stepMonths"),
                n = "#" + t.id.replace(/\\\\/g, "\\");
            t.dpDiv.find("[data-handler]").map(function () {
                var t = {
                    prev: function () {
                        e.datepicker._adjustDate(n, -i, "M")
                    },
                    next: function () {
                        e.datepicker._adjustDate(n, +i, "M")
                    },
                    hide: function () {
                        e.datepicker._hideDatepicker()
                    },
                    today: function () {
                        e.datepicker._gotoToday(n)
                    },
                    selectDay: function () {
                        return e.datepicker._selectDay(n, +this.getAttribute("data-month"), +this.getAttribute("data-year"), this), !1
                    },
                    selectMonth: function () {
                        return e.datepicker._selectMonthYear(n, this, "M"), !1
                    },
                    selectYear: function () {
                        return e.datepicker._selectMonthYear(n, this, "Y"), !1
                    }
                };
                e(this).bind(this.getAttribute("data-event"), t[this.getAttribute("data-handler")])
            })
        },
        _generateHTML: function (e) {
            var t, i, n, s, r, a, o, l, u, h, f, c, d, p, g, m, v, b, y, _, w, x, k, C, D, T, S, I, M, P, N, E, A, H, z, W, O, j, L, F = new Date,
                R = this._daylightSavingAdjust(new Date(F.getFullYear(), F.getMonth(), F.getDate())),
                B = this._get(e, "isRTL"),
                q = this._get(e, "showButtonPanel"),
                Y = this._get(e, "hideIfNoPrevNext"),
                $ = this._get(e, "navigationAsDateFormat"),
                U = this._getNumberOfMonths(e),
                K = this._get(e, "showCurrentAtPos"),
                X = this._get(e, "stepMonths"),
                V = 1 !== U[0] || 1 !== U[1],
                Q = this._daylightSavingAdjust(e.currentDay ? new Date(e.currentYear, e.currentMonth, e.currentDay) : new Date(9999, 9, 9)),
                G = this._getMinMaxDate(e, "min"),
                J = this._getMinMaxDate(e, "max"),
                Z = e.drawMonth - K,
                et = e.drawYear;
            if (0 > Z && (Z += 12, et--), J)
                for (t = this._daylightSavingAdjust(new Date(J.getFullYear(), J.getMonth() - U[0] * U[1] + 1, J.getDate())), t = G && G > t ? G : t; this._daylightSavingAdjust(new Date(et, Z, 1)) > t;) Z--, 0 > Z && (Z = 11, et--);
            for (e.drawMonth = Z, e.drawYear = et, i = this._get(e, "prevText"), i = $ ? this.formatDate(i, this._daylightSavingAdjust(new Date(et, Z - X, 1)), this._getFormatConfig(e)) : i, n = this._canAdjustMonth(e, -1, et, Z) ? "<a class='ui-datepicker-prev ui-corner-all' data-handler='prev' data-event='click' title='" + i + "'><span class='ui-icon ui-icon-circle-triangle-" + (B ? "e" : "w") + "'>" + i + "</span></a>" : Y ? "" : "<a class='ui-datepicker-prev ui-corner-all ui-state-disabled' title='" + i + "'><span class='ui-icon ui-icon-circle-triangle-" + (B ? "e" : "w") + "'>" + i + "</span></a>", s = this._get(e, "nextText"), s = $ ? this.formatDate(s, this._daylightSavingAdjust(new Date(et, Z + X, 1)), this._getFormatConfig(e)) : s, r = this._canAdjustMonth(e, 1, et, Z) ? "<a class='ui-datepicker-next ui-corner-all' data-handler='next' data-event='click' title='" + s + "'><span class='ui-icon ui-icon-circle-triangle-" + (B ? "w" : "e") + "'>" + s + "</span></a>" : Y ? "" : "<a class='ui-datepicker-next ui-corner-all ui-state-disabled' title='" + s + "'><span class='ui-icon ui-icon-circle-triangle-" + (B ? "w" : "e") + "'>" + s + "</span></a>", a = this._get(e, "currentText"), o = this._get(e, "gotoCurrent") && e.currentDay ? Q : R, a = $ ? this.formatDate(a, o, this._getFormatConfig(e)) : a, l = e.inline ? "" : "<button type='button' class='ui-datepicker-close ui-state-default ui-priority-primary ui-corner-all' data-handler='hide' data-event='click'>" + this._get(e, "closeText") + "</button>", u = q ? "<div class='ui-datepicker-buttonpane ui-widget-content'>" + (B ? l : "") + (this._isInRange(e, o) ? "<button type='button' class='ui-datepicker-current ui-state-default ui-priority-secondary ui-corner-all' data-handler='today' data-event='click'>" + a + "</button>" : "") + (B ? "" : l) + "</div>" : "", h = parseInt(this._get(e, "firstDay"), 10), h = isNaN(h) ? 0 : h, f = this._get(e, "showWeek"), c = this._get(e, "dayNames"), d = this._get(e, "dayNamesMin"), p = this._get(e, "monthNames"), g = this._get(e, "monthNamesShort"), m = this._get(e, "beforeShowDay"), v = this._get(e, "showOtherMonths"), b = this._get(e, "selectOtherMonths"), y = this._getDefaultDate(e), _ = "", x = 0; x < U[0]; x++) {
                for (k = "", this.maxRows = 4, C = 0; C < U[1]; C++) {
                    if (D = this._daylightSavingAdjust(new Date(et, Z, e.selectedDay)), T = " ui-corner-all", S = "", V) {
                        if (S += "<div class='ui-datepicker-group", U[1] > 1) switch (C) {
                            case 0:
                                S += " ui-datepicker-group-first", T = " ui-corner-" + (B ? "right" : "left");
                                break;
                            case U[1] - 1:
                                S += " ui-datepicker-group-last", T = " ui-corner-" + (B ? "left" : "right");
                                break;
                            default:
                                S += " ui-datepicker-group-middle", T = ""
                        }
                        S += "'>"
                    }
                    for (S += "<div class='ui-datepicker-header ui-widget-header ui-helper-clearfix" + T + "'>" + (/all|left/.test(T) && 0 === x ? B ? r : n : "") + (/all|right/.test(T) && 0 === x ? B ? n : r : "") + this._generateMonthYearHeader(e, Z, et, G, J, x > 0 || C > 0, p, g) + "</div><table class='ui-datepicker-calendar'><thead><tr>", I = f ? "<th class='ui-datepicker-week-col'>" + this._get(e, "weekHeader") + "</th>" : "", w = 0; 7 > w; w++) M = (w + h) % 7, I += "<th" + ((w + h + 6) % 7 >= 5 ? " class='ui-datepicker-week-end'" : "") + "><span title='" + c[M] + "'>" + d[M] + "</span></th>";
                    for (S += I + "</tr></thead><tbody>", P = this._getDaysInMonth(et, Z), et === e.selectedYear && Z === e.selectedMonth && (e.selectedDay = Math.min(e.selectedDay, P)), N = (this._getFirstDayOfMonth(et, Z) - h + 7) % 7, E = Math.ceil((N + P) / 7), A = V && this.maxRows > E ? this.maxRows : E, this.maxRows = A, H = this._daylightSavingAdjust(new Date(et, Z, 1 - N)), z = 0; A > z; z++) {
                        for (S += "<tr>", W = f ? "<td class='ui-datepicker-week-col'>" + this._get(e, "calculateWeek")(H) + "</td>" : "", w = 0; 7 > w; w++) O = m ? m.apply(e.input ? e.input[0] : null, [H]) : [!0, ""], j = H.getMonth() !== Z, L = j && !b || !O[0] || G && G > H || J && H > J, W += "<td class='" + ((w + h + 6) % 7 >= 5 ? " ui-datepicker-week-end" : "") + (j ? " ui-datepicker-other-month" : "") + (H.getTime() === D.getTime() && Z === e.selectedMonth && e._keyEvent || y.getTime() === H.getTime() && y.getTime() === D.getTime() ? " " + this._dayOverClass : "") + (L ? " " + this._unselectableClass + " ui-state-disabled" : "") + (j && !v ? "" : " " + O[1] + (H.getTime() === Q.getTime() ? " " + this._currentClass : "") + (H.getTime() === R.getTime() ? " ui-datepicker-today" : "")) + "'" + (j && !v || !O[2] ? "" : " title='" + O[2].replace(/'/g, "&#39;") + "'") + (L ? "" : " data-handler='selectDay' data-event='click' data-month='" + H.getMonth() + "' data-year='" + H.getFullYear() + "'") + ">" + (j && !v ? "&#xa0;" : L ? "<span class='ui-state-default'>" + H.getDate() + "</span>" : "<a class='ui-state-default" + (H.getTime() === R.getTime() ? " ui-state-highlight" : "") + (H.getTime() === Q.getTime() ? " ui-state-active" : "") + (j ? " ui-priority-secondary" : "") + "' href='#'>" + H.getDate() + "</a>") + "</td>", H.setDate(H.getDate() + 1), H = this._daylightSavingAdjust(H);
                        S += W + "</tr>"
                    }
                    Z++, Z > 11 && (Z = 0, et++), S += "</tbody></table>" + (V ? "</div>" + (U[0] > 0 && C === U[1] - 1 ? "<div class='ui-datepicker-row-break'></div>" : "") : ""), k += S
                }
                _ += k
            }
            return _ += u, e._keyEvent = !1, _
        },
        _generateMonthYearHeader: function (e, t, i, n, s, r, a, o) {
            var l, u, h, f, c, d, p, g, m = this._get(e, "changeMonth"),
                v = this._get(e, "changeYear"),
                b = this._get(e, "showMonthAfterYear"),
                y = "<div class='ui-datepicker-title'>",
                _ = "";
            if (r || !m) _ += "<span class='ui-datepicker-month'>" + a[t] + "</span>";
            else {
                for (l = n && n.getFullYear() === i, u = s && s.getFullYear() === i, _ += "<select class='ui-datepicker-month' data-handler='selectMonth' data-event='change'>", h = 0; 12 > h; h++)(!l || h >= n.getMonth()) && (!u || h <= s.getMonth()) && (_ += "<option value='" + h + "'" + (h === t ? " selected='selected'" : "") + ">" + o[h] + "</option>");
                _ += "</select>"
            }
            if (b || (y += _ + (!r && m && v ? "" : "&#xa0;")), !e.yearshtml)
                if (e.yearshtml = "", r || !v) y += "<span class='ui-datepicker-year'>" + i + "</span>";
                else {
                    for (f = this._get(e, "yearRange").split(":"), c = (new Date).getFullYear(), d = function (e) {
                            var t = e.match(/c[+\-].*/) ? i + parseInt(e.substring(1), 10) : e.match(/[+\-].*/) ? c + parseInt(e, 10) : parseInt(e, 10);
                            return isNaN(t) ? c : t
                        }, p = d(f[0]), g = Math.max(p, d(f[1] || "")), p = n ? Math.max(p, n.getFullYear()) : p, g = s ? Math.min(g, s.getFullYear()) : g, e.yearshtml += "<select class='ui-datepicker-year' data-handler='selectYear' data-event='change'>"; g >= p; p++) e.yearshtml += "<option value='" + p + "'" + (p === i ? " selected='selected'" : "") + ">" + p + "</option>";
                    e.yearshtml += "</select>", y += e.yearshtml, e.yearshtml = null
                }
            return y += this._get(e, "yearSuffix"), b && (y += (!r && m && v ? "" : "&#xa0;") + _), y += "</div>"
        },
        _adjustInstDate: function (e, t, i) {
            var n = e.drawYear + ("Y" === i ? t : 0),
                s = e.drawMonth + ("M" === i ? t : 0),
                r = Math.min(e.selectedDay, this._getDaysInMonth(n, s)) + ("D" === i ? t : 0),
                a = this._restrictMinMax(e, this._daylightSavingAdjust(new Date(n, s, r)));
            e.selectedDay = a.getDate(), e.drawMonth = e.selectedMonth = a.getMonth(), e.drawYear = e.selectedYear = a.getFullYear(), ("M" === i || "Y" === i) && this._notifyChange(e)
        },
        _restrictMinMax: function (e, t) {
            var i = this._getMinMaxDate(e, "min"),
                n = this._getMinMaxDate(e, "max"),
                s = i && i > t ? i : t;
            return n && s > n ? n : s
        },
        _notifyChange: function (e) {
            var t = this._get(e, "onChangeMonthYear");
            t && t.apply(e.input ? e.input[0] : null, [e.selectedYear, e.selectedMonth + 1, e])
        },
        _getNumberOfMonths: function (e) {
            var t = this._get(e, "numberOfMonths");
            return null == t ? [1, 1] : "number" == typeof t ? [1, t] : t
        },
        _getMinMaxDate: function (e, t) {
            return this._determineDate(e, this._get(e, t + "Date"), null)
        },
        _getDaysInMonth: function (e, t) {
            return 32 - this._daylightSavingAdjust(new Date(e, t, 32)).getDate()
        },
        _getFirstDayOfMonth: function (e, t) {
            return new Date(e, t, 1).getDay()
        },
        _canAdjustMonth: function (e, t, i, n) {
            var s = this._getNumberOfMonths(e),
                r = this._daylightSavingAdjust(new Date(i, n + (0 > t ? t : s[0] * s[1]), 1));
            return 0 > t && r.setDate(this._getDaysInMonth(r.getFullYear(), r.getMonth())), this._isInRange(e, r)
        },
        _isInRange: function (e, t) {
            var i, n, s = this._getMinMaxDate(e, "min"),
                r = this._getMinMaxDate(e, "max"),
                a = null,
                o = null,
                l = this._get(e, "yearRange");
            return l && (i = l.split(":"), n = (new Date).getFullYear(), a = parseInt(i[0], 10), o = parseInt(i[1], 10), i[0].match(/[+\-].*/) && (a += n), i[1].match(/[+\-].*/) && (o += n)), (!s || t.getTime() >= s.getTime()) && (!r || t.getTime() <= r.getTime()) && (!a || t.getFullYear() >= a) && (!o || t.getFullYear() <= o)
        },
        _getFormatConfig: function (e) {
            var t = this._get(e, "shortYearCutoff");
            return t = "string" != typeof t ? t : (new Date).getFullYear() % 100 + parseInt(t, 10), {
                shortYearCutoff: t,
                dayNamesShort: this._get(e, "dayNamesShort"),
                dayNames: this._get(e, "dayNames"),
                monthNamesShort: this._get(e, "monthNamesShort"),
                monthNames: this._get(e, "monthNames")
            }
        },
        _formatDate: function (e, t, i, n) {
            t || (e.currentDay = e.selectedDay, e.currentMonth = e.selectedMonth, e.currentYear = e.selectedYear);
            var s = t ? "object" == typeof t ? t : this._daylightSavingAdjust(new Date(n, i, t)) : this._daylightSavingAdjust(new Date(e.currentYear, e.currentMonth, e.currentDay));
            return this.formatDate(this._get(e, "dateFormat"), s, this._getFormatConfig(e))
        }
    }), e.fn.datepicker = function (t) {
        if (!this.length) return this;
        e.datepicker.initialized || (e(document).mousedown(e.datepicker._checkExternalClick), e.datepicker.initialized = !0), 0 === e("#" + e.datepicker._mainDivId).length && e("body").append(e.datepicker.dpDiv);
        var i = Array.prototype.slice.call(arguments, 1);
        return "string" != typeof t || "isDisabled" !== t && "getDate" !== t && "widget" !== t ? "option" === t && 2 === arguments.length && "string" == typeof arguments[1] ? e.datepicker["_" + t + "Datepicker"].apply(e.datepicker, [this[0]].concat(i)) : this.each(function () {
            "string" == typeof t ? e.datepicker["_" + t + "Datepicker"].apply(e.datepicker, [this].concat(i)) : e.datepicker._attachDatepicker(this, t)
        }) : e.datepicker["_" + t + "Datepicker"].apply(e.datepicker, [this[0]].concat(i))
    }, e.datepicker = new s, e.datepicker.initialized = !1, e.datepicker.uuid = (new Date).getTime(), e.datepicker.version = "1.10.4"
}(jQuery),
function (e) {
    var i = {
            buttons: !0,
            height: !0,
            maxHeight: !0,
            maxWidth: !0,
            minHeight: !0,
            minWidth: !0,
            width: !0
        },
        n = {
            maxHeight: !0,
            maxWidth: !0,
            minHeight: !0,
            minWidth: !0
        };
    e.widget("ui.dialog", {
        version: "1.10.4",
        options: {
            appendTo: "body",
            autoOpen: !0,
            buttons: [],
            closeOnEscape: !0,
            closeText: "close",
            dialogClass: "",
            draggable: !0,
            hide: null,
            height: "auto",
            maxHeight: null,
            maxWidth: null,
            minHeight: 150,
            minWidth: 150,
            modal: !1,
            position: {
                my: "center",
                at: "center",
                of: window,
                collision: "fit",
                using: function (t) {
                    var i = e(this).css(t).offset().top;
                    0 > i && e(this).css("top", t.top - i)
                }
            },
            resizable: !0,
            show: null,
            title: null,
            width: 300,
            beforeClose: null,
            close: null,
            drag: null,
            dragStart: null,
            dragStop: null,
            focus: null,
            open: null,
            resize: null,
            resizeStart: null,
            resizeStop: null
        },
        _create: function () {
            this.originalCss = {
                display: this.element[0].style.display,
                width: this.element[0].style.width,
                minHeight: this.element[0].style.minHeight,
                maxHeight: this.element[0].style.maxHeight,
                height: this.element[0].style.height
            }, this.originalPosition = {
                parent: this.element.parent(),
                index: this.element.parent().children().index(this.element)
            }, this.originalTitle = this.element.attr("title"), this.options.title = this.options.title || this.originalTitle, this._createWrapper(), this.element.show().removeAttr("title").addClass("ui-dialog-content ui-widget-content").appendTo(this.uiDialog), this._createTitlebar(), this._createButtonPane(), this.options.draggable && e.fn.draggable && this._makeDraggable(), this.options.resizable && e.fn.resizable && this._makeResizable(), this._isOpen = !1
        },
        _init: function () {
            this.options.autoOpen && this.open()
        },
        _appendTo: function () {
            var t = this.options.appendTo;
            return t && (t.jquery || t.nodeType) ? e(t) : this.document.find(t || "body").eq(0)
        },
        _destroy: function () {
            var e, t = this.originalPosition;
            this._destroyOverlay(), this.element.removeUniqueId().removeClass("ui-dialog-content ui-widget-content").css(this.originalCss).detach(), this.uiDialog.stop(!0, !0).remove(), this.originalTitle && this.element.attr("title", this.originalTitle), e = t.parent.children().eq(t.index), e.length && e[0] !== this.element[0] ? e.before(this.element) : t.parent.append(this.element)
        },
        widget: function () {
            return this.uiDialog
        },
        disable: e.noop,
        enable: e.noop,
        close: function (t) {
            var i, n = this;
            if (this._isOpen && this._trigger("beforeClose", t) !== !1) {
                if (this._isOpen = !1, this._destroyOverlay(), !this.opener.filter(":focusable").focus().length) try {
                    i = this.document[0].activeElement, i && "body" !== i.nodeName.toLowerCase() && e(i).blur()
                } catch (s) {}
                this._hide(this.uiDialog, this.options.hide, function () {
                    n._trigger("close", t)
                })
            }
        },
        isOpen: function () {
            return this._isOpen
        },
        moveToTop: function () {
            this._moveToTop()
        },
        _moveToTop: function (e, t) {
            var i = !!this.uiDialog.nextAll(":visible").insertBefore(this.uiDialog).length;
            return i && !t && this._trigger("focus", e), i
        },
        open: function () {
            var t = this;
            return this._isOpen ? void(this._moveToTop() && this._focusTabbable()) : (this._isOpen = !0, this.opener = e(this.document[0].activeElement), this._size(), this._position(), this._createOverlay(), this._moveToTop(null, !0), this._show(this.uiDialog, this.options.show, function () {
                t._focusTabbable(), t._trigger("focus")
            }), void this._trigger("open"))
        },
        _focusTabbable: function () {
            var e = this.element.find("[autofocus]");
            e.length || (e = this.element.find(":tabbable")), e.length || (e = this.uiDialogButtonPane.find(":tabbable")), e.length || (e = this.uiDialogTitlebarClose.filter(":tabbable")), e.length || (e = this.uiDialog), e.eq(0).focus()
        },
        _keepFocus: function (t) {
            function i() {
                var t = this.document[0].activeElement,
                    i = this.uiDialog[0] === t || e.contains(this.uiDialog[0], t);
                i || this._focusTabbable()
            }
            t.preventDefault(), i.call(this), this._delay(i)
        },
        _createWrapper: function () {
            this.uiDialog = e("<div>").addClass("ui-dialog ui-widget ui-widget-content ui-corner-all ui-front " + this.options.dialogClass).hide().attr({
                tabIndex: -1,
                role: "dialog"
            }).appendTo(this._appendTo()), this._on(this.uiDialog, {
                keydown: function (t) {
                    if (this.options.closeOnEscape && !t.isDefaultPrevented() && t.keyCode && t.keyCode === e.ui.keyCode.ESCAPE) return t.preventDefault(), void this.close(t);
                    if (t.keyCode === e.ui.keyCode.TAB) {
                        var i = this.uiDialog.find(":tabbable"),
                            n = i.filter(":first"),
                            s = i.filter(":last");
                        t.target !== s[0] && t.target !== this.uiDialog[0] || t.shiftKey ? t.target !== n[0] && t.target !== this.uiDialog[0] || !t.shiftKey || (s.focus(1), t.preventDefault()) : (n.focus(1), t.preventDefault())
                    }
                },
                mousedown: function (e) {
                    this._moveToTop(e) && this._focusTabbable()
                }
            }), this.element.find("[aria-describedby]").length || this.uiDialog.attr({
                "aria-describedby": this.element.uniqueId().attr("id")
            })
        },
        _createTitlebar: function () {
            var t;
            this.uiDialogTitlebar = e("<div>").addClass("ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix").prependTo(this.uiDialog), this._on(this.uiDialogTitlebar, {
                mousedown: function (t) {
                    e(t.target).closest(".ui-dialog-titlebar-close") || this.uiDialog.focus()
                }
            }), this.uiDialogTitlebarClose = e("<button type='button'></button>").button({
                label: this.options.closeText,
                icons: {
                    primary: "ui-icon-closethick"
                },
                text: !1
            }).addClass("ui-dialog-titlebar-close").appendTo(this.uiDialogTitlebar), this._on(this.uiDialogTitlebarClose, {
                click: function (e) {
                    e.preventDefault(), this.close(e)
                }
            }), t = e("<span>").uniqueId().addClass("ui-dialog-title").prependTo(this.uiDialogTitlebar), this._title(t), this.uiDialog.attr({
                "aria-labelledby": t.attr("id")
            })
        },
        _title: function (e) {
            this.options.title || e.html("&#160;"), e.text(this.options.title)
        },
        _createButtonPane: function () {
            this.uiDialogButtonPane = e("<div>").addClass("ui-dialog-buttonpane ui-widget-content ui-helper-clearfix"), this.uiButtonSet = e("<div>").addClass("ui-dialog-buttonset").appendTo(this.uiDialogButtonPane), this._createButtons()
        },
        _createButtons: function () {
            var t = this,
                i = this.options.buttons;
            return this.uiDialogButtonPane.remove(), this.uiButtonSet.empty(), e.isEmptyObject(i) || e.isArray(i) && !i.length ? void this.uiDialog.removeClass("ui-dialog-buttons") : (e.each(i, function (i, n) {
                var s, r;
                n = e.isFunction(n) ? {
                    click: n,
                    text: i
                } : n, n = e.extend({
                    type: "button"
                }, n), s = n.click, n.click = function () {
                    s.apply(t.element[0], arguments)
                }, r = {
                    icons: n.icons,
                    text: n.showText
                }, delete n.icons, delete n.showText, e("<button></button>", n).button(r).appendTo(t.uiButtonSet)
            }), this.uiDialog.addClass("ui-dialog-buttons"), void this.uiDialogButtonPane.appendTo(this.uiDialog))
        },
        _makeDraggable: function () {
            function n(e) {
                return {
                    position: e.position,
                    offset: e.offset
                }
            }
            var t = this,
                i = this.options;
            this.uiDialog.draggable({
                cancel: ".ui-dialog-content, .ui-dialog-titlebar-close",
                handle: ".ui-dialog-titlebar",
                containment: "document",
                start: function (i, s) {
                    e(this).addClass("ui-dialog-dragging"), t._blockFrames(), t._trigger("dragStart", i, n(s))
                },
                drag: function (e, i) {
                    t._trigger("drag", e, n(i))
                },
                stop: function (s, r) {
                    i.position = [r.position.left - t.document.scrollLeft(), r.position.top - t.document.scrollTop()], e(this).removeClass("ui-dialog-dragging"), t._unblockFrames(), t._trigger("dragStop", s, n(r))
                }
            })
        },
        _makeResizable: function () {
            function a(e) {
                return {
                    originalPosition: e.originalPosition,
                    originalSize: e.originalSize,
                    position: e.position,
                    size: e.size
                }
            }
            var t = this,
                i = this.options,
                n = i.resizable,
                s = this.uiDialog.css("position"),
                r = "string" == typeof n ? n : "n,e,s,w,se,sw,ne,nw";
            this.uiDialog.resizable({
                cancel: ".ui-dialog-content",
                containment: "document",
                alsoResize: this.element,
                maxWidth: i.maxWidth,
                maxHeight: i.maxHeight,
                minWidth: i.minWidth,
                minHeight: this._minHeight(),
                handles: r,
                start: function (i, n) {
                    e(this).addClass("ui-dialog-resizing"), t._blockFrames(), t._trigger("resizeStart", i, a(n))
                },
                resize: function (e, i) {
                    t._trigger("resize", e, a(i))
                },
                stop: function (n, s) {
                    i.height = e(this).height(), i.width = e(this).width(), e(this).removeClass("ui-dialog-resizing"), t._unblockFrames(), t._trigger("resizeStop", n, a(s))
                }
            }).css("position", s)
        },
        _minHeight: function () {
            var e = this.options;
            return "auto" === e.height ? e.minHeight : Math.min(e.minHeight, e.height)
        },
        _position: function () {
            var e = this.uiDialog.is(":visible");
            e || this.uiDialog.show(), this.uiDialog.position(this.options.position), e || this.uiDialog.hide()
        },
        _setOptions: function (t) {
            var s = this,
                r = !1,
                a = {};
            e.each(t, function (e, t) {
                s._setOption(e, t), e in i && (r = !0), e in n && (a[e] = t)
            }), r && (this._size(), this._position()), this.uiDialog.is(":data(ui-resizable)") && this.uiDialog.resizable("option", a)
        },
        _setOption: function (e, t) {
            var i, n, s = this.uiDialog;
            "dialogClass" === e && s.removeClass(this.options.dialogClass).addClass(t), "disabled" !== e && (this._super(e, t), "appendTo" === e && this.uiDialog.appendTo(this._appendTo()), "buttons" === e && this._createButtons(), "closeText" === e && this.uiDialogTitlebarClose.button({
                label: "" + t
            }), "draggable" === e && (i = s.is(":data(ui-draggable)"), i && !t && s.draggable("destroy"), !i && t && this._makeDraggable()), "position" === e && this._position(), "resizable" === e && (n = s.is(":data(ui-resizable)"), n && !t && s.resizable("destroy"), n && "string" == typeof t && s.resizable("option", "handles", t), n || t === !1 || this._makeResizable()), "title" === e && this._title(this.uiDialogTitlebar.find(".ui-dialog-title")))
        },
        _size: function () {
            var e, t, i, n = this.options;
            this.element.show().css({
                width: "auto",
                minHeight: 0,
                maxHeight: "none",
                height: 0
            }), n.minWidth > n.width && (n.width = n.minWidth), e = this.uiDialog.css({
                height: "auto",
                width: n.width
            }).outerHeight(), t = Math.max(0, n.minHeight - e), i = "number" == typeof n.maxHeight ? Math.max(0, n.maxHeight - e) : "none", "auto" === n.height ? this.element.css({
                minHeight: t,
                maxHeight: i,
                height: "auto"
            }) : this.element.height(Math.max(0, n.height - e)), this.uiDialog.is(":data(ui-resizable)") && this.uiDialog.resizable("option", "minHeight", this._minHeight())
        },
        _blockFrames: function () {
            this.iframeBlocks = this.document.find("iframe").map(function () {
                var t = e(this);
                return e("<div>").css({
                    position: "absolute",
                    width: t.outerWidth(),
                    height: t.outerHeight()
                }).appendTo(t.parent()).offset(t.offset())[0]
            })
        },
        _unblockFrames: function () {
            this.iframeBlocks && (this.iframeBlocks.remove(), delete this.iframeBlocks)
        },
        _allowInteraction: function (t) {
            return e(t.target).closest(".ui-dialog").length ? !0 : !!e(t.target).closest(".ui-datepicker").length
        },
        _createOverlay: function () {
            if (this.options.modal) {
                var t = this,
                    i = this.widgetFullName;
                e.ui.dialog.overlayInstances || this._delay(function () {
                    e.ui.dialog.overlayInstances && this.document.bind("focusin.dialog", function (n) {
                        t._allowInteraction(n) || (n.preventDefault(), e(".ui-dialog:visible:last .ui-dialog-content").data(i)._focusTabbable())
                    })
                }), this.overlay = e("<div>").addClass("ui-widget-overlay ui-front").appendTo(this._appendTo()), this._on(this.overlay, {
                    mousedown: "_keepFocus"
                }), e.ui.dialog.overlayInstances++
            }
        },
        _destroyOverlay: function () {
            this.options.modal && this.overlay && (e.ui.dialog.overlayInstances--, e.ui.dialog.overlayInstances || this.document.unbind("focusin.dialog"), this.overlay.remove(), this.overlay = null)
        }
    }), e.ui.dialog.overlayInstances = 0, e.uiBackCompat !== !1 && e.widget("ui.dialog", e.ui.dialog, {
        _position: function () {
            var s, t = this.options.position,
                i = [],
                n = [0, 0];
            t ? (("string" == typeof t || "object" == typeof t && "0" in t) && (i = t.split ? t.split(" ") : [t[0], t[1]], 1 === i.length && (i[1] = i[0]), e.each(["left", "top"], function (e, t) {
                +i[e] === i[e] && (n[e] = i[e], i[e] = t)
            }), t = {
                my: i[0] + (n[0] < 0 ? n[0] : "+" + n[0]) + " " + i[1] + (n[1] < 0 ? n[1] : "+" + n[1]),
                at: i.join(" ")
            }), t = e.extend({}, e.ui.dialog.prototype.options.position, t)) : t = e.ui.dialog.prototype.options.position, s = this.uiDialog.is(":visible"), s || this.uiDialog.show(), this.uiDialog.position(t), s || this.uiDialog.hide()
        }
    })
}(jQuery),
function (e) {
    var i = /up|down|vertical/,
        n = /up|left|vertical|horizontal/;
    e.effects.effect.blind = function (t, s) {
        var g, m, v, r = e(this),
            a = ["position", "top", "bottom", "left", "right", "height", "width"],
            o = e.effects.setMode(r, t.mode || "hide"),
            l = t.direction || "up",
            u = i.test(l),
            h = u ? "height" : "width",
            f = u ? "top" : "left",
            c = n.test(l),
            d = {},
            p = "show" === o;
        r.parent().is(".ui-effects-wrapper") ? e.effects.save(r.parent(), a) : e.effects.save(r, a), r.show(), g = e.effects.createWrapper(r).css({
            overflow: "hidden"
        }), m = g[h](), v = parseFloat(g.css(f)) || 0, d[h] = p ? m : 0, c || (r.css(u ? "bottom" : "right", 0).css(u ? "top" : "left", "auto").css({
            position: "absolute"
        }), d[f] = p ? v : m + v), p && (g.css(h, 0), c || g.css(f, v + m)), g.animate(d, {
            duration: t.duration,
            easing: t.easing,
            queue: !1,
            complete: function () {
                "hide" === o && r.hide(), e.effects.restore(r, a), e.effects.removeWrapper(r), s()
            }
        })
    }
}(jQuery),
function (e) {
    e.effects.effect.bounce = function (t, i) {
        var m, v, b, n = e(this),
            s = ["position", "top", "bottom", "left", "right", "height", "width"],
            r = e.effects.setMode(n, t.mode || "effect"),
            a = "hide" === r,
            o = "show" === r,
            l = t.direction || "up",
            u = t.distance,
            h = t.times || 5,
            f = 2 * h + (o || a ? 1 : 0),
            c = t.duration / f,
            d = t.easing,
            p = "up" === l || "down" === l ? "top" : "left",
            g = "up" === l || "left" === l,
            y = n.queue(),
            _ = y.length;
        for ((o || a) && s.push("opacity"), e.effects.save(n, s), n.show(), e.effects.createWrapper(n), u || (u = n["top" === p ? "outerHeight" : "outerWidth"]() / 3), o && (b = {
                opacity: 1
            }, b[p] = 0, n.css("opacity", 0).css(p, g ? 2 * -u : 2 * u).animate(b, c, d)), a && (u /= Math.pow(2, h - 1)), b = {}, b[p] = 0, m = 0; h > m; m++) v = {}, v[p] = (g ? "-=" : "+=") + u, n.animate(v, c, d).animate(b, c, d), u = a ? 2 * u : u / 2;
        a && (v = {
            opacity: 0
        }, v[p] = (g ? "-=" : "+=") + u, n.animate(v, c, d)), n.queue(function () {
            a && n.hide(), e.effects.restore(n, s), e.effects.removeWrapper(n), i()
        }), _ > 1 && y.splice.apply(y, [1, 0].concat(y.splice(_, f + 1))), n.dequeue()
    }
}(jQuery),
function (e) {
    e.effects.effect.clip = function (t, i) {
        var c, d, p, n = e(this),
            s = ["position", "top", "bottom", "left", "right", "height", "width"],
            r = e.effects.setMode(n, t.mode || "hide"),
            a = "show" === r,
            o = t.direction || "vertical",
            l = "vertical" === o,
            u = l ? "height" : "width",
            h = l ? "top" : "left",
            f = {};
        e.effects.save(n, s), n.show(), c = e.effects.createWrapper(n).css({
            overflow: "hidden"
        }), d = "IMG" === n[0].tagName ? c : n, p = d[u](), a && (d.css(u, 0), d.css(h, p / 2)), f[u] = a ? p : 0, f[h] = a ? 0 : p / 2, d.animate(f, {
            queue: !1,
            duration: t.duration,
            easing: t.easing,
            complete: function () {
                a || n.hide(), e.effects.restore(n, s), e.effects.removeWrapper(n), i()
            }
        })
    }
}(jQuery),
function (e) {
    e.effects.effect.drop = function (t, i) {
        var f, n = e(this),
            s = ["position", "top", "bottom", "left", "right", "opacity", "height", "width"],
            r = e.effects.setMode(n, t.mode || "hide"),
            a = "show" === r,
            o = t.direction || "left",
            l = "up" === o || "down" === o ? "top" : "left",
            u = "up" === o || "left" === o ? "pos" : "neg",
            h = {
                opacity: a ? 1 : 0
            };
        e.effects.save(n, s), n.show(), e.effects.createWrapper(n), f = t.distance || n["top" === l ? "outerHeight" : "outerWidth"](!0) / 2, a && n.css("opacity", 0).css(l, "pos" === u ? -f : f), h[l] = (a ? "pos" === u ? "+=" : "-=" : "pos" === u ? "-=" : "+=") + f, n.animate(h, {
            queue: !1,
            duration: t.duration,
            easing: t.easing,
            complete: function () {
                "hide" === r && n.hide(), e.effects.restore(n, s), e.effects.removeWrapper(n), i()
            }
        })
    }
}(jQuery),
function (e) {
    e.effects.effect.explode = function (t, i) {
        function b() {
            f.push(this), f.length === n * s && y()
        }

        function y() {
            r.css({
                visibility: "visible"
            }), e(f).remove(), o || r.hide(), i()
        }
        var c, d, p, g, m, v, n = t.pieces ? Math.round(Math.sqrt(t.pieces)) : 3,
            s = n,
            r = e(this),
            a = e.effects.setMode(r, t.mode || "hide"),
            o = "show" === a,
            l = r.show().css("visibility", "hidden").offset(),
            u = Math.ceil(r.outerWidth() / s),
            h = Math.ceil(r.outerHeight() / n),
            f = [];
        for (c = 0; n > c; c++)
            for (g = l.top + c * h, v = c - (n - 1) / 2, d = 0; s > d; d++) p = l.left + d * u, m = d - (s - 1) / 2, r.clone().appendTo("body").wrap("<div></div>").css({
                position: "absolute",
                visibility: "visible",
                left: -d * u,
                top: -c * h
            }).parent().addClass("ui-effects-explode").css({
                position: "absolute",
                overflow: "hidden",
                width: u,
                height: h,
                left: p + (o ? m * u : 0),
                top: g + (o ? v * h : 0),
                opacity: o ? 0 : 1
            }).animate({
                left: p + (o ? 0 : m * u),
                top: g + (o ? 0 : v * h),
                opacity: o ? 1 : 0
            }, t.duration || 500, t.easing, b)
    }
}(jQuery),
function (e) {
    e.effects.effect.fade = function (t, i) {
        var n = e(this),
            s = e.effects.setMode(n, t.mode || "toggle");
        n.animate({
            opacity: s
        }, {
            queue: !1,
            duration: t.duration,
            easing: t.easing,
            complete: i
        })
    }
}(jQuery),
function (e) {
    e.effects.effect.fold = function (t, i) {
        var p, g, n = e(this),
            s = ["position", "top", "bottom", "left", "right", "height", "width"],
            r = e.effects.setMode(n, t.mode || "hide"),
            a = "show" === r,
            o = "hide" === r,
            l = t.size || 15,
            u = /([0-9]+)%/.exec(l),
            h = !!t.horizFirst,
            f = a !== h,
            c = f ? ["width", "height"] : ["height", "width"],
            d = t.duration / 2,
            m = {},
            v = {};
        e.effects.save(n, s), n.show(), p = e.effects.createWrapper(n).css({
            overflow: "hidden"
        }), g = f ? [p.width(), p.height()] : [p.height(), p.width()], u && (l = parseInt(u[1], 10) / 100 * g[o ? 0 : 1]), a && p.css(h ? {
            height: 0,
            width: l
        } : {
            height: l,
            width: 0
        }), m[c[0]] = a ? g[0] : l, v[c[1]] = a ? g[1] : 0, p.animate(m, d, t.easing).animate(v, d, t.easing, function () {
            o && n.hide(), e.effects.restore(n, s), e.effects.removeWrapper(n), i()
        })
    }
}(jQuery),
function (e) {
    e.effects.effect.highlight = function (t, i) {
        var n = e(this),
            s = ["backgroundImage", "backgroundColor", "opacity"],
            r = e.effects.setMode(n, t.mode || "show"),
            a = {
                backgroundColor: n.css("backgroundColor")
            };
        "hide" === r && (a.opacity = 0), e.effects.save(n, s), n.show().css({
            backgroundImage: "none",
            backgroundColor: t.color || "#ffff99"
        }).animate(a, {
            queue: !1,
            duration: t.duration,
            easing: t.easing,
            complete: function () {
                "hide" === r && n.hide(), e.effects.restore(n, s), i()
            }
        })
    }
}(jQuery),
function (e) {
    e.effects.effect.pulsate = function (t, i) {
        var d, n = e(this),
            s = e.effects.setMode(n, t.mode || "show"),
            r = "show" === s,
            a = "hide" === s,
            o = r || "hide" === s,
            l = 2 * (t.times || 5) + (o ? 1 : 0),
            u = t.duration / l,
            h = 0,
            f = n.queue(),
            c = f.length;
        for ((r || !n.is(":visible")) && (n.css("opacity", 0).show(), h = 1), d = 1; l > d; d++) n.animate({
            opacity: h
        }, u, t.easing), h = 1 - h;
        n.animate({
            opacity: h
        }, u, t.easing), n.queue(function () {
            a && n.hide(), i()
        }), c > 1 && f.splice.apply(f, [1, 0].concat(f.splice(c, l + 1))), n.dequeue()
    }
}(jQuery),
function (e) {
    e.effects.effect.puff = function (t, i) {
        var n = e(this),
            s = e.effects.setMode(n, t.mode || "hide"),
            r = "hide" === s,
            a = parseInt(t.percent, 10) || 150,
            o = a / 100,
            l = {
                height: n.height(),
                width: n.width(),
                outerHeight: n.outerHeight(),
                outerWidth: n.outerWidth()
            };
        e.extend(t, {
            effect: "scale",
            queue: !1,
            fade: !0,
            mode: s,
            complete: i,
            percent: r ? a : 100,
            from: r ? l : {
                height: l.height * o,
                width: l.width * o,
                outerHeight: l.outerHeight * o,
                outerWidth: l.outerWidth * o
            }
        }), n.effect(t)
    }, e.effects.effect.scale = function (t, i) {
        var n = e(this),
            s = e.extend(!0, {}, t),
            r = e.effects.setMode(n, t.mode || "effect"),
            a = parseInt(t.percent, 10) || (0 === parseInt(t.percent, 10) ? 0 : "hide" === r ? 0 : 100),
            o = t.direction || "both",
            l = t.origin,
            u = {
                height: n.height(),
                width: n.width(),
                outerHeight: n.outerHeight(),
                outerWidth: n.outerWidth()
            },
            h = {
                y: "horizontal" !== o ? a / 100 : 1,
                x: "vertical" !== o ? a / 100 : 1
            };
        s.effect = "size", s.queue = !1, s.complete = i, "effect" !== r && (s.origin = l || ["middle", "center"], s.restore = !0), s.from = t.from || ("show" === r ? {
            height: 0,
            width: 0,
            outerHeight: 0,
            outerWidth: 0
        } : u), s.to = {
            height: u.height * h.y,
            width: u.width * h.x,
            outerHeight: u.outerHeight * h.y,
            outerWidth: u.outerWidth * h.x
        }, s.fade && ("show" === r && (s.from.opacity = 0, s.to.opacity = 1), "hide" === r && (s.from.opacity = 1, s.to.opacity = 0)), n.effect(s)
    }, e.effects.effect.size = function (t, i) {
        var n, s, r, a = e(this),
            o = ["position", "top", "bottom", "left", "right", "width", "height", "overflow", "opacity"],
            l = ["position", "top", "bottom", "left", "right", "overflow", "opacity"],
            u = ["width", "height", "overflow"],
            h = ["fontSize"],
            f = ["borderTopWidth", "borderBottomWidth", "paddingTop", "paddingBottom"],
            c = ["borderLeftWidth", "borderRightWidth", "paddingLeft", "paddingRight"],
            d = e.effects.setMode(a, t.mode || "effect"),
            p = t.restore || "effect" !== d,
            g = t.scale || "both",
            m = t.origin || ["middle", "center"],
            v = a.css("position"),
            b = p ? o : l,
            y = {
                height: 0,
                width: 0,
                outerHeight: 0,
                outerWidth: 0
            };
        "show" === d && a.show(), n = {
            height: a.height(),
            width: a.width(),
            outerHeight: a.outerHeight(),
            outerWidth: a.outerWidth()
        }, "toggle" === t.mode && "show" === d ? (a.from = t.to || y, a.to = t.from || n) : (a.from = t.from || ("show" === d ? y : n), a.to = t.to || ("hide" === d ? y : n)), r = {
            from: {
                y: a.from.height / n.height,
                x: a.from.width / n.width
            },
            to: {
                y: a.to.height / n.height,
                x: a.to.width / n.width
            }
        }, ("box" === g || "both" === g) && (r.from.y !== r.to.y && (b = b.concat(f), a.from = e.effects.setTransition(a, f, r.from.y, a.from), a.to = e.effects.setTransition(a, f, r.to.y, a.to)), r.from.x !== r.to.x && (b = b.concat(c), a.from = e.effects.setTransition(a, c, r.from.x, a.from), a.to = e.effects.setTransition(a, c, r.to.x, a.to))), ("content" === g || "both" === g) && r.from.y !== r.to.y && (b = b.concat(h).concat(u), a.from = e.effects.setTransition(a, h, r.from.y, a.from), a.to = e.effects.setTransition(a, h, r.to.y, a.to)), e.effects.save(a, b), a.show(), e.effects.createWrapper(a), a.css("overflow", "hidden").css(a.from), m && (s = e.effects.getBaseline(m, n), a.from.top = (n.outerHeight - a.outerHeight()) * s.y, a.from.left = (n.outerWidth - a.outerWidth()) * s.x, a.to.top = (n.outerHeight - a.to.outerHeight) * s.y, a.to.left = (n.outerWidth - a.to.outerWidth) * s.x), a.css(a.from), ("content" === g || "both" === g) && (f = f.concat(["marginTop", "marginBottom"]).concat(h), c = c.concat(["marginLeft", "marginRight"]), u = o.concat(f).concat(c), a.find("*[width]").each(function () {
            var i = e(this),
                n = {
                    height: i.height(),
                    width: i.width(),
                    outerHeight: i.outerHeight(),
                    outerWidth: i.outerWidth()
                };
            p && e.effects.save(i, u), i.from = {
                height: n.height * r.from.y,
                width: n.width * r.from.x,
                outerHeight: n.outerHeight * r.from.y,
                outerWidth: n.outerWidth * r.from.x
            }, i.to = {
                height: n.height * r.to.y,
                width: n.width * r.to.x,
                outerHeight: n.height * r.to.y,
                outerWidth: n.width * r.to.x
            }, r.from.y !== r.to.y && (i.from = e.effects.setTransition(i, f, r.from.y, i.from), i.to = e.effects.setTransition(i, f, r.to.y, i.to)), r.from.x !== r.to.x && (i.from = e.effects.setTransition(i, c, r.from.x, i.from), i.to = e.effects.setTransition(i, c, r.to.x, i.to)), i.css(i.from), i.animate(i.to, t.duration, t.easing, function () {
                p && e.effects.restore(i, u)
            })
        })), a.animate(a.to, {
            queue: !1,
            duration: t.duration,
            easing: t.easing,
            complete: function () {
                0 === a.to.opacity && a.css("opacity", a.from.opacity), "hide" === d && a.hide(), e.effects.restore(a, b), p || ("static" === v ? a.css({
                    position: "relative",
                    top: a.to.top,
                    left: a.to.left
                }) : e.each(["top", "left"], function (e, t) {
                    a.css(t, function (t, i) {
                        var n = parseInt(i, 10),
                            s = e ? a.to.left : a.to.top;
                        return "auto" === i ? s + "px" : n + s + "px"
                    })
                })), e.effects.removeWrapper(a), i()
            }
        })
    }
}(jQuery),
function (e) {
    e.effects.effect.shake = function (t, i) {
        var m, n = e(this),
            s = ["position", "top", "bottom", "left", "right", "height", "width"],
            r = e.effects.setMode(n, t.mode || "effect"),
            a = t.direction || "left",
            o = t.distance || 20,
            l = t.times || 3,
            u = 2 * l + 1,
            h = Math.round(t.duration / u),
            f = "up" === a || "down" === a ? "top" : "left",
            c = "up" === a || "left" === a,
            d = {},
            p = {},
            g = {},
            v = n.queue(),
            b = v.length;
        for (e.effects.save(n, s), n.show(), e.effects.createWrapper(n), d[f] = (c ? "-=" : "+=") + o, p[f] = (c ? "+=" : "-=") + 2 * o, g[f] = (c ? "-=" : "+=") + 2 * o, n.animate(d, h, t.easing), m = 1; l > m; m++) n.animate(p, h, t.easing).animate(g, h, t.easing);
        n.animate(p, h, t.easing).animate(d, h / 2, t.easing).queue(function () {
            "hide" === r && n.hide(), e.effects.restore(n, s), e.effects.removeWrapper(n), i()
        }), b > 1 && v.splice.apply(v, [1, 0].concat(v.splice(b, u + 1))), n.dequeue()
    }
}(jQuery),
function (e) {
    e.effects.effect.slide = function (t, i) {
        var h, n = e(this),
            s = ["position", "top", "bottom", "left", "right", "width", "height"],
            r = e.effects.setMode(n, t.mode || "show"),
            a = "show" === r,
            o = t.direction || "left",
            l = "up" === o || "down" === o ? "top" : "left",
            u = "up" === o || "left" === o,
            f = {};
        e.effects.save(n, s), n.show(), h = t.distance || n["top" === l ? "outerHeight" : "outerWidth"](!0), e.effects.createWrapper(n).css({
            overflow: "hidden"
        }), a && n.css(l, u ? isNaN(h) ? "-" + h : -h : h), f[l] = (a ? u ? "+=" : "-=" : u ? "-=" : "+=") + h, n.animate(f, {
            queue: !1,
            duration: t.duration,
            easing: t.easing,
            complete: function () {
                "hide" === r && n.hide(), e.effects.restore(n, s), e.effects.removeWrapper(n), i()
            }
        })
    }
}(jQuery),
function (e) {
    e.effects.effect.transfer = function (t, i) {
        var n = e(this),
            s = e(t.to),
            r = "fixed" === s.css("position"),
            a = e("body"),
            o = r ? a.scrollTop() : 0,
            l = r ? a.scrollLeft() : 0,
            u = s.offset(),
            h = {
                top: u.top - o,
                left: u.left - l,
                height: s.innerHeight(),
                width: s.innerWidth()
            },
            f = n.offset(),
            c = e("<div class='ui-effects-transfer'></div>").appendTo(document.body).addClass(t.className).css({
                top: f.top - o,
                left: f.left - l,
                height: n.innerHeight(),
                width: n.innerWidth(),
                position: r ? "fixed" : "absolute"
            }).animate(h, t.duration, t.easing, function () {
                c.remove(), i()
            })
    }
}(jQuery),
function (e) {
    e.widget("ui.menu", {
        version: "1.10.4",
        defaultElement: "<ul>",
        delay: 300,
        options: {
            icons: {
                submenu: "ui-icon-carat-1-e"
            },
            menus: "ul",
            position: {
                my: "left top",
                at: "right top"
            },
            role: "menu",
            blur: null,
            focus: null,
            select: null
        },
        _create: function () {
            this.activeMenu = this.element, this.mouseHandled = !1, this.element.uniqueId().addClass("ui-menu ui-widget ui-widget-content ui-corner-all").toggleClass("ui-menu-icons", !!this.element.find(".ui-icon").length).attr({
                role: this.options.role,
                tabIndex: 0
            }).bind("click" + this.eventNamespace, e.proxy(function (e) {
                this.options.disabled && e.preventDefault()
            }, this)), this.options.disabled && this.element.addClass("ui-state-disabled").attr("aria-disabled", "true"), this._on({
                "mousedown .ui-menu-item > a": function (e) {
                    e.preventDefault()
                },
                "click .ui-state-disabled > a": function (e) {
                    e.preventDefault()
                },
                "click .ui-menu-item:has(a)": function (t) {
                    var i = e(t.target).closest(".ui-menu-item");
                    !this.mouseHandled && i.not(".ui-state-disabled").length && (this.select(t), t.isPropagationStopped() || (this.mouseHandled = !0), i.has(".ui-menu").length ? this.expand(t) : !this.element.is(":focus") && e(this.document[0].activeElement).closest(".ui-menu").length && (this.element.trigger("focus", [!0]), this.active && 1 === this.active.parents(".ui-menu").length && clearTimeout(this.timer)))
                },
                "mouseenter .ui-menu-item": function (t) {
                    var i = e(t.currentTarget);
                    i.siblings().children(".ui-state-active").removeClass("ui-state-active"), this.focus(t, i)
                },
                mouseleave: "collapseAll",
                "mouseleave .ui-menu": "collapseAll",
                focus: function (e, t) {
                    var i = this.active || this.element.children(".ui-menu-item").eq(0);
                    t || this.focus(e, i)
                },
                blur: function (t) {
                    this._delay(function () {
                        e.contains(this.element[0], this.document[0].activeElement) || this.collapseAll(t)
                    })
                },
                keydown: "_keydown"
            }), this.refresh(), this._on(this.document, {
                click: function (t) {
                    e(t.target).closest(".ui-menu").length || this.collapseAll(t), this.mouseHandled = !1
                }
            })
        },
        _destroy: function () {
            this.element.removeAttr("aria-activedescendant").find(".ui-menu").addBack().removeClass("ui-menu ui-widget ui-widget-content ui-corner-all ui-menu-icons").removeAttr("role").removeAttr("tabIndex").removeAttr("aria-labelledby").removeAttr("aria-expanded").removeAttr("aria-hidden").removeAttr("aria-disabled").removeUniqueId().show(), this.element.find(".ui-menu-item").removeClass("ui-menu-item").removeAttr("role").removeAttr("aria-disabled").children("a").removeUniqueId().removeClass("ui-corner-all ui-state-hover").removeAttr("tabIndex").removeAttr("role").removeAttr("aria-haspopup").children().each(function () {
                var t = e(this);
                t.data("ui-menu-submenu-carat") && t.remove()
            }), this.element.find(".ui-menu-divider").removeClass("ui-menu-divider ui-widget-content")
        },
        _keydown: function (t) {
            function l(e) {
                return e.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&")
            }
            var i, n, s, r, a, o = !0;
            switch (t.keyCode) {
                case e.ui.keyCode.PAGE_UP:
                    this.previousPage(t);
                    break;
                case e.ui.keyCode.PAGE_DOWN:
                    this.nextPage(t);
                    break;
                case e.ui.keyCode.HOME:
                    this._move("first", "first", t);
                    break;
                case e.ui.keyCode.END:
                    this._move("last", "last", t);
                    break;
                case e.ui.keyCode.UP:
                    this.previous(t);
                    break;
                case e.ui.keyCode.DOWN:
                    this.next(t);
                    break;
                case e.ui.keyCode.LEFT:
                    this.collapse(t);
                    break;
                case e.ui.keyCode.RIGHT:
                    this.active && !this.active.is(".ui-state-disabled") && this.expand(t);
                    break;
                case e.ui.keyCode.ENTER:
                case e.ui.keyCode.SPACE:
                    this._activate(t);
                    break;
                case e.ui.keyCode.ESCAPE:
                    this.collapse(t);
                    break;
                default:
                    o = !1, n = this.previousFilter || "", s = String.fromCharCode(t.keyCode), r = !1, clearTimeout(this.filterTimer), s === n ? r = !0 : s = n + s, a = new RegExp("^" + l(s), "i"), i = this.activeMenu.children(".ui-menu-item").filter(function () {
                        return a.test(e(this).children("a").text())
                    }), i = r && -1 !== i.index(this.active.next()) ? this.active.nextAll(".ui-menu-item") : i, i.length || (s = String.fromCharCode(t.keyCode), a = new RegExp("^" + l(s), "i"), i = this.activeMenu.children(".ui-menu-item").filter(function () {
                        return a.test(e(this).children("a").text())
                    })), i.length ? (this.focus(t, i), i.length > 1 ? (this.previousFilter = s, this.filterTimer = this._delay(function () {
                        delete this.previousFilter
                    }, 1e3)) : delete this.previousFilter) : delete this.previousFilter
            }
            o && t.preventDefault()
        },
        _activate: function (e) {
            this.active.is(".ui-state-disabled") || (this.active.children("a[aria-haspopup='true']").length ? this.expand(e) : this.select(e))
        },
        refresh: function () {
            var t, i = this.options.icons.submenu,
                n = this.element.find(this.options.menus);
            this.element.toggleClass("ui-menu-icons", !!this.element.find(".ui-icon").length), n.filter(":not(.ui-menu)").addClass("ui-menu ui-widget ui-widget-content ui-corner-all").hide().attr({
                role: this.options.role,
                "aria-hidden": "true",
                "aria-expanded": "false"
            }).each(function () {
                var t = e(this),
                    n = t.prev("a"),
                    s = e("<span>").addClass("ui-menu-icon ui-icon " + i).data("ui-menu-submenu-carat", !0);
                n.attr("aria-haspopup", "true").prepend(s), t.attr("aria-labelledby", n.attr("id"))
            }), t = n.add(this.element), t.children(":not(.ui-menu-item):has(a)").addClass("ui-menu-item").attr("role", "presentation").children("a").uniqueId().addClass("ui-corner-all").attr({
                tabIndex: -1,
                role: this._itemRole()
            }), t.children(":not(.ui-menu-item)").each(function () {
                var t = e(this);
                /[^\-\u2014\u2013\s]/.test(t.text()) || t.addClass("ui-widget-content ui-menu-divider")
            }), t.children(".ui-state-disabled").attr("aria-disabled", "true"), this.active && !e.contains(this.element[0], this.active[0]) && this.blur()
        },
        _itemRole: function () {
            return {
                menu: "menuitem",
                listbox: "option"
            }[this.options.role]
        },
        _setOption: function (e, t) {
            "icons" === e && this.element.find(".ui-menu-icon").removeClass(this.options.icons.submenu).addClass(t.submenu), this._super(e, t)
        },
        focus: function (e, t) {
            var i, n;
            this.blur(e, e && "focus" === e.type), this._scrollIntoView(t), this.active = t.first(), n = this.active.children("a").addClass("ui-state-focus"), this.options.role && this.element.attr("aria-activedescendant", n.attr("id")), this.active.parent().closest(".ui-menu-item").children("a:first").addClass("ui-state-active"), e && "keydown" === e.type ? this._close() : this.timer = this._delay(function () {
                this._close()
            }, this.delay), i = t.children(".ui-menu"), i.length && e && /^mouse/.test(e.type) && this._startOpening(i), this.activeMenu = t.parent(), this._trigger("focus", e, {
                item: t
            })
        },
        _scrollIntoView: function (t) {
            var i, n, s, r, a, o;
            this._hasScroll() && (i = parseFloat(e.css(this.activeMenu[0], "borderTopWidth")) || 0, n = parseFloat(e.css(this.activeMenu[0], "paddingTop")) || 0, s = t.offset().top - this.activeMenu.offset().top - i - n, r = this.activeMenu.scrollTop(), a = this.activeMenu.height(), o = t.height(), 0 > s ? this.activeMenu.scrollTop(r + s) : s + o > a && this.activeMenu.scrollTop(r + s - a + o))
        },
        blur: function (e, t) {
            t || clearTimeout(this.timer), this.active && (this.active.children("a").removeClass("ui-state-focus"), this.active = null, this._trigger("blur", e, {
                item: this.active
            }))
        },
        _startOpening: function (e) {
            clearTimeout(this.timer), "true" === e.attr("aria-hidden") && (this.timer = this._delay(function () {
                this._close(), this._open(e)
            }, this.delay))
        },
        _open: function (t) {
            var i = e.extend({
                of: this.active
            }, this.options.position);
            clearTimeout(this.timer), this.element.find(".ui-menu").not(t.parents(".ui-menu")).hide().attr("aria-hidden", "true"), t.show().removeAttr("aria-hidden").attr("aria-expanded", "true").position(i)
        },
        collapseAll: function (t, i) {
            clearTimeout(this.timer), this.timer = this._delay(function () {
                var n = i ? this.element : e(t && t.target).closest(this.element.find(".ui-menu"));
                n.length || (n = this.element), this._close(n), this.blur(t), this.activeMenu = n
            }, this.delay)
        },
        _close: function (e) {
            e || (e = this.active ? this.active.parent() : this.element), e.find(".ui-menu").hide().attr("aria-hidden", "true").attr("aria-expanded", "false").end().find("a.ui-state-active").removeClass("ui-state-active")
        },
        collapse: function (e) {
            var t = this.active && this.active.parent().closest(".ui-menu-item", this.element);
            t && t.length && (this._close(), this.focus(e, t))
        },
        expand: function (e) {
            var t = this.active && this.active.children(".ui-menu ").children(".ui-menu-item").first();
            t && t.length && (this._open(t.parent()), this._delay(function () {
                this.focus(e, t)
            }))
        },
        next: function (e) {
            this._move("next", "first", e)
        },
        previous: function (e) {
            this._move("prev", "last", e)
        },
        isFirstItem: function () {
            return this.active && !this.active.prevAll(".ui-menu-item").length
        },
        isLastItem: function () {
            return this.active && !this.active.nextAll(".ui-menu-item").length
        },
        _move: function (e, t, i) {
            var n;
            this.active && (n = "first" === e || "last" === e ? this.active["first" === e ? "prevAll" : "nextAll"](".ui-menu-item").eq(-1) : this.active[e + "All"](".ui-menu-item").eq(0)), n && n.length && this.active || (n = this.activeMenu.children(".ui-menu-item")[t]()), this.focus(i, n)
        },
        nextPage: function (t) {
            var i, n, s;
            return this.active ? void(this.isLastItem() || (this._hasScroll() ? (n = this.active.offset().top, s = this.element.height(), this.active.nextAll(".ui-menu-item").each(function () {
                return i = e(this), i.offset().top - n - s < 0
            }), this.focus(t, i)) : this.focus(t, this.activeMenu.children(".ui-menu-item")[this.active ? "last" : "first"]()))) : void this.next(t)
        },
        previousPage: function (t) {
            var i, n, s;
            return this.active ? void(this.isFirstItem() || (this._hasScroll() ? (n = this.active.offset().top, s = this.element.height(), this.active.prevAll(".ui-menu-item").each(function () {
                return i = e(this), i.offset().top - n + s > 0
            }), this.focus(t, i)) : this.focus(t, this.activeMenu.children(".ui-menu-item").first()))) : void this.next(t)
        },
        _hasScroll: function () {
            return this.element.outerHeight() < this.element.prop("scrollHeight")
        },
        select: function (t) {
            this.active = this.active || e(t.target).closest(".ui-menu-item");
            var i = {
                item: this.active
            };
            this.active.has(".ui-menu").length || this.collapseAll(t, !0), this._trigger("select", t, i)
        }
    })
}(jQuery),
function (e, t) {
    function c(e, t, i) {
        return [parseFloat(e[0]) * (h.test(e[0]) ? t / 100 : 1), parseFloat(e[1]) * (h.test(e[1]) ? i / 100 : 1)]
    }

    function d(t, i) {
        return parseInt(e.css(t, i), 10) || 0
    }

    function p(t) {
        var i = t[0];
        return 9 === i.nodeType ? {
            width: t.width(),
            height: t.height(),
            offset: {
                top: 0,
                left: 0
            }
        } : e.isWindow(i) ? {
            width: t.width(),
            height: t.height(),
            offset: {
                top: t.scrollTop(),
                left: t.scrollLeft()
            }
        } : i.preventDefault ? {
            width: 0,
            height: 0,
            offset: {
                top: i.pageY,
                left: i.pageX
            }
        } : {
            width: t.outerWidth(),
            height: t.outerHeight(),
            offset: t.offset()
        }
    }
    e.ui = e.ui || {};
    var i, n = Math.max,
        s = Math.abs,
        r = Math.round,
        a = /left|center|right/,
        o = /top|center|bottom/,
        l = /[\+\-]\d+(\.[\d]+)?%?/,
        u = /^\w+/,
        h = /%$/,
        f = e.fn.position;
    e.position = {
            scrollbarWidth: function () {
                if (i !== t) return i;
                var n, s, r = e("<div style='display:block;position:absolute;width:50px;height:50px;overflow:hidden;'><div style='height:100px;width:auto;'></div></div>"),
                    a = r.children()[0];
                return e("body").append(r), n = a.offsetWidth, r.css("overflow", "scroll"), s = a.offsetWidth, n === s && (s = r[0].clientWidth), r.remove(), i = n - s
            },
            getScrollInfo: function (t) {
                var i = t.isWindow || t.isDocument ? "" : t.element.css("overflow-x"),
                    n = t.isWindow || t.isDocument ? "" : t.element.css("overflow-y"),
                    s = "scroll" === i || "auto" === i && t.width < t.element[0].scrollWidth,
                    r = "scroll" === n || "auto" === n && t.height < t.element[0].scrollHeight;
                return {
                    width: r ? e.position.scrollbarWidth() : 0,
                    height: s ? e.position.scrollbarWidth() : 0
                }
            },
            getWithinInfo: function (t) {
                var i = e(t || window),
                    n = e.isWindow(i[0]),
                    s = !!i[0] && 9 === i[0].nodeType;
                return {
                    element: i,
                    isWindow: n,
                    isDocument: s,
                    offset: i.offset() || {
                        left: 0,
                        top: 0
                    },
                    scrollLeft: i.scrollLeft(),
                    scrollTop: i.scrollTop(),
                    width: n ? i.width() : i.outerWidth(),
                    height: n ? i.height() : i.outerHeight()
                }
            }
        }, e.fn.position = function (t) {
            if (!t || !t.of) return f.apply(this, arguments);
            t = e.extend({}, t);
            var i, h, g, m, v, b, y = e(t.of),
                _ = e.position.getWithinInfo(t.within),
                w = e.position.getScrollInfo(_),
                x = (t.collision || "flip").split(" "),
                k = {};
            return b = p(y), y[0].preventDefault && (t.at = "left top"), h = b.width, g = b.height, m = b.offset, v = e.extend({}, m), e.each(["my", "at"], function () {
                var i, n, e = (t[this] || "").split(" ");
                1 === e.length && (e = a.test(e[0]) ? e.concat(["center"]) : o.test(e[0]) ? ["center"].concat(e) : ["center", "center"]), e[0] = a.test(e[0]) ? e[0] : "center", e[1] = o.test(e[1]) ? e[1] : "center", i = l.exec(e[0]), n = l.exec(e[1]), k[this] = [i ? i[0] : 0, n ? n[0] : 0], t[this] = [u.exec(e[0])[0], u.exec(e[1])[0]]
            }), 1 === x.length && (x[1] = x[0]), "right" === t.at[0] ? v.left += h : "center" === t.at[0] && (v.left += h / 2), "bottom" === t.at[1] ? v.top += g : "center" === t.at[1] && (v.top += g / 2), i = c(k.at, h, g), v.left += i[0], v.top += i[1], this.each(function () {
                var a, o, l = e(this),
                    u = l.outerWidth(),
                    f = l.outerHeight(),
                    p = d(this, "marginLeft"),
                    b = d(this, "marginTop"),
                    C = u + p + d(this, "marginRight") + w.width,
                    D = f + b + d(this, "marginBottom") + w.height,
                    T = e.extend({}, v),
                    S = c(k.my, l.outerWidth(), l.outerHeight());
                "right" === t.my[0] ? T.left -= u : "center" === t.my[0] && (T.left -= u / 2), "bottom" === t.my[1] ? T.top -= f : "center" === t.my[1] && (T.top -= f / 2), T.left += S[0], T.top += S[1], e.support.offsetFractions || (T.left = r(T.left), T.top = r(T.top)), a = {
                    marginLeft: p,
                    marginTop: b
                }, e.each(["left", "top"], function (n, s) {
                    e.ui.position[x[n]] && e.ui.position[x[n]][s](T, {
                        targetWidth: h,
                        targetHeight: g,
                        elemWidth: u,
                        elemHeight: f,
                        collisionPosition: a,
                        collisionWidth: C,
                        collisionHeight: D,
                        offset: [i[0] + S[0], i[1] + S[1]],
                        my: t.my,
                        at: t.at,
                        within: _,
                        elem: l
                    })
                }), t.using && (o = function (e) {
                    var i = m.left - T.left,
                        r = i + h - u,
                        a = m.top - T.top,
                        o = a + g - f,
                        c = {
                            target: {
                                element: y,
                                left: m.left,
                                top: m.top,
                                width: h,
                                height: g
                            },
                            element: {
                                element: l,
                                left: T.left,
                                top: T.top,
                                width: u,
                                height: f
                            },
                            horizontal: 0 > r ? "left" : i > 0 ? "right" : "center",
                            vertical: 0 > o ? "top" : a > 0 ? "bottom" : "middle"
                        };
                    u > h && s(i + r) < h && (c.horizontal = "center"), f > g && s(a + o) < g && (c.vertical = "middle"), c.important = n(s(i), s(r)) > n(s(a), s(o)) ? "horizontal" : "vertical", t.using.call(this, e, c)
                }), l.offset(e.extend(T, {
                    using: o
                }))
            })
        }, e.ui.position = {
            fit: {
                left: function (e, t) {
                    var u, i = t.within,
                        s = i.isWindow ? i.scrollLeft : i.offset.left,
                        r = i.width,
                        a = e.left - t.collisionPosition.marginLeft,
                        o = s - a,
                        l = a + t.collisionWidth - r - s;
                    t.collisionWidth > r ? o > 0 && 0 >= l ? (u = e.left + o + t.collisionWidth - r - s, e.left += o - u) : e.left = l > 0 && 0 >= o ? s : o > l ? s + r - t.collisionWidth : s : o > 0 ? e.left += o : l > 0 ? e.left -= l : e.left = n(e.left - a, e.left)
                },
                top: function (e, t) {
                    var u, i = t.within,
                        s = i.isWindow ? i.scrollTop : i.offset.top,
                        r = t.within.height,
                        a = e.top - t.collisionPosition.marginTop,
                        o = s - a,
                        l = a + t.collisionHeight - r - s;
                    t.collisionHeight > r ? o > 0 && 0 >= l ? (u = e.top + o + t.collisionHeight - r - s, e.top += o - u) : e.top = l > 0 && 0 >= o ? s : o > l ? s + r - t.collisionHeight : s : o > 0 ? e.top += o : l > 0 ? e.top -= l : e.top = n(e.top - a, e.top)
                }
            },
            flip: {
                left: function (e, t) {
                    var d, p, i = t.within,
                        n = i.offset.left + i.scrollLeft,
                        r = i.width,
                        a = i.isWindow ? i.scrollLeft : i.offset.left,
                        o = e.left - t.collisionPosition.marginLeft,
                        l = o - a,
                        u = o + t.collisionWidth - r - a,
                        h = "left" === t.my[0] ? -t.elemWidth : "right" === t.my[0] ? t.elemWidth : 0,
                        f = "left" === t.at[0] ? t.targetWidth : "right" === t.at[0] ? -t.targetWidth : 0,
                        c = -2 * t.offset[0];
                    0 > l ? (d = e.left + h + f + c + t.collisionWidth - r - n, (0 > d || d < s(l)) && (e.left += h + f + c)) : u > 0 && (p = e.left - t.collisionPosition.marginLeft + h + f + c - a, (p > 0 || s(p) < u) && (e.left += h + f + c))
                },
                top: function (e, t) {
                    var p, g, i = t.within,
                        n = i.offset.top + i.scrollTop,
                        r = i.height,
                        a = i.isWindow ? i.scrollTop : i.offset.top,
                        o = e.top - t.collisionPosition.marginTop,
                        l = o - a,
                        u = o + t.collisionHeight - r - a,
                        h = "top" === t.my[1],
                        f = h ? -t.elemHeight : "bottom" === t.my[1] ? t.elemHeight : 0,
                        c = "top" === t.at[1] ? t.targetHeight : "bottom" === t.at[1] ? -t.targetHeight : 0,
                        d = -2 * t.offset[1];
                    0 > l ? (g = e.top + f + c + d + t.collisionHeight - r - n, e.top + f + c + d > l && (0 > g || g < s(l)) && (e.top += f + c + d)) : u > 0 && (p = e.top - t.collisionPosition.marginTop + f + c + d - a, e.top + f + c + d > u && (p > 0 || s(p) < u) && (e.top += f + c + d))
                }
            },
            flipfit: {
                left: function () {
                    e.ui.position.flip.left.apply(this, arguments), e.ui.position.fit.left.apply(this, arguments)
                },
                top: function () {
                    e.ui.position.flip.top.apply(this, arguments), e.ui.position.fit.top.apply(this, arguments)
                }
            }
        },
        function () {
            var t, i, n, s, r, a = document.getElementsByTagName("body")[0],
                o = document.createElement("div");
            t = document.createElement(a ? "div" : "body"), n = {
                visibility: "hidden",
                width: 0,
                height: 0,
                border: 0,
                margin: 0,
                background: "none"
            }, a && e.extend(n, {
                position: "absolute",
                left: "-1000px",
                top: "-1000px"
            });
            for (r in n) t.style[r] = n[r];
            t.appendChild(o), i = a || document.documentElement, i.insertBefore(t, i.firstChild), o.style.cssText = "position: absolute; left: 10.7432222px;", s = e(o).offset().left, e.support.offsetFractions = s > 10 && 11 > s, t.innerHTML = "", i.removeChild(t)
        }()
}(jQuery),
function (e, t) {
    e.widget("ui.progressbar", {
        version: "1.10.4",
        options: {
            max: 100,
            value: 0,
            change: null,
            complete: null
        },
        min: 0,
        _create: function () {
            this.oldValue = this.options.value = this._constrainedValue(), this.element.addClass("ui-progressbar ui-widget ui-widget-content ui-corner-all").attr({
                role: "progressbar",
                "aria-valuemin": this.min
            }), this.valueDiv = e("<div class='ui-progressbar-value ui-widget-header ui-corner-left'></div>").appendTo(this.element), this._refreshValue()
        },
        _destroy: function () {
            this.element.removeClass("ui-progressbar ui-widget ui-widget-content ui-corner-all").removeAttr("role").removeAttr("aria-valuemin").removeAttr("aria-valuemax").removeAttr("aria-valuenow"), this.valueDiv.remove()
        },
        value: function (e) {
            return e === t ? this.options.value : (this.options.value = this._constrainedValue(e), void this._refreshValue())
        },
        _constrainedValue: function (e) {
            return e === t && (e = this.options.value), this.indeterminate = e === !1, "number" != typeof e && (e = 0), this.indeterminate ? !1 : Math.min(this.options.max, Math.max(this.min, e))
        },
        _setOptions: function (e) {
            var t = e.value;
            delete e.value, this._super(e), this.options.value = this._constrainedValue(t), this._refreshValue()
        },
        _setOption: function (e, t) {
            "max" === e && (t = Math.max(this.min, t)), this._super(e, t)
        },
        _percentage: function () {
            return this.indeterminate ? 100 : 100 * (this.options.value - this.min) / (this.options.max - this.min)
        },
        _refreshValue: function () {
            var t = this.options.value,
                i = this._percentage();
            this.valueDiv.toggle(this.indeterminate || t > this.min).toggleClass("ui-corner-right", t === this.options.max).width(i.toFixed(0) + "%"), this.element.toggleClass("ui-progressbar-indeterminate", this.indeterminate), this.indeterminate ? (this.element.removeAttr("aria-valuenow"), this.overlayDiv || (this.overlayDiv = e("<div class='ui-progressbar-overlay'></div>").appendTo(this.valueDiv))) : (this.element.attr({
                "aria-valuemax": this.options.max,
                "aria-valuenow": t
            }), this.overlayDiv && (this.overlayDiv.remove(), this.overlayDiv = null)), this.oldValue !== t && (this.oldValue = t, this._trigger("change")), t === this.options.max && this._trigger("complete")
        }
    })
}(jQuery),
function (e) {
    var i = 5;
    e.widget("ui.slider", e.ui.mouse, {
        version: "1.10.4",
        widgetEventPrefix: "slide",
        options: {
            animate: !1,
            distance: 0,
            max: 100,
            min: 0,
            orientation: "horizontal",
            range: !1,
            step: 1,
            value: 0,
            values: null,
            change: null,
            slide: null,
            start: null,
            stop: null
        },
        _create: function () {
            this._keySliding = !1, this._mouseSliding = !1, this._animateOff = !0, this._handleIndex = null, this._detectOrientation(), this._mouseInit(), this.element.addClass("ui-slider ui-slider-" + this.orientation + " ui-widget ui-widget-content ui-corner-all"), this._refresh(), this._setOption("disabled", this.options.disabled), this._animateOff = !1
        },
        _refresh: function () {
            this._createRange(), this._createHandles(), this._setupEvents(), this._refreshValue()
        },
        _createHandles: function () {
            var t, i, n = this.options,
                s = this.element.find(".ui-slider-handle").addClass("ui-state-default ui-corner-all"),
                r = "<a class='ui-slider-handle ui-state-default ui-corner-all' href='#'></a>",
                a = [];
            for (i = n.values && n.values.length || 1, s.length > i && (s.slice(i).remove(), s = s.slice(0, i)), t = s.length; i > t; t++) a.push(r);
            this.handles = s.add(e(a.join("")).appendTo(this.element)), this.handle = this.handles.eq(0), this.handles.each(function (t) {
                e(this).data("ui-slider-handle-index", t)
            })
        },
        _createRange: function () {
            var t = this.options,
                i = "";
            t.range ? (t.range === !0 && (t.values ? t.values.length && 2 !== t.values.length ? t.values = [t.values[0], t.values[0]] : e.isArray(t.values) && (t.values = t.values.slice(0)) : t.values = [this._valueMin(), this._valueMin()]), this.range && this.range.length ? this.range.removeClass("ui-slider-range-min ui-slider-range-max").css({
                left: "",
                bottom: ""
            }) : (this.range = e("<div></div>").appendTo(this.element), i = "ui-slider-range ui-widget-header ui-corner-all"), this.range.addClass(i + ("min" === t.range || "max" === t.range ? " ui-slider-range-" + t.range : ""))) : (this.range && this.range.remove(), this.range = null)
        },
        _setupEvents: function () {
            var e = this.handles.add(this.range).filter("a");
            this._off(e), this._on(e, this._handleEvents), this._hoverable(e), this._focusable(e)
        },
        _destroy: function () {
            this.handles.remove(), this.range && this.range.remove(), this.element.removeClass("ui-slider ui-slider-horizontal ui-slider-vertical ui-widget ui-widget-content ui-corner-all"), this._mouseDestroy()
        },
        _mouseCapture: function (t) {
            var i, n, s, r, a, o, l, u, h = this,
                f = this.options;
            return f.disabled ? !1 : (this.elementSize = {
                width: this.element.outerWidth(),
                height: this.element.outerHeight()
            }, this.elementOffset = this.element.offset(), i = {
                x: t.pageX,
                y: t.pageY
            }, n = this._normValueFromMouse(i), s = this._valueMax() - this._valueMin() + 1, this.handles.each(function (t) {
                var i = Math.abs(n - h.values(t));
                (s > i || s === i && (t === h._lastChangedValue || h.values(t) === f.min)) && (s = i, r = e(this), a = t)
            }), o = this._start(t, a), o === !1 ? !1 : (this._mouseSliding = !0, this._handleIndex = a, r.addClass("ui-state-active").focus(), l = r.offset(), u = !e(t.target).parents().addBack().is(".ui-slider-handle"), this._clickOffset = u ? {
                left: 0,
                top: 0
            } : {
                left: t.pageX - l.left - r.width() / 2,
                top: t.pageY - l.top - r.height() / 2 - (parseInt(r.css("borderTopWidth"), 10) || 0) - (parseInt(r.css("borderBottomWidth"), 10) || 0) + (parseInt(r.css("marginTop"), 10) || 0)
            }, this.handles.hasClass("ui-state-hover") || this._slide(t, a, n), this._animateOff = !0, !0))
        },
        _mouseStart: function () {
            return !0
        },
        _mouseDrag: function (e) {
            var t = {
                    x: e.pageX,
                    y: e.pageY
                },
                i = this._normValueFromMouse(t);
            return this._slide(e, this._handleIndex, i), !1
        },
        _mouseStop: function (e) {
            return this.handles.removeClass("ui-state-active"), this._mouseSliding = !1, this._stop(e, this._handleIndex), this._change(e, this._handleIndex), this._handleIndex = null, this._clickOffset = null, this._animateOff = !1, !1
        },
        _detectOrientation: function () {
            this.orientation = "vertical" === this.options.orientation ? "vertical" : "horizontal"
        },
        _normValueFromMouse: function (e) {
            var t, i, n, s, r;
            return "horizontal" === this.orientation ? (t = this.elementSize.width, i = e.x - this.elementOffset.left - (this._clickOffset ? this._clickOffset.left : 0)) : (t = this.elementSize.height, i = e.y - this.elementOffset.top - (this._clickOffset ? this._clickOffset.top : 0)), n = i / t, n > 1 && (n = 1), 0 > n && (n = 0), "vertical" === this.orientation && (n = 1 - n), s = this._valueMax() - this._valueMin(), r = this._valueMin() + n * s, this._trimAlignValue(r)
        },
        _start: function (e, t) {
            var i = {
                handle: this.handles[t],
                value: this.value()
            };
            return this.options.values && this.options.values.length && (i.value = this.values(t), i.values = this.values()), this._trigger("start", e, i)
        },
        _slide: function (e, t, i) {
            var n, s, r;
            this.options.values && this.options.values.length ? (n = this.values(t ? 0 : 1), 2 === this.options.values.length && this.options.range === !0 && (0 === t && i > n || 1 === t && n > i) && (i = n), i !== this.values(t) && (s = this.values(), s[t] = i, r = this._trigger("slide", e, {
                handle: this.handles[t],
                value: i,
                values: s
            }), n = this.values(t ? 0 : 1), r !== !1 && this.values(t, i))) : i !== this.value() && (r = this._trigger("slide", e, {
                handle: this.handles[t],
                value: i
            }), r !== !1 && this.value(i))
        },
        _stop: function (e, t) {
            var i = {
                handle: this.handles[t],
                value: this.value()
            };
            this.options.values && this.options.values.length && (i.value = this.values(t), i.values = this.values()), this._trigger("stop", e, i)
        },
        _change: function (e, t) {
            if (!this._keySliding && !this._mouseSliding) {
                var i = {
                    handle: this.handles[t],
                    value: this.value()
                };
                this.options.values && this.options.values.length && (i.value = this.values(t), i.values = this.values()), this._lastChangedValue = t, this._trigger("change", e, i)
            }
        },
        value: function (e) {
            return arguments.length ? (this.options.value = this._trimAlignValue(e), this._refreshValue(), void this._change(null, 0)) : this._value()
        },
        values: function (t, i) {
            var n, s, r;
            if (arguments.length > 1) return this.options.values[t] = this._trimAlignValue(i), this._refreshValue(), void this._change(null, t);
            if (!arguments.length) return this._values();
            if (!e.isArray(arguments[0])) return this.options.values && this.options.values.length ? this._values(t) : this.value();
            for (n = this.options.values, s = arguments[0], r = 0; r < n.length; r += 1) n[r] = this._trimAlignValue(s[r]), this._change(null, r);
            this._refreshValue()
        },
        _setOption: function (t, i) {
            var n, s = 0;
            switch ("range" === t && this.options.range === !0 && ("min" === i ? (this.options.value = this._values(0), this.options.values = null) : "max" === i && (this.options.value = this._values(this.options.values.length - 1), this.options.values = null)), e.isArray(this.options.values) && (s = this.options.values.length), e.Widget.prototype._setOption.apply(this, arguments), t) {
                case "orientation":
                    this._detectOrientation(), this.element.removeClass("ui-slider-horizontal ui-slider-vertical").addClass("ui-slider-" + this.orientation), this._refreshValue();
                    break;
                case "value":
                    this._animateOff = !0, this._refreshValue(), this._change(null, 0), this._animateOff = !1;
                    break;
                case "values":
                    for (this._animateOff = !0, this._refreshValue(), n = 0; s > n; n += 1) this._change(null, n);
                    this._animateOff = !1;
                    break;
                case "min":
                case "max":
                    this._animateOff = !0, this._refreshValue(), this._animateOff = !1;
                    break;
                case "range":
                    this._animateOff = !0, this._refresh(), this._animateOff = !1
            }
        },
        _value: function () {
            var e = this.options.value;
            return e = this._trimAlignValue(e)
        },
        _values: function (e) {
            var t, i, n;
            if (arguments.length) return t = this.options.values[e], t = this._trimAlignValue(t);
            if (this.options.values && this.options.values.length) {
                for (i = this.options.values.slice(), n = 0; n < i.length; n += 1) i[n] = this._trimAlignValue(i[n]);
                return i
            }
            return []
        },
        _trimAlignValue: function (e) {
            if (e <= this._valueMin()) return this._valueMin();
            if (e >= this._valueMax()) return this._valueMax();
            var t = this.options.step > 0 ? this.options.step : 1,
                i = (e - this._valueMin()) % t,
                n = e - i;
            return 2 * Math.abs(i) >= t && (n += i > 0 ? t : -t), parseFloat(n.toFixed(5))
        },
        _valueMin: function () {
            return this.options.min
        },
        _valueMax: function () {
            return this.options.max
        },
        _refreshValue: function () {
            var t, i, n, s, r, a = this.options.range,
                o = this.options,
                l = this,
                u = this._animateOff ? !1 : o.animate,
                h = {};
            this.options.values && this.options.values.length ? this.handles.each(function (n) {
                i = (l.values(n) - l._valueMin()) / (l._valueMax() - l._valueMin()) * 100, h["horizontal" === l.orientation ? "left" : "bottom"] = i + "%", e(this).stop(1, 1)[u ? "animate" : "css"](h, o.animate), l.options.range === !0 && ("horizontal" === l.orientation ? (0 === n && l.range.stop(1, 1)[u ? "animate" : "css"]({
                    left: i + "%"
                }, o.animate), 1 === n && l.range[u ? "animate" : "css"]({
                    width: i - t + "%"
                }, {
                    queue: !1,
                    duration: o.animate
                })) : (0 === n && l.range.stop(1, 1)[u ? "animate" : "css"]({
                    bottom: i + "%"
                }, o.animate), 1 === n && l.range[u ? "animate" : "css"]({
                    height: i - t + "%"
                }, {
                    queue: !1,
                    duration: o.animate
                }))), t = i
            }) : (n = this.value(), s = this._valueMin(), r = this._valueMax(), i = r !== s ? (n - s) / (r - s) * 100 : 0, h["horizontal" === this.orientation ? "left" : "bottom"] = i + "%", this.handle.stop(1, 1)[u ? "animate" : "css"](h, o.animate), "min" === a && "horizontal" === this.orientation && this.range.stop(1, 1)[u ? "animate" : "css"]({
                width: i + "%"
            }, o.animate), "max" === a && "horizontal" === this.orientation && this.range[u ? "animate" : "css"]({
                width: 100 - i + "%"
            }, {
                queue: !1,
                duration: o.animate
            }), "min" === a && "vertical" === this.orientation && this.range.stop(1, 1)[u ? "animate" : "css"]({
                height: i + "%"
            }, o.animate), "max" === a && "vertical" === this.orientation && this.range[u ? "animate" : "css"]({
                height: 100 - i + "%"
            }, {
                queue: !1,
                duration: o.animate
            }))
        },
        _handleEvents: {
            keydown: function (t) {
                var n, s, r, a, o = e(t.target).data("ui-slider-handle-index");
                switch (t.keyCode) {
                    case e.ui.keyCode.HOME:
                    case e.ui.keyCode.END:
                    case e.ui.keyCode.PAGE_UP:
                    case e.ui.keyCode.PAGE_DOWN:
                    case e.ui.keyCode.UP:
                    case e.ui.keyCode.RIGHT:
                    case e.ui.keyCode.DOWN:
                    case e.ui.keyCode.LEFT:
                        if (t.preventDefault(), !this._keySliding && (this._keySliding = !0, e(t.target).addClass("ui-state-active"), n = this._start(t, o), n === !1)) return
                }
                switch (a = this.options.step, s = r = this.options.values && this.options.values.length ? this.values(o) : this.value(), t.keyCode) {
                    case e.ui.keyCode.HOME:
                        r = this._valueMin();
                        break;
                    case e.ui.keyCode.END:
                        r = this._valueMax();
                        break;
                    case e.ui.keyCode.PAGE_UP:
                        r = this._trimAlignValue(s + (this._valueMax() - this._valueMin()) / i);
                        break;
                    case e.ui.keyCode.PAGE_DOWN:
                        r = this._trimAlignValue(s - (this._valueMax() - this._valueMin()) / i);
                        break;
                    case e.ui.keyCode.UP:
                    case e.ui.keyCode.RIGHT:
                        if (s === this._valueMax()) return;
                        r = this._trimAlignValue(s + a);
                        break;
                    case e.ui.keyCode.DOWN:
                    case e.ui.keyCode.LEFT:
                        if (s === this._valueMin()) return;
                        r = this._trimAlignValue(s - a)
                }
                this._slide(t, o, r)
            },
            click: function (e) {
                e.preventDefault()
            },
            keyup: function (t) {
                var i = e(t.target).data("ui-slider-handle-index");
                this._keySliding && (this._keySliding = !1, this._stop(t, i), this._change(t, i), e(t.target).removeClass("ui-state-active"))
            }
        }
    })
}(jQuery),
function (e) {
    function t(e) {
        return function () {
            var t = this.element.val();
            e.apply(this, arguments), this._refresh(), t !== this.element.val() && this._trigger("change")
        }
    }
    e.widget("ui.spinner", {
        version: "1.10.4",
        defaultElement: "<input>",
        widgetEventPrefix: "spin",
        options: {
            culture: null,
            icons: {
                down: "ui-icon-triangle-1-s",
                up: "ui-icon-triangle-1-n"
            },
            incremental: !0,
            max: null,
            min: null,
            numberFormat: null,
            page: 10,
            step: 1,
            change: null,
            spin: null,
            start: null,
            stop: null
        },
        _create: function () {
            this._setOption("max", this.options.max), this._setOption("min", this.options.min), this._setOption("step", this.options.step), "" !== this.value() && this._value(this.element.val(), !0), this._draw(), this._on(this._events), this._refresh(), this._on(this.window, {
                beforeunload: function () {
                    this.element.removeAttr("autocomplete")
                }
            })
        },
        _getCreateOptions: function () {
            var t = {},
                i = this.element;
            return e.each(["min", "max", "step"], function (e, n) {
                var s = i.attr(n);
                void 0 !== s && s.length && (t[n] = s)
            }), t
        },
        _events: {
            keydown: function (e) {
                this._start(e) && this._keydown(e) && e.preventDefault()
            },
            keyup: "_stop",
            focus: function () {
                this.previous = this.element.val()
            },
            blur: function (e) {
                return this.cancelBlur ? void delete this.cancelBlur : (this._stop(), this._refresh(), void(this.previous !== this.element.val() && this._trigger("change", e)))
            },
            mousewheel: function (e, t) {
                if (t) {
                    if (!this.spinning && !this._start(e)) return !1;
                    this._spin((t > 0 ? 1 : -1) * this.options.step, e), clearTimeout(this.mousewheelTimer), this.mousewheelTimer = this._delay(function () {
                        this.spinning && this._stop(e)
                    }, 100), e.preventDefault()
                }
            },
            "mousedown .ui-spinner-button": function (t) {
                function n() {
                    var e = this.element[0] === this.document[0].activeElement;
                    e || (this.element.focus(), this.previous = i, this._delay(function () {
                        this.previous = i
                    }))
                }
                var i;
                i = this.element[0] === this.document[0].activeElement ? this.previous : this.element.val(), t.preventDefault(), n.call(this), this.cancelBlur = !0, this._delay(function () {
                    delete this.cancelBlur, n.call(this)
                }), this._start(t) !== !1 && this._repeat(null, e(t.currentTarget).hasClass("ui-spinner-up") ? 1 : -1, t)
            },
            "mouseup .ui-spinner-button": "_stop",
            "mouseenter .ui-spinner-button": function (t) {
                return e(t.currentTarget).hasClass("ui-state-active") ? this._start(t) === !1 ? !1 : void this._repeat(null, e(t.currentTarget).hasClass("ui-spinner-up") ? 1 : -1, t) : void 0
            },
            "mouseleave .ui-spinner-button": "_stop"
        },
        _draw: function () {
            var e = this.uiSpinner = this.element.addClass("ui-spinner-input").attr("autocomplete", "off").wrap(this._uiSpinnerHtml()).parent().append(this._buttonHtml());
            this.element.attr("role", "spinbutton"), this.buttons = e.find(".ui-spinner-button").attr("tabIndex", -1).button().removeClass("ui-corner-all"), this.buttons.height() > Math.ceil(.5 * e.height()) && e.height() > 0 && e.height(e.height()), this.options.disabled && this.disable()
        },
        _keydown: function (t) {
            var i = this.options,
                n = e.ui.keyCode;
            switch (t.keyCode) {
                case n.UP:
                    return this._repeat(null, 1, t), !0;
                case n.DOWN:
                    return this._repeat(null, -1, t), !0;
                case n.PAGE_UP:
                    return this._repeat(null, i.page, t), !0;
                case n.PAGE_DOWN:
                    return this._repeat(null, -i.page, t), !0
            }
            return !1
        },
        _uiSpinnerHtml: function () {
            return "<span class='ui-spinner ui-widget ui-widget-content ui-corner-all'></span>"
        },
        _buttonHtml: function () {
            return "<a class='ui-spinner-button ui-spinner-up ui-corner-tr'><span class='ui-icon " + this.options.icons.up + "'>&#9650;</span></a><a class='ui-spinner-button ui-spinner-down ui-corner-br'><span class='ui-icon " + this.options.icons.down + "'>&#9660;</span></a>"
        },
        _start: function (e) {
            return this.spinning || this._trigger("start", e) !== !1 ? (this.counter || (this.counter = 1), this.spinning = !0, !0) : !1
        },
        _repeat: function (e, t, i) {
            e = e || 500, clearTimeout(this.timer), this.timer = this._delay(function () {
                this._repeat(40, t, i)
            }, e), this._spin(t * this.options.step, i)
        },
        _spin: function (e, t) {
            var i = this.value() || 0;
            this.counter || (this.counter = 1), i = this._adjustValue(i + e * this._increment(this.counter)), this.spinning && this._trigger("spin", t, {
                value: i
            }) === !1 || (this._value(i), this.counter++)
        },
        _increment: function (t) {
            var i = this.options.incremental;
            return i ? e.isFunction(i) ? i(t) : Math.floor(t * t * t / 5e4 - t * t / 500 + 17 * t / 200 + 1) : 1
        },
        _precision: function () {
            var e = this._precisionOf(this.options.step);
            return null !== this.options.min && (e = Math.max(e, this._precisionOf(this.options.min))), e
        },
        _precisionOf: function (e) {
            var t = e.toString(),
                i = t.indexOf(".");
            return -1 === i ? 0 : t.length - i - 1
        },
        _adjustValue: function (e) {
            var t, i, n = this.options;
            return t = null !== n.min ? n.min : 0, i = e - t, i = Math.round(i / n.step) * n.step, e = t + i, e = parseFloat(e.toFixed(this._precision())), null !== n.max && e > n.max ? n.max : null !== n.min && e < n.min ? n.min : e
        },
        _stop: function (e) {
            this.spinning && (clearTimeout(this.timer), clearTimeout(this.mousewheelTimer), this.counter = 0, this.spinning = !1, this._trigger("stop", e))
        },
        _setOption: function (e, t) {
            if ("culture" === e || "numberFormat" === e) {
                var i = this._parse(this.element.val());
                return this.options[e] = t, void this.element.val(this._format(i))
            }("max" === e || "min" === e || "step" === e) && "string" == typeof t && (t = this._parse(t)), "icons" === e && (this.buttons.first().find(".ui-icon").removeClass(this.options.icons.up).addClass(t.up), this.buttons.last().find(".ui-icon").removeClass(this.options.icons.down).addClass(t.down)), this._super(e, t), "disabled" === e && (t ? (this.element.prop("disabled", !0), this.buttons.button("disable")) : (this.element.prop("disabled", !1), this.buttons.button("enable")))
        },
        _setOptions: t(function (e) {
            this._super(e), this._value(this.element.val())
        }),
        _parse: function (e) {
            return "string" == typeof e && "" !== e && (e = window.Globalize && this.options.numberFormat ? Globalize.parseFloat(e, 10, this.options.culture) : +e), "" === e || isNaN(e) ? null : e
        },
        _format: function (e) {
            return "" === e ? "" : window.Globalize && this.options.numberFormat ? Globalize.format(e, this.options.numberFormat, this.options.culture) : e
        },
        _refresh: function () {
            this.element.attr({
                "aria-valuemin": this.options.min,
                "aria-valuemax": this.options.max,
                "aria-valuenow": this._parse(this.element.val())
            })
        },
        _value: function (e, t) {
            var i;
            "" !== e && (i = this._parse(e), null !== i && (t || (i = this._adjustValue(i)), e = this._format(i))), this.element.val(e), this._refresh()
        },
        _destroy: function () {
            this.element.removeClass("ui-spinner-input").prop("disabled", !1).removeAttr("autocomplete").removeAttr("role").removeAttr("aria-valuemin").removeAttr("aria-valuemax").removeAttr("aria-valuenow"), this.uiSpinner.replaceWith(this.element)
        },
        stepUp: t(function (e) {
            this._stepUp(e)
        }),
        _stepUp: function (e) {
            this._start() && (this._spin((e || 1) * this.options.step), this._stop())
        },
        stepDown: t(function (e) {
            this._stepDown(e)
        }),
        _stepDown: function (e) {
            this._start() && (this._spin((e || 1) * -this.options.step), this._stop())
        },
        pageUp: t(function (e) {
            this._stepUp((e || 1) * this.options.page)
        }),
        pageDown: t(function (e) {
            this._stepDown((e || 1) * this.options.page)
        }),
        value: function (e) {
            return arguments.length ? void t(this._value).call(this, e) : this._parse(this.element.val())
        },
        widget: function () {
            return this.uiSpinner
        }
    })
}(jQuery),
function (e, t) {
    function s() {
        return ++i
    }

    function r(e) {
        return e = e.cloneNode(!1), e.hash.length > 1 && decodeURIComponent(e.href.replace(n, "")) === decodeURIComponent(location.href.replace(n, ""))
    }
    var i = 0,
        n = /#.*$/;
    e.widget("ui.tabs", {
        version: "1.10.4",
        delay: 300,
        options: {
            active: null,
            collapsible: !1,
            event: "click",
            heightStyle: "content",
            hide: null,
            show: null,
            activate: null,
            beforeActivate: null,
            beforeLoad: null,
            load: null
        },
        _create: function () {
            var t = this,
                i = this.options;
            this.running = !1, this.element.addClass("ui-tabs ui-widget ui-widget-content ui-corner-all").toggleClass("ui-tabs-collapsible", i.collapsible).delegate(".ui-tabs-nav > li", "mousedown" + this.eventNamespace, function (t) {
                e(this).is(".ui-state-disabled") && t.preventDefault()
            }).delegate(".ui-tabs-anchor", "focus" + this.eventNamespace, function () {
                e(this).closest("li").is(".ui-state-disabled") && this.blur()
            }), this._processTabs(), i.active = this._initialActive(), e.isArray(i.disabled) && (i.disabled = e.unique(i.disabled.concat(e.map(this.tabs.filter(".ui-state-disabled"), function (e) {
                return t.tabs.index(e)
            }))).sort()), this.active = this.options.active !== !1 && this.anchors.length ? this._findActive(i.active) : e(), this._refresh(), this.active.length && this.load(i.active)
        },
        _initialActive: function () {
            var t = this.options.active,
                i = this.options.collapsible,
                n = location.hash.substring(1);
            return null === t && (n && this.tabs.each(function (i, s) {
                return e(s).attr("aria-controls") === n ? (t = i, !1) : void 0
            }), null === t && (t = this.tabs.index(this.tabs.filter(".ui-tabs-active"))), (null === t || -1 === t) && (t = this.tabs.length ? 0 : !1)), t !== !1 && (t = this.tabs.index(this.tabs.eq(t)), -1 === t && (t = i ? !1 : 0)), !i && t === !1 && this.anchors.length && (t = 0), t
        },
        _getCreateEventData: function () {
            return {
                tab: this.active,
                panel: this.active.length ? this._getPanelForTab(this.active) : e()
            }
        },
        _tabKeydown: function (t) {
            var i = e(this.document[0].activeElement).closest("li"),
                n = this.tabs.index(i),
                s = !0;
            if (!this._handlePageNav(t)) {
                switch (t.keyCode) {
                    case e.ui.keyCode.RIGHT:
                    case e.ui.keyCode.DOWN:
                        n++;
                        break;
                    case e.ui.keyCode.UP:
                    case e.ui.keyCode.LEFT:
                        s = !1, n--;
                        break;
                    case e.ui.keyCode.END:
                        n = this.anchors.length - 1;
                        break;
                    case e.ui.keyCode.HOME:
                        n = 0;
                        break;
                    case e.ui.keyCode.SPACE:
                        return t.preventDefault(), clearTimeout(this.activating), void this._activate(n);
                    case e.ui.keyCode.ENTER:
                        return t.preventDefault(), clearTimeout(this.activating), void this._activate(n === this.options.active ? !1 : n);
                    default:
                        return
                }
                t.preventDefault(), clearTimeout(this.activating), n = this._focusNextTab(n, s), t.ctrlKey || (i.attr("aria-selected", "false"), this.tabs.eq(n).attr("aria-selected", "true"), this.activating = this._delay(function () {
                    this.option("active", n)
                }, this.delay))
            }
        },
        _panelKeydown: function (t) {
            this._handlePageNav(t) || t.ctrlKey && t.keyCode === e.ui.keyCode.UP && (t.preventDefault(), this.active.focus())
        },
        _handlePageNav: function (t) {
            return t.altKey && t.keyCode === e.ui.keyCode.PAGE_UP ? (this._activate(this._focusNextTab(this.options.active - 1, !1)), !0) : t.altKey && t.keyCode === e.ui.keyCode.PAGE_DOWN ? (this._activate(this._focusNextTab(this.options.active + 1, !0)), !0) : void 0
        },
        _findNextTab: function (t, i) {
            function s() {
                return t > n && (t = 0), 0 > t && (t = n), t
            }
            for (var n = this.tabs.length - 1; - 1 !== e.inArray(s(), this.options.disabled);) t = i ? t + 1 : t - 1;
            return t
        },
        _focusNextTab: function (e, t) {
            return e = this._findNextTab(e, t), this.tabs.eq(e).focus(), e
        },
        _setOption: function (e, t) {
            return "active" === e ? void this._activate(t) : "disabled" === e ? void this._setupDisabled(t) : (this._super(e, t), "collapsible" === e && (this.element.toggleClass("ui-tabs-collapsible", t), t || this.options.active !== !1 || this._activate(0)), "event" === e && this._setupEvents(t), void("heightStyle" === e && this._setupHeightStyle(t)))
        },
        _tabId: function (e) {
            return e.attr("aria-controls") || "ui-tabs-" + s()
        },
        _sanitizeSelector: function (e) {
            return e ? e.replace(/[!"$%&'()*+,.\/:;<=>?@\[\]\^`{|}~]/g, "\\$&") : ""
        },
        refresh: function () {
            var t = this.options,
                i = this.tablist.children(":has(a[href])");
            t.disabled = e.map(i.filter(".ui-state-disabled"), function (e) {
                return i.index(e)
            }), this._processTabs(), t.active !== !1 && this.anchors.length ? this.active.length && !e.contains(this.tablist[0], this.active[0]) ? this.tabs.length === t.disabled.length ? (t.active = !1, this.active = e()) : this._activate(this._findNextTab(Math.max(0, t.active - 1), !1)) : t.active = this.tabs.index(this.active) : (t.active = !1, this.active = e()), this._refresh()
        },
        _refresh: function () {
            this._setupDisabled(this.options.disabled), this._setupEvents(this.options.event), this._setupHeightStyle(this.options.heightStyle), this.tabs.not(this.active).attr({
                "aria-selected": "false",
                tabIndex: -1
            }), this.panels.not(this._getPanelForTab(this.active)).hide().attr({
                "aria-expanded": "false",
                "aria-hidden": "true"
            }), this.active.length ? (this.active.addClass("ui-tabs-active ui-state-active").attr({
                "aria-selected": "true",
                tabIndex: 0
            }), this._getPanelForTab(this.active).show().attr({
                "aria-expanded": "true",
                "aria-hidden": "false"
            })) : this.tabs.eq(0).attr("tabIndex", 0)
        },
        _processTabs: function () {
            var t = this;
            this.tablist = this._getList().addClass("ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all").attr("role", "tablist"), this.tabs = this.tablist.find("> li:has(a[href])").addClass("ui-state-default ui-corner-top").attr({
                role: "tab",
                tabIndex: -1
            }), this.anchors = this.tabs.map(function () {
                return e("a", this)[0]
            }).addClass("ui-tabs-anchor").attr({
                role: "presentation",
                tabIndex: -1
            }), this.panels = e(), this.anchors.each(function (i, n) {
                var s, a, o, l = e(n).uniqueId().attr("id"),
                    u = e(n).closest("li"),
                    h = u.attr("aria-controls");
                r(n) ? (s = n.hash, a = t.element.find(t._sanitizeSelector(s))) : (o = t._tabId(u), s = "#" + o, a = t.element.find(s), a.length || (a = t._createPanel(o), a.insertAfter(t.panels[i - 1] || t.tablist)), a.attr("aria-live", "polite")), a.length && (t.panels = t.panels.add(a)), h && u.data("ui-tabs-aria-controls", h), u.attr({
                    "aria-controls": s.substring(1),
                    "aria-labelledby": l
                }), a.attr("aria-labelledby", l)
            }), this.panels.addClass("ui-tabs-panel ui-widget-content ui-corner-bottom").attr("role", "tabpanel")
        },
        _getList: function () {
            return this.tablist || this.element.find("ol,ul").eq(0)
        },
        _createPanel: function (t) {
            return e("<div>").attr("id", t).addClass("ui-tabs-panel ui-widget-content ui-corner-bottom").data("ui-tabs-destroy", !0)
        },
        _setupDisabled: function (t) {
            e.isArray(t) && (t.length ? t.length === this.anchors.length && (t = !0) : t = !1);
            for (var n, i = 0; n = this.tabs[i]; i++) t === !0 || -1 !== e.inArray(i, t) ? e(n).addClass("ui-state-disabled").attr("aria-disabled", "true") : e(n).removeClass("ui-state-disabled").removeAttr("aria-disabled");
            this.options.disabled = t
        },
        _setupEvents: function (t) {
            var i = {
                click: function (e) {
                    e.preventDefault()
                }
            };
            t && e.each(t.split(" "), function (e, t) {
                i[t] = "_eventHandler"
            }), this._off(this.anchors.add(this.tabs).add(this.panels)), this._on(this.anchors, i), this._on(this.tabs, {
                keydown: "_tabKeydown"
            }), this._on(this.panels, {
                keydown: "_panelKeydown"
            }), this._focusable(this.tabs), this._hoverable(this.tabs)
        },
        _setupHeightStyle: function (t) {
            var i, n = this.element.parent();
            "fill" === t ? (i = n.height(), i -= this.element.outerHeight() - this.element.height(), this.element.siblings(":visible").each(function () {
                var t = e(this),
                    n = t.css("position");
                "absolute" !== n && "fixed" !== n && (i -= t.outerHeight(!0))
            }), this.element.children().not(this.panels).each(function () {
                i -= e(this).outerHeight(!0)
            }), this.panels.each(function () {
                e(this).height(Math.max(0, i - e(this).innerHeight() + e(this).height()))
            }).css("overflow", "auto")) : "auto" === t && (i = 0, this.panels.each(function () {
                i = Math.max(i, e(this).height("").height())
            }).height(i))
        },
        _eventHandler: function (t) {
            var i = this.options,
                n = this.active,
                s = e(t.currentTarget),
                r = s.closest("li"),
                a = r[0] === n[0],
                o = a && i.collapsible,
                l = o ? e() : this._getPanelForTab(r),
                u = n.length ? this._getPanelForTab(n) : e(),
                h = {
                    oldTab: n,
                    oldPanel: u,
                    newTab: o ? e() : r,
                    newPanel: l
                };
            t.preventDefault(), r.hasClass("ui-state-disabled") || r.hasClass("ui-tabs-loading") || this.running || a && !i.collapsible || this._trigger("beforeActivate", t, h) === !1 || (i.active = o ? !1 : this.tabs.index(r), this.active = a ? e() : r, this.xhr && this.xhr.abort(), u.length || l.length || e.error("jQuery UI Tabs: Mismatching fragment identifier."), l.length && this.load(this.tabs.index(r), t), this._toggle(t, h))
        },
        _toggle: function (t, i) {
            function a() {
                n.running = !1, n._trigger("activate", t, i)
            }

            function o() {
                i.newTab.closest("li").addClass("ui-tabs-active ui-state-active"), s.length && n.options.show ? n._show(s, n.options.show, a) : (s.show(), a())
            }
            var n = this,
                s = i.newPanel,
                r = i.oldPanel;
            this.running = !0, r.length && this.options.hide ? this._hide(r, this.options.hide, function () {
                i.oldTab.closest("li").removeClass("ui-tabs-active ui-state-active"), o()
            }) : (i.oldTab.closest("li").removeClass("ui-tabs-active ui-state-active"), r.hide(), o()), r.attr({
                "aria-expanded": "false",
                "aria-hidden": "true"
            }), i.oldTab.attr("aria-selected", "false"), s.length && r.length ? i.oldTab.attr("tabIndex", -1) : s.length && this.tabs.filter(function () {
                return 0 === e(this).attr("tabIndex")
            }).attr("tabIndex", -1), s.attr({
                "aria-expanded": "true",
                "aria-hidden": "false"
            }), i.newTab.attr({
                "aria-selected": "true",
                tabIndex: 0
            })
        },
        _activate: function (t) {
            var i, n = this._findActive(t);
            n[0] !== this.active[0] && (n.length || (n = this.active), i = n.find(".ui-tabs-anchor")[0], this._eventHandler({
                target: i,
                currentTarget: i,
                preventDefault: e.noop
            }))
        },
        _findActive: function (t) {
            return t === !1 ? e() : this.tabs.eq(t)
        },
        _getIndex: function (e) {
            return "string" == typeof e && (e = this.anchors.index(this.anchors.filter("[href$='" + e + "']"))), e
        },
        _destroy: function () {
            this.xhr && this.xhr.abort(), this.element.removeClass("ui-tabs ui-widget ui-widget-content ui-corner-all ui-tabs-collapsible"), this.tablist.removeClass("ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all").removeAttr("role"), this.anchors.removeClass("ui-tabs-anchor").removeAttr("role").removeAttr("tabIndex").removeUniqueId(), this.tabs.add(this.panels).each(function () {
                e.data(this, "ui-tabs-destroy") ? e(this).remove() : e(this).removeClass("ui-state-default ui-state-active ui-state-disabled ui-corner-top ui-corner-bottom ui-widget-content ui-tabs-active ui-tabs-panel").removeAttr("tabIndex").removeAttr("aria-live").removeAttr("aria-busy").removeAttr("aria-selected").removeAttr("aria-labelledby").removeAttr("aria-hidden").removeAttr("aria-expanded").removeAttr("role")
            }), this.tabs.each(function () {
                var t = e(this),
                    i = t.data("ui-tabs-aria-controls");
                i ? t.attr("aria-controls", i).removeData("ui-tabs-aria-controls") : t.removeAttr("aria-controls")
            }), this.panels.show(), "content" !== this.options.heightStyle && this.panels.css("height", "")
        },
        enable: function (i) {
            var n = this.options.disabled;
            n !== !1 && (i === t ? n = !1 : (i = this._getIndex(i), n = e.isArray(n) ? e.map(n, function (e) {
                return e !== i ? e : null
            }) : e.map(this.tabs, function (e, t) {
                return t !== i ? t : null
            })), this._setupDisabled(n))
        },
        disable: function (i) {
            var n = this.options.disabled;
            if (n !== !0) {
                if (i === t) n = !0;
                else {
                    if (i = this._getIndex(i), -1 !== e.inArray(i, n)) return;
                    n = e.isArray(n) ? e.merge([i], n).sort() : [i]
                }
                this._setupDisabled(n)
            }
        },
        load: function (t, i) {
            t = this._getIndex(t);
            var n = this,
                s = this.tabs.eq(t),
                a = s.find(".ui-tabs-anchor"),
                o = this._getPanelForTab(s),
                l = {
                    tab: s,
                    panel: o
                };
            r(a[0]) || (this.xhr = e.ajax(this._ajaxSettings(a, i, l)), this.xhr && "canceled" !== this.xhr.statusText && (s.addClass("ui-tabs-loading"), o.attr("aria-busy", "true"), this.xhr.success(function (e) {
                setTimeout(function () {
                    o.html(e), n._trigger("load", i, l)
                }, 1)
            }).complete(function (e, t) {
                setTimeout(function () {
                    "abort" === t && n.panels.stop(!1, !0), s.removeClass("ui-tabs-loading"), o.removeAttr("aria-busy"), e === n.xhr && delete n.xhr
                }, 1)
            })))
        },
        _ajaxSettings: function (t, i, n) {
            var s = this;
            return {
                url: t.attr("href"),
                beforeSend: function (t, r) {
                    return s._trigger("beforeLoad", i, e.extend({
                        jqXHR: t,
                        ajaxSettings: r
                    }, n))
                }
            }
        },
        _getPanelForTab: function (t) {
            var i = e(t).attr("aria-controls");
            return this.element.find(this._sanitizeSelector("#" + i))
        }
    })
}(jQuery),
function (e) {
    function i(t, i) {
        var n = (t.attr("aria-describedby") || "").split(/\s+/);
        n.push(i), t.data("ui-tooltip-id", i).attr("aria-describedby", e.trim(n.join(" ")))
    }

    function n(t) {
        var i = t.data("ui-tooltip-id"),
            n = (t.attr("aria-describedby") || "").split(/\s+/),
            s = e.inArray(i, n); - 1 !== s && n.splice(s, 1), t.removeData("ui-tooltip-id"), n = e.trim(n.join(" ")), n ? t.attr("aria-describedby", n) : t.removeAttr("aria-describedby")
    }
    var t = 0;
    e.widget("ui.tooltip", {
        version: "1.10.4",
        options: {
            content: function () {
                var t = e(this).attr("title") || "";
                return e("<a>").text(t).html()
            },
            hide: !0,
            items: "[title]:not([disabled])",
            position: {
                my: "left top+15",
                at: "left bottom",
                collision: "flipfit flip"
            },
            show: !0,
            tooltipClass: null,
            track: !1,
            close: null,
            open: null
        },
        _create: function () {
            this._on({
                mouseover: "open",
                focusin: "open"
            }), this.tooltips = {}, this.parents = {}, this.options.disabled && this._disable()
        },
        _setOption: function (t, i) {
            var n = this;
            return "disabled" === t ? (this[i ? "_disable" : "_enable"](), void(this.options[t] = i)) : (this._super(t, i), void("content" === t && e.each(this.tooltips, function (e, t) {
                n._updateContent(t)
            })))
        },
        _disable: function () {
            var t = this;
            e.each(this.tooltips, function (i, n) {
                var s = e.Event("blur");
                s.target = s.currentTarget = n[0], t.close(s, !0)
            }), this.element.find(this.options.items).addBack().each(function () {
                var t = e(this);
                t.is("[title]") && t.data("ui-tooltip-title", t.attr("title")).attr("title", "")
            })
        },
        _enable: function () {
            this.element.find(this.options.items).addBack().each(function () {
                var t = e(this);
                t.data("ui-tooltip-title") && t.attr("title", t.data("ui-tooltip-title"))
            })
        },
        open: function (t) {
            var i = this,
                n = e(t ? t.target : this.element).closest(this.options.items);
            n.length && !n.data("ui-tooltip-id") && (n.attr("title") && n.data("ui-tooltip-title", n.attr("title")), n.data("ui-tooltip-open", !0), t && "mouseover" === t.type && n.parents().each(function () {
                var n, t = e(this);
                t.data("ui-tooltip-open") && (n = e.Event("blur"), n.target = n.currentTarget = this, i.close(n, !0)), t.attr("title") && (t.uniqueId(), i.parents[this.id] = {
                    element: this,
                    title: t.attr("title")
                }, t.attr("title", ""))
            }), this._updateContent(n, t))
        },
        _updateContent: function (e, t) {
            var i, n = this.options.content,
                s = this,
                r = t ? t.type : null;
            return "string" == typeof n ? this._open(t, e, n) : (i = n.call(e[0], function (i) {
                e.data("ui-tooltip-open") && s._delay(function () {
                    t && (t.type = r), this._open(t, e, i)
                })
            }), void(i && this._open(t, e, i)))
        },
        _open: function (t, n, s) {
            function u(e) {
                l.of = e, r.is(":hidden") || r.position(l)
            }
            var r, a, o, l = e.extend({}, this.options.position);
            if (s) {
                if (r = this._find(n), r.length) return void r.find(".ui-tooltip-content").html(s);
                n.is("[title]") && (t && "mouseover" === t.type ? n.attr("title", "") : n.removeAttr("title")), r = this._tooltip(n), i(n, r.attr("id")), r.find(".ui-tooltip-content").html(s), this.options.track && t && /^mouse/.test(t.type) ? (this._on(this.document, {
                    mousemove: u
                }), u(t)) : r.position(e.extend({
                    of: n
                }, this.options.position)), r.hide(), this._show(r, this.options.show), this.options.show && this.options.show.delay && (o = this.delayedShow = setInterval(function () {
                    r.is(":visible") && (u(l.of), clearInterval(o))
                }, e.fx.interval)), this._trigger("open", t, {
                    tooltip: r
                }), a = {
                    keyup: function (t) {
                        if (t.keyCode === e.ui.keyCode.ESCAPE) {
                            var i = e.Event(t);
                            i.currentTarget = n[0], this.close(i, !0)
                        }
                    },
                    remove: function () {
                        this._removeTooltip(r)
                    }
                }, t && "mouseover" !== t.type || (a.mouseleave = "close"), t && "focusin" !== t.type || (a.focusout = "close"), this._on(!0, n, a)
            }
        },
        close: function (t) {
            var i = this,
                s = e(t ? t.currentTarget : this.element),
                r = this._find(s);
            this.closing || (clearInterval(this.delayedShow), s.data("ui-tooltip-title") && s.attr("title", s.data("ui-tooltip-title")), n(s), r.stop(!0), this._hide(r, this.options.hide, function () {
                i._removeTooltip(e(this))
            }), s.removeData("ui-tooltip-open"), this._off(s, "mouseleave focusout keyup"), s[0] !== this.element[0] && this._off(s, "remove"), this._off(this.document, "mousemove"), t && "mouseleave" === t.type && e.each(this.parents, function (t, n) {
                e(n.element).attr("title", n.title), delete i.parents[t]
            }), this.closing = !0, this._trigger("close", t, {
                tooltip: r
            }), this.closing = !1)
        },
        _tooltip: function (i) {
            var n = "ui-tooltip-" + t++,
                s = e("<div>").attr({
                    id: n,
                    role: "tooltip"
                }).addClass("ui-tooltip ui-widget ui-corner-all ui-widget-content " + (this.options.tooltipClass || ""));
            return e("<div>").addClass("ui-tooltip-content").appendTo(s), s.appendTo(this.document[0].body), this.tooltips[n] = i, s
        },
        _find: function (t) {
            var i = t.data("ui-tooltip-id");
            return i ? e("#" + i) : e()
        },
        _removeTooltip: function (e) {
            e.remove(), delete this.tooltips[e.attr("id")]
        },
        _destroy: function () {
            var t = this;
            e.each(this.tooltips, function (i, n) {
                var s = e.Event("blur");
                s.target = s.currentTarget = n[0], t.close(s, !0), e("#" + i).remove(), n.data("ui-tooltip-title") && (n.attr("title", n.data("ui-tooltip-title")), n.removeData("ui-tooltip-title"))
            })
        }
    })
}(jQuery);
