
  var map = L.map('map').setView([39.87, -75.24], 13);

  var baseMap = L.esri.basemapLayer('Gray').addTo(map);
  var gbaseMap = L.esri.basemapLayer('DarkGray');//.addTo(map);
  var streetMap = L.esri.basemapLayer('Streets');//.addTo(map);
  var topoMap = L.esri.basemapLayer('Topographic');//.addTo(map);
  var oMap = L.esri.basemapLayer('Oceans');//.addTo(map);

  var runwayLayer = L.esri.featureLayer({
    url: 'https://services6.arcgis.com/ssFJjBXIUyZDrSYZ/arcgis/rest/services/Runways/FeatureServer/0'
  }).addTo(map);
  var pane = map.createPane('class');
  pane.style.opacity = 0.2;
  var classLayer = L.esri.featureLayer({
    url: 'https://services6.arcgis.com/ssFJjBXIUyZDrSYZ/arcgis/rest/services/Class_Airspace/FeatureServer/0',
    style: function() {
      return {
        color: '#010101',
        fill: false,
        fillColor: '#FFFFFF',
        weight: 2
      };
    },
    onEachFeature: function(feature, layer) {
        layer.bindPopup(feature.properties.NAME);
    },
    pane: 'class'
  }).addTo(map);

  var shades = [ '#0000ff', '#3232ff', '#6666ff', '#9999ff', '#ccccff'];
  var counts = [ '10', '7', '5', '3', '1'];
  var coin = [ true, false ];

  function getRandomIntInclusive(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  var markerLayer = new L.ConditionalMarkers({
    minZoomShow: 12,
    maxZoomShow: 16,
    viewportPadding: 0.0
  }).addTo(map);

  var countLayer = new L.ConditionalMarkers({
    minZoomShow: 12,
    maxZoomShow: 16,
    viewportPadding: 0.0
  }).addTo(map);

  $.ajaxSetup ({
    cache: false
  });

  function countClick(e) {
		var dialog = $('<div style="z-index=999;"></div>').load("popup.html");
    $(dialog).dialog({ 
      zIndex: 999,
      width: 345
    });
  }

  function pendingClick() {
    var latlngs = [[39.8, -75.05],[39.805, -75.03],[39.83, -75.00],[39.82, -75.02]];
    var polygon = L.polygon(latlngs, {color: 'red'}).addTo(map);
    map.fitBounds(polygon.getBounds());
		var dialog = $('<div style="z-index=999;padding-top: 10px;padding-left: 10px;"><button>Approve</button>&nbsp;&nbsp;<button>Deny</button></div>');
    $(dialog).dialog({ 
      zIndex: 999,
      width: 170,
      height: 90,
      close: function(e){
        map.removeLayer(polygon);
      }
    });
  }

  var emptyRectLayer = L.layerGroup().addTo(map);
  var rectLayer = L.layerGroup().addTo(map);
  var min = 1.0/60.0;
  for(lat = 39.4; lat < 40.4; lat+=min) {
      for(lon = -75.8; lon < -74.8; lon+=min) {
          var b = [[lat, lon], [lat+min,lon+min]];
          /*
          var blueshade = Math.floor(Math.random() * 255) + 1; //1 to 255
          var hex = blueshade.toString(16);
          var bcolor = '#0000'+hex;
          */
          var idx = getRandomIntInclusive(0,4);
          var bcolor = shades[idx];
          var shouldFill = coin[getRandomIntInclusive(0,1)];
          //shouldFill = false;
          var altLimit = '400';
          var phlCenterLat = 39.87;
          var phlCenterLon = -75.24;
          if(Math.abs(lat-phlCenterLat) <= 3*min && Math.abs(lon-phlCenterLon) <= 3*min) {
            altLimit = '0';
            shouldFill = false;
          } else if(Math.abs(lat-phlCenterLat) <= 10*min && Math.abs(lon-phlCenterLon) <= 10*min) {
            altLimit = '100';
          } else if(Math.abs(lat-phlCenterLat) <= 15*min && Math.abs(lon-phlCenterLon) <= 15*min) {
            altLimit = '200';
          } else if(Math.abs(lat-phlCenterLat) <= 17*min && Math.abs(lon-phlCenterLon) <= 17*min) {
            altLimit = '300';
          }
          var r = L.rectangle(b, { fill: false, fillOpacity: 0.4, color: '#808080', fillColor: bcolor, weight: 1 });
          emptyRectLayer.addLayer(r);
          var r = L.rectangle(b, { fill: shouldFill, fillOpacity: 0.4, color: '#808080', fillColor: bcolor, weight: 1 });
          rectLayer.addLayer(r);
          var myIcon = L.divIcon({html: altLimit, className: 'label'});
          var center = r.getBounds().getCenter();
          var m = L.marker(center, {icon: myIcon});
          markerLayer.addLayer(m);
          if(shouldFill) {
            var myCount = L.divIcon({html: counts[idx], className: 'count-label'});
            var corner = r.getBounds().getSouthEast();
            corner.lat += 0.0010;
            corner.lng -= 0.0015;
            var c = L.marker(corner, {icon: myCount}).on('click', countClick);
            /*
            c.bindPopup(function() {
              var el = $('<div/>');
              $.get("popup.html").done(function(data) {
                  el.html = data;
                  //popup.update();
              });
              return el.html;
            });
            */
            countLayer.addLayer(c);
          }
      }  
  }

  var bounds1 = [[40.0, -75.0], [40.016667,-75.016667]];
  var rect1 = L.rectangle(bounds1, {color: '#0000FF', weight: 1});

    var baseMaps = {
        "Grayscale": baseMap,
        "DarkGrayscale": gbaseMap,
        "Streets": streetMap,
        "Topographic": topoMap,
        "Oceans": oMap
    };

    var overlayMaps = {
        "Empty Grid": emptyRectLayer,
        "Color Grid": rectLayer,
        "Labels": markerLayer,
        "Counts": countLayer,
        "Runways": runwayLayer,
        "Class": classLayer
    };

    L.control.layers(baseMaps, overlayMaps).addTo(map);
    //L.control.layers(null, overlayMaps).addTo(map);

    L.control.scale().addTo(map);

